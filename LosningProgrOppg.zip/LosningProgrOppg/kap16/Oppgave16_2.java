/**
 * Oppgave16_2.java  - "Programmering i Java", 4.utgave - 2011-02-28
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen og videreutviklet
 * av Hans Roar Sandberg for tidligere utgaver av boka.
 *
 * Denne filen inneholder en klasse Tekst som "krypterer" vha. en kode som ligger p� en
 * egen fil. Programmet leser tekst fra en fil, krypterer denne, og skriver
 * resultatet til en tredje fil.
 */
import mittBibliotek.DataLeser;
import java.io.*;

public class Oppgave16_2 {
  public static void main(String[] args) throws IOException {

    /* Leser inn filnavn fra brukeren. */
    String kode = DataLeser.lesTekst("Fil som inneholder kodene:");
    String original = DataLeser.lesTekst("Fil som inneholder tekst:");
    String resultat = DataLeser.lesTekst("Fil som skal inneholde resultatet:");

    /* Oppretter et objekt av klassen Tekst som krypterer innholdet i originalfila*/
    Tekst enTekst = new Tekst(kode,original,resultat);

    String utskrift = "Krypterer:\n";
    utskrift += enTekst.getOriginalTekst();
    utskrift += "\n\nKryptert versjon av teksten:\n";
    utskrift += enTekst.getKryptertTekst();

    javax.swing.JOptionPane.showMessageDialog(null, utskrift);
  }
}


/**
 * Klassen Tekst
 */
class Tekst {
  public final static String ALFABETET = "abcdefghijklmnopqrstuvwxyz���";
  private final String kodeks;
  private final String originalTekst;
  private String kryptertTekst = "";
  private boolean kryptert = false;

  public Tekst(String kodeksFil, String originalFilNavn, String resultatFilNavn) throws IOException {
    originalTekst = lesInnTekst(originalFilNavn);
    kodeks = lesInnTekst(kodeksFil);
    if (kodeks.length() != ALFABETET.length())  {   // /kke samsvar mellom antall bokstaver i alfabetet og koden
     throw new IllegalArgumentException("Illegal kode.");
    }
    krypter(resultatFilNavn);
  }

  public String getOriginalTekst() {
    return originalTekst;
  }

  public String getKryptertTekst()  throws IOException {
    return kryptertTekst;
  }

 /**
  * Privat hjelpemetode.
  * Leser inn tekst fra oppgitt fil.
  */
  private String lesInnTekst(String filnavn) throws IOException {
    FileReader lesForb = new FileReader(filnavn);
    BufferedReader leser = new BufferedReader(lesForb);
    String tekst = "";

    String linje = leser.readLine();
    while (linje != null) {
      tekst += linje + "\n";
      linje = leser.readLine();
    }
    /* Fjerner siste linjeskift da det ikke skal v�re med */
    tekst = tekst.substring(0,tekst.length() - 1);
    leser.close();
    return tekst;
  }

  /**
   * Privat hjelpemetode.
   * Dette metoden tar utgangspunkt i originalTekst og endrer den i henhold til kodeks.
   * Resultatet lagres i variabelen kryptertTekst og ogs� p� oppgitt datafil.
   */
  private void krypter(String resultatFilNavn) throws IOException {
    StringBuilder resultat = new StringBuilder(); // Se side 253 og 278
    for (int i = 0; i < originalTekst.length(); i++) {
      boolean stor = Character.isUpperCase(originalTekst.charAt(i));
      int pos = ALFABETET.indexOf(Character.toLowerCase(originalTekst.charAt(i)));
      if (pos > -1) {
        if (stor) {
          resultat.append(Character.toUpperCase(kodeks.charAt(pos)));
        } else {
          resultat.append(kodeks.charAt(pos));
        }
      } else {
        resultat.append(originalTekst.charAt(i));
      }
    }

    kryptertTekst = resultat.toString();

    /* �pner forbindelse for skriving til fil, og skriver ut den krypterte teksten */
    FileWriter resultatForbindelse = new FileWriter(resultatFilNavn, false);
    PrintWriter resultatSkriver = new PrintWriter(new BufferedWriter(resultatForbindelse));
    resultatSkriver.print(kryptertTekst);
    resultatSkriver.close();
  }
}


/* Eksempel p� kj�ring:

Filen med kodene ser slik ut:

�yxwv�tsrqp�nmlkjihgfedcbazuo

Filen med originaldataene ser slik ut:

Simon Thoresen
Thomas Angells gate 12
7011 Trondheim

Resultatfilen ser slik ut:

Hrnlm Gslivhvm
Gsln�h �mtv��h t�gv 12
7011 Gilmwsvrn

*/