/*
 * Oppgave16_4.java  - "Programmering i Java", 4.utgave - 2011-02-28
 *
 * Fletting av filer:
 * To sorterte filer flettes. Bare ett tall fra hver fil lagres i minnet
 * av gangen. For � f� til � lese kun ett tall av gangen fra en tekstfil,
 * knyttes den til et RandomAccessFile-objekt ved �pningen. Vi bruker
 * readByte()-metoden for � lese �n byte av gangen. Vi skj�ter flere
 * bytes sammen til �n streng og omformer denne til et heltall.
 *
 * Vi forutsetter at dataene er feilfrie.
 */

import java.io.*;
import static javax.swing.JOptionPane.*;

/* Klassen som beskriver en input-fil */
class InndataFil {
  private RandomAccessFile leser;
  public InndataFil(String filnavn) throws IOException {
    leser = new RandomAccessFile(filnavn, "r");
  }

  /**
   * Leser et heltall fra filen.
   * Algoritme: Se innledningsteksten foran.
   */
  public int lesHeltall() throws Exception {
    String etHeltall = "";
    try {  // hopper over blanke foran tallet
      char etTegn = (char) leser.readByte();
      while (!Character.isDigit(etTegn) && etTegn != '-') {
        etTegn = (char) leser.readByte();
      }

      do {  // leser bytes inntil ikke-siffer p�treffes
        etHeltall += etTegn;
        etTegn = (char) leser.readByte();
      } while (Character.isDigit(etTegn));

    } finally {  // omformer til et heltallsobjekt, ogs� dersom EOFException kastes
      return (Integer.parseInt(etHeltall));
    }
  }

  public void close() throws IOException {
    leser.close();
  }
}

/* Denne klassen beskriver utdata-filen */
class UtdataFil {
  private PrintWriter skriver;
  private int antallTallSkrevet = 0; // maks 10 tall pr linje
  private static final int maksPrLinje = 10;

  public UtdataFil(String filnavn) throws IOException {
    skriver = new PrintWriter(
                  new BufferedWriter(
                      new FileWriter(filnavn, false)));
  }

  /**
   * Skriver et heltall (med blank) til datafilen.
   */
  public void skriv(int tall) {
    skriver.print(tall + " ");
    antallTallSkrevet++;
    if (antallTallSkrevet == maksPrLinje) {
      skriver.println();
      antallTallSkrevet = 0;
    }
  }

  public void close() throws IOException {
    skriver.close();
  }
}

class Oppgave16_4 {
  public static void main(String[] args) throws Exception {
    InndataFil input1 = new InndataFil(showInputDialog("Input file 1: "));
    InndataFil input2 = new InndataFil(showInputDialog("Input file 2: "));
    UtdataFil output = new UtdataFil(showInputDialog("Output file: "));

    boolean filslutt1 = false;
    boolean filslutt2 = false;

    int tall1 = 0;
    int tall2 = 0;

    try {
      tall1 = input1.lesHeltall();
    } catch (Exception e) {
      filslutt1 = true;
    }

    try {
      tall2 = input2.lesHeltall();
    } catch (Exception e) {
      filslutt2 = true;
    }

    while (!filslutt1 && !filslutt2) {
      if (tall1 < tall2) {
        output.skriv(tall1);
        try {
          tall1 = input1.lesHeltall();
        } catch (Exception e) {
          filslutt1 = true;
        }
      } else {
        output.skriv(tall2);
        try {
          tall2 = input2.lesHeltall();
        } catch (Exception e) {
          filslutt2 = true;
        }
      }
    }

    if (filslutt1 && !filslutt2) {
      while (!filslutt2) {
        output.skriv(tall2);
        try {
          tall2 = input2.lesHeltall();
        } catch (Exception e) {
          filslutt2 = true;
        }
      }
    }

    if (filslutt2 && !filslutt1) {
      while (!filslutt1) {
        output.skriv(tall1);
        try {
          tall1 = input1.lesHeltall();
        } catch (Exception e) {
          filslutt1 = true;
        }
      }
    }

    input1.close();
    input2.close();
    output.close();
  }
}

/* Eksempel p� kj�ring:

Inndatafil 1:
-10, -3, 0, 1, 3, 5, 6, 9, 23, 89

Inndatafil 2:
-34, 19, 51, 83, 125, 665, 745, 879, 1000

Resultatfilen:
-34 -10 -3 0 1 3 5 6 9 19
23 51 83 89 125 665 745 879 1000
*/