/*
 * Oppgave21_1.java ST/EL 2001-06-15
 *
 * Denne oppgaven omfatter at man skal utvide programliste 21.4 til � ogs�
 * st�tte sletting av data fra s�ketreet. Dette er en ganske omfattende
 * operasjon, men ved � implementere de n�dvendige funksjonene beskrevet i
 *
 *   "Introduction to Algorithms" av Cormen, Leiserson og Rivest
 *
 * blir oppgaven betraktelig enklere. Under kapittel 13, "Binary Search Trees",
 * finnes pseudokoden for b�de innsetting og sletting av data.
 */
public class Oppgave21_1 {
  public static void main(String[] args) {

    /* Fyller et tre med tilfeldig data. */
    SubTre tre = new SubTre(6);
    for (int i = 1; i < 25; i++) {
      int verdi = 0;
      do {
        verdi = (int)(Math.random() * 50);
      }
      while (tre.s�kEtterVerdi(verdi));

      tre.settInnVerdi(verdi);
    }

    System.out.println("Treet: " + tre + "\n");

    /* Pr�ver � slette en rekke tilfeldige tall. */
    for (int i = 0; i < 5; i++) {
      int verdi = 0;
      do {
        verdi = (int)(Math.random() * 50);
      }
      while (!tre.s�kEtterVerdi(verdi));

      slettVerdi(tre, verdi);
      System.out.println("Slettet tallet " + verdi + ".\n" +
                          "Treet: " + tre + "\n");
    }
  }

  /*
   * Metoden sletter en gitt verdi fra det gitte treet.
   */
  public static boolean slettVerdi(SubTre tre, int enVerdi) {
    SubTre z = tre.finnSubTre(enVerdi);
    if (z == null)
      return false;

    SubTre y = null;
    if (z.finnVenstreTre() == null || z.finnH�yreTre() == null)
      y = z;
    else
      y = z.finnEtterf�lger();

    SubTre x = null;
    if (y.finnVenstreTre() != null)
      x = y.finnVenstreTre();
    else
      x = y.finnH�yreTre();

    if (x != null)
      x.settForelder(y.finnForelder());

    if (y.finnForelder() == null)
      tre = x;
    else if (y == y.finnForelder().finnVenstreTre())
      y.finnForelder().settVenstreTre(x);
    else
      y.finnForelder().settH�yreTre(x);

    if (y != z)
      z.settVerdi(y.finnVerdi());

    return true;
  }
}

/*
 * Klasse for delene av et bin�rt s�ketre. Subtreene, inklusive
 * bladene, best�r av nye objekter av klassen.
 */
class SubTre {
  private SubTre h�yreTre = null;
  private SubTre venstreTre = null;
  private SubTre forelder = null;
  private int verdi = 0;

  public SubTre(int startVerdi) {
    verdi = startVerdi;
  }

  public SubTre(int startVerdi, SubTre startForelder) {
    verdi = startVerdi;
    forelder = startForelder;
  }

  /*
   * Metoden setter inn en ny verdi i dette (sub)treet.
   */
  public void settInnVerdi(int nyVerdi) {

    /* Dersom verdien for dette hj�rnet er st�rre enn eller likden
     * nye, skal den nye verdien inn i venstre subtre. */
    if (verdi >= nyVerdi) {
      if (venstreTre != null) {
        venstreTre.settInnVerdi(nyVerdi);
      } else {
        venstreTre = new SubTre(nyVerdi, this);
      }
    } else {
      if (h�yreTre != null) {
        h�yreTre.settInnVerdi(nyVerdi);
      } else {
        h�yreTre = new SubTre(nyVerdi, this);
      }
    }
  }

  /*
   * Finn-metoder
   */
  public SubTre finnVenstreTre() {
    return venstreTre;
  }

  public SubTre finnH�yreTre() {
    return h�yreTre;
  }

  public SubTre finnForelder() {
    return forelder;
  }

  public SubTre finnRot() {
    if (forelder == null)
      return this;
    else
      return forelder.finnRot();
  }

  public SubTre finnMin() {
    if (venstreTre == null)
      return this;
    else
      return venstreTre.finnMin();
  }

  public SubTre finnMaks() {
    if (h�yreTre == null)
      return this;
    else
      return h�yreTre.finnMaks();
  }

  public SubTre finnEtterf�lger() {
    if (h�yreTre != null)
      return h�yreTre.finnMin();

    if (forelder == null)
      return this;
    else if (forelder.finnVenstreTre() == this)
      return forelder;
    else
      return forelder.finnEtterf�lger();
  }

  public SubTre finnSubTre(int enVerdi) {
    if (verdi == enVerdi)
      return this;

    if (verdi > enVerdi) {
      if (venstreTre != null)
        return venstreTre.finnSubTre(enVerdi);
    }
    else {
      if (h�yreTre != null)
        return h�yreTre.finnSubTre(enVerdi);
    }

    return null;
  }

  public int finnVerdi() {
    return verdi;
  }

  /*
   * Sett-metoder
   */
  public void settVenstreTre(SubTre tre) {
    venstreTre = tre;
  }

  public void settH�yreTre(SubTre tre) {
    h�yreTre = tre;
  }

  public void settForelder(SubTre tre) {
    forelder = tre;
  }

  public void settVerdi(int nyVerdi) {
    verdi = nyVerdi;
  }

  /*
   * Metoden traverserer treet infiks, og returnerer en tekst med
   * innholdet, separert med blanktegn.
   */
  public String toString () {
    String returStreng = "";
    if (venstreTre != null) {
      returStreng = venstreTre.toString() + " ";
    }
    returStreng = returStreng + verdi;
    if (h�yreTre != null) {
      returStreng = returStreng + " " + h�yreTre.toString();
    }
    return returStreng;
  }

  /*
   * Metoden returnerer true dersom den oppgitte verdien finnes i
   * treet.
   */
  public boolean s�kEtterVerdi(int s�keVerdi) {
    if (s�keVerdi == verdi) return true;
    if (verdi > s�keVerdi) {
      if (venstreTre != null) {
        return venstreTre.s�kEtterVerdi(s�keVerdi);
      } else {
        return false;
      }
    } else {
      if (h�yreTre != null) {
        return h�yreTre.s�kEtterVerdi(s�keVerdi);
      } else {
        return false;
      }
    }
  }
}

/* Utskriftvindu:
Treet: 1 4 5 6 8 10 13 14 15 16 17 21 22 23 25 26 27 28 31 35 36 39 40 44 49

Slettet tallet 28.
Treet: 1 4 5 6 8 10 13 14 15 16 17 21 22 23 25 26 27 31 35 36 39 40 44 49

Slettet tallet 36.
Treet: 1 4 5 6 8 10 13 14 15 16 17 21 22 23 25 26 27 31 35 39 40 44 49

Slettet tallet 35.
Treet: 1 4 5 6 8 10 13 14 15 16 17 21 22 23 25 26 27 31 39 40 44 49

Slettet tallet 16.
Treet: 1 4 5 6 8 10 13 14 15 17 21 22 23 25 26 27 31 39 40 44 49

Slettet tallet 5.
Treet: 1 4 6 8 10 13 14 15 17 21 22 23 25 26 27 31 39 40 44 49
*/