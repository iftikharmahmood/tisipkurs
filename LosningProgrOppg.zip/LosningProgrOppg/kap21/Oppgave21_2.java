/*
 * Oppgave21_2.java ST/EL 2006-01-24
 *
 * Denne oppgaven har til m�l � sammenlikne to datastrukturer for � se hvilke
 * av disse som egner seg best til � holde et stort antall data.
 *
 * Det er viktig � p�peke at dette er "feil" m�te � sammenlikne to strukturer,
 * da enhver struktur har egenskaper tilpasset sitt problemdomene.
 *
 * Vi utf�rer 2 tester, en med sekvensiell data og en med tilfeldig data. Dette
 * b�r ogs� kaste lys p� noe av strukturenes egenskaper.
 *
 * Bruken av lokal variabel 'verdi':
 *   Ved � bruke denne slipper TreeMap � opprette to egne Integer, mens
 *   LinkedList bare trenger �n. Ved et stort antall iterasjoner kan slike
 *   forskjeller p�virker resultatet.
 */
import java.util.*;

public class Oppgave21_2 {
  public static void main(String[] args) {

    /* Utf�rer et stort antall tester. */
    System.out.println("Resultat etter 1.000 innsettinger " +
                        "(sekvensiell / tilfeldig):\n" +
                        "  Lenket Liste:   " + testListe(1000, true) + "ms / "+
                                               testListe(1000, false) + "ms\n" +
                        "  Bin�rt S�ketre: " + testTre(1000, true) + "ms / " +
                                               testTre(1000, false) + "ms\n");

    System.out.println("Resultat etter 10.000 innsettinger " +
                        "(sekvensiell / tilfeldig):\n" +
                        "  Lenket Liste:   " + testListe(10000, true) + "ms / "+
                                               testListe(10000, false) + "ms\n" +
                        "  Bin�rt S�ketre: " + testTre(10000, true) + "ms / " +
                                               testTre(10000, false) + "ms\n");

    System.out.println("Resultat etter 100.000 innsettinger " +
                        "(sekvensiell / tilfeldig):\n" +
                        "  Lenket Liste:   " + testListe(100000, true) + "ms / "+
                                               testListe(100000, false) + "ms\n" +
                        "  Bin�rt S�ketre: " + testTre(100000, true) + "ms / " +
                                               testTre(100000, false) + "ms\n");
  }

  public static double testTre(int iterasjoner, boolean sekvensiell) {
    TreeMap<Double, Double> tre = new TreeMap<Double, Double>();
    double startTid = System.currentTimeMillis();

    for (int i = 0; i < iterasjoner; i++) {
      Double verdi = new Double(sekvensiell ? i : Math.random());
      tre.put(verdi, verdi);
    }

    double stoppTid = System.currentTimeMillis();
    return stoppTid - startTid;
  }

  public static double testListe(int iterasjoner, boolean sekvensiell) {
    LinkedList<Double> liste = new LinkedList<Double>();
    double startTid = System.currentTimeMillis();

    for (int i = 0; i < iterasjoner; i++) {
      Double verdi = new Double(sekvensiell ? i : Math.random());
      liste.addLast(verdi);
    }

    double stoppTid = System.currentTimeMillis();
    return stoppTid - startTid;
  }
}

/* Utskriftvindu:
Resultat etter 1.000 innsettinger (sekvensiell / tilfeldig):
  Lenket Liste:   0.0ms / 0.0ms
  Bin�rt S�ketre: 0.0ms / 0.0ms

Resultat etter 10.000 innsettinger (sekvensiell / tilfeldig):
  Lenket Liste:   60.0ms / 50.0ms
  Bin�rt S�ketre: 770.0ms / 60.0ms

Resultat etter 100.000 innsettinger (sekvensiell / tilfeldig):
  Lenket Liste:   1050.0ms / 540.0ms
  Bin�rt S�ketre: 1210.0ms / 1430.0ms
*/