/**
 * Oppgave6_1.java - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Program som beregner hvor mye l�nn en sensor skal ha.
 * Beregningene ligger i klassen Sensurering
 *
 */
import static javax.swing.JOptionPane.*;
class Sensurering {
  public static final int MUNTLIG_EKSAMEN = 1;
  public static final int SKRIFTLIG_EKSAMEN = 2;
  public static final int PROSJEKTOPPGAVE = 3;

  private static final double FORBEREDELSE = 3.0; // timer
  private static final int GRENSE = 10; // grensen mellom faktor1 og faktor2
  private static final double FAKTOR1 = 0.15;
  private static final double FAKTOR2 = 0.1;
  private static final double PROSJEKTSENSUR = 8; // timer

  private final String fag;
  private final int eksamenstype;
  private final double lengde;
  private final int antBesvarelser;

  public Sensurering(String fag, double medg�ttTid) {  // brukes ved muntlig eksamen
    this.fag = fag;
    this.lengde = medg�ttTid;
    this.eksamenstype = MUNTLIG_EKSAMEN;
    this.antBesvarelser = 0;
  }

  public Sensurering(String fag, int antBesvarelser) {  // brukes ved prosjektoppgave
    this.fag = fag;
    this.antBesvarelser = antBesvarelser;
    this.eksamenstype = PROSJEKTOPPGAVE;
    this.lengde = 0.0;
  }

  public Sensurering(String fag, double lengde, int antBesvarelser) {  // brukes ved skriftlig eksamen
    this.fag = fag;
    this.lengde = lengde;
    this.antBesvarelser = antBesvarelser;
    this.eksamenstype = SKRIFTLIG_EKSAMEN;
  }

  public double finnTimeforbruk() {
    if (eksamenstype == MUNTLIG_EKSAMEN) {
      return beregnMuntligEksamen();
    } else if (eksamenstype == SKRIFTLIG_EKSAMEN) {
      return beregnSkriftligEksamen();
    } else {
      return beregnProsjektoppgaver();
    }
  }

  private double beregnMuntligEksamen() {
    return lengde + FORBEREDELSE;
  }

  private double beregnSkriftligEksamen() {
    double antTimer = FORBEREDELSE;
    if (antBesvarelser < GRENSE) {
      antTimer += FAKTOR1 * lengde * antBesvarelser;
    } else {
      antTimer += FAKTOR1 * lengde * GRENSE + FAKTOR2 * lengde * (antBesvarelser - GRENSE);
    }
    return antTimer;
  }

  private double beregnProsjektoppgaver() {
    return antBesvarelser * PROSJEKTSENSUR;
  }
}

class Oppgave6_1 {
  public static void main(String[] args) {
    Sensurering sensur1 = new Sensurering("Fag1", 15.5);  // muntlig
    Sensurering sensur2 = new Sensurering("Fag2", 4, 50);  // skriftlig
    Sensurering sensur3 = new Sensurering("Fag3", 5, 10);  // skriftlig
    Sensurering sensur4 = new Sensurering("Fag4", 3, 5);  // skriftlig
    Sensurering sensur5 = new Sensurering("Fag5", 5); // prosjekt

    System.out.println("Totalt antall tester: 5");
    final double TOLERANSE = 0.001;
    if (Math.abs(sensur1.finnTimeforbruk() - 18.5) < TOLERANSE) {
      System.out.println("Sensurering: Test 1 vellykket.");
    }
    if (Math.abs(sensur2.finnTimeforbruk() - 25.0) < TOLERANSE) {
      System.out.println("Sensurering: Test 2 vellykket.");
    }
    if (Math.abs(sensur3.finnTimeforbruk() - 10.5) < TOLERANSE) {
      System.out.println("Sensurering: Test 3 vellykket.");
    }
    if (Math.abs(sensur4.finnTimeforbruk() - 5.25) < TOLERANSE) {
      System.out.println("Sensurering: Test 4 vellykket.");
    }
    if (Math.abs(sensur5.finnTimeforbruk() - 40.0) < TOLERANSE) {
      System.out.println("Sensurering: Test 5 vellykket.");
    }
  }
}