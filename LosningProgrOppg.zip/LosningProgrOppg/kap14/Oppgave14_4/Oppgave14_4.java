/**
 * Oppgave14_4.java  - "Programmering i Java", 4.utgave - 2011-02-03
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen og videreutviklet av Vidar Vestnes
 * og Hans Roar Sandberg for tidligere utgaver av boka.
 *
 * Denne oppgaven beskriver et kunderegister som til stor grad benytter seg av
 * arv og polymorfi.
 */
import java.util.*;

public class Oppgave14_4 {
  public static void main(String[] args) {

    /* Oppretter et register, og fyller det med tilfeldige kunder. */
    Register register = new Register();
    register.registrerNyKunde(new Kunde("Simon Thoresen",
                               "7011 Trondheim",
                               "+47 915 47 197"));
    register.registrerNyttSalg(0, new NySalg("Aixam 300/400", 87000, 2010, 11));
    register.registrerNyttSalg(0, new BruktSalg("Alfa Romeo 156 1.8 TS", 259000, 2005,
                                       "34.500 km. servo, ABS, el.vindu, utetemp, " +
                                       "sp.understell, 17'alu, klima, fj.st.s.l�s, " +
                                       "v.seter, cd, alu.v.dekk, skinnratt. ",
                                       2000));

    register.registrerNyKunde(new FirmaKunde("ideX A.S.",
                                    "7053 Ranheim",
                                    "+47 73 919 232",
                                    "Erik Thoresen",
                                    "+47 900 13 260"));
    register.registrerNyttSalg(1, new BruktSalg("Jaguar Six 3.2 Sport", 439000, 2008,
                                       "44.830 km. Aut. aut, klima aut, skinn, abs, " +
                                       "airbag, servo, 4el.vinduer/speil/soltak, " +
                                       "el.just.seter, startsperre, alu, fj.sl�s, " +
                                       "v.seter, kompl.s.hefte.",
                                       1996));
    register.registrerNyttSalg(1, new NySalg("Audi A6 1.9TDi Avant", 379000, 2010, 9));

    /* Skriver ut data om alle kundene. */
    for (int i = 0; i < register.finnAntallKunder(); i++) {
      Kunde kunde = register.finnKunde(i);
      System.out.println(kunde.toString() + "\n");

      System.out.println("Total kj�pesum: " + register.finnTotaltSalgKunde(i));
      System.out.println("Snitt alder: " + register.finnSnittAlderKunde(i) + "\n\n");
    }
  }
}

/**
 * Klassen Kunde
 * En Kunde-klasse med navn, adresse, telefon samt oversikt over utf�rte salg.
 */
class Kunde {

  private ArrayList<Salg> salg = new ArrayList<Salg>();
  private final String navn;
  private final String adresse;
  private final String telefon;

  public Kunde(String navn, String adresse, String telefon) {
    this.navn = navn;
    this.adresse = adresse;
    this.telefon = telefon;
  }

  public String getNavn() {
    return navn;
  }

  public String getAdresse() {
    return adresse;
  }

  public String getTelefon() {
    return telefon;
  }

  /**
   * Registrerer nytt salg.
   * Ingen kontroll av om salget er registrert tidligere, e.l.
   */
  public void registrerNyttSalg(Salg ettSalg) {
    salg.add(ettSalg);
  }

  /**
   * Summerer opp totalt salg for denne kunden.
   */
  public double finnTotaltSalg() {
    double sum = 0.0;
    for (Salg etSalg : salg) {
      sum += etSalg.getPris();
    }
    return sum;
  }

  /**
   * Beregner gjennomsnittlig bilalder.
   * Returnerer -1 hvis ingen biler er registrert.
   */
  public double finnSnittAlder() {
    int sum = 0;
    for (Salg etSalg : salg) {
      sum += etSalg.finnAlder();
    }
    return (salg.size() == 0) ? -1 : (double) (sum / salg.size());
  }

  public String toString() {
    String res = "Navn: " + navn + ",\nAdresse: " + adresse + ",\nTlf.: " + telefon + "\n";
    for (Salg s : salg) {
      res += "Salg: " + s.toString() + "\n";
    }
    return res;
  }
}

/**
 * Klassen FirmaKunde
 */
class FirmaKunde extends Kunde {

  private final String kontaktNavn;
  private final String kontaktTelefon;

  public FirmaKunde(String navn, String adresse, String telefon,
                    String kontaktNavn, String kontaktTelefon) {
    super(navn, adresse, telefon);
    this.kontaktNavn = kontaktNavn;
    this.kontaktTelefon = kontaktTelefon;
  }

  public String getKontaktNavn() {
    return kontaktNavn;
  }

  public String getKontaktTelefon() {
    return kontaktTelefon;
  }

  public String toString() {
    return super.toString() + "Mer info: Kontaktnavn: " + kontaktNavn + ", kontakttlf.: " + kontaktTelefon;
  }
}


/**
 * Klassen Salg
 * Klassen med bilmerke, pris og salgs�r.
 */
abstract class Salg {

  private final String bilmerke;
  private final double pris;
  private final int salgs�r;

  public Salg(String bilmerke, double pris, int salgs�r) {
    this.bilmerke = bilmerke;
    this.pris = pris;
    this.salgs�r = salgs�r;
  }

  abstract public int finn�rsmodell();

  public int finnAlder() {
    int alder = salgs�r - finn�rsmodell();
    return (alder <= 0) ? 0 : alder;
  }

  public String getBilmerke() {
    return bilmerke;
  }

  public double getPris() {
    return pris;
  }

  public int getSalgs�r() {
    return salgs�r;
  }

  public String toString() {
    java.text.NumberFormat pengeformat = java.text.NumberFormat.getCurrencyInstance();
    return finn�rsmodell() + " " + bilmerke + ", " + pengeformat.format(pris) + ", salgs�r: " + salgs�r;
  }
}

/**
 * Klassen NySalg
 */
class NySalg extends Salg {
  public static final int OKTOBER = 10; // m�nedsnummer
  private final int salgsmnd;

  public NySalg(String bilmerke, double pris, int salgs�r, int salgsmnd) {
    super(bilmerke, pris, salgs�r);
    this.salgsmnd = salgsmnd;
  }

  public int getSalgsmnd() {
    return salgsmnd;
  }

  public int finn�rsmodell() {
    if (salgsmnd >= OKTOBER) {
      return getSalgs�r() + 1;
    } else {
      return getSalgs�r();
    }
  }

  public String toString() {
    return super.toString() + ", salgsmnd: " + salgsmnd;
  }
}

/**
 * Klassen BruktSalg
 */
class BruktSalg extends Salg {

  private final int �rsmodell;
  private final String beskrivelse;

  public BruktSalg(String bilmerke, double pris, int salgs�r, String beskrivelse, int �rsmodell) {
    super(bilmerke, pris, salgs�r);
    this.beskrivelse = beskrivelse;
    this.�rsmodell = �rsmodell;
  }

  public int finn�rsmodell() {
    return �rsmodell;
  }

  public String getBeskrivelse() {
    return beskrivelse;
  }

  public String toString() {
    return super.toString() + "\n  " + beskrivelse;
  }
}

/**
 * Klassen Register
 * Klasse med kunderegister. I tilknytning til hver kunde finner vi oversikt over salgene til kunden.
 */
class Register {

  private ArrayList<Kunde> liste = new ArrayList<Kunde>();

  /**
   * Returnerer antall kunder.
   */
  public int finnAntallKunder() {
    return liste.size();
  }

  /**
   * Finner en kunde, gitt indeksen - som typisk g�r fra og med 0 og opp til, men ikke inkludert, finnAntallKunder()
   * Metoden returnerer null hvis indeksen er ugyldig.
   */
  public Kunde finnKunde(int indeks) {
    return (indeks >= 0 && indeks < liste.size()) ? liste.get(indeks) : null;
  }

  /**
   * Finner totalsalget til en kunde, gitt kundeindeksen -
   * som typisk g�r fra og med 0 og opp til, men ikke inkludert, finnAntallKunder()
   * Metoden returnerer null hvis indeksen er ugyldig.
   */
  public double finnTotaltSalgKunde(int indeks) {
    Kunde kunde = finnKunde(indeks);
    return (kunde == null) ? null : kunde.finnTotaltSalg();
  }

  /**
   * Finner gjennomsnittlig alder p� bilene en kunde har kj�pt, gitt kundeindeksen -
   * som typisk g�r fra og med 0 og opp til, men ikke inkludert, finnAntallKunder()
   * Metoden returnerer null hvis indeksen er ugyldig.
   */
  public double finnSnittAlderKunde(int indeks) {
    Kunde kunde = finnKunde(indeks);
    return (kunde == null) ? null : kunde.finnSnittAlder();
  }

  /**
   * Skifter ut kundedata p� en gitt indeks.
   * Metoden returnerer false dersom ugyldig indeks.
   */
  public boolean settKunde(int indeks, Kunde kunde) {
    if (indeks >= 0 && indeks < liste.size()) {
      liste.set(indeks, kunde);
      return true;
    } else {
      return false;
    }
  }

  /**
   * Registrerer en ny kunde.
   * Ingen kontroll av hvorvidt kunde med dette navn e.l. er registrert fra f�r.
   */
  public void registrerNyKunde(Kunde kunde) {
    liste.add(kunde);
  }

  /**
   * Registrerer et nytt salg til en kunde, gitt kundeindeksen -
   * som typisk g�r fra og med 0 og opp til, men ikke inkludert, finnAntallKunder()
   * Metoden returnerer false hvis indeksen er ugyldig, ellers true.
   */
  public boolean registrerNyttSalg(int indeks, Salg salg) {
    if (indeks >= 0 && indeks < liste.size()) {
      Kunde kunde = liste.get(indeks);
      kunde.registrerNyttSalg(salg);
      return true;
    } else {
      return false;
    }
  }
}

/* Utskriftvindu:
Navn: Simon Thoresen,
Adresse: 7011 Trondheim,
Tlf.: +47 915 47 197
Salg: 2010 Aixam 300/400, kr 87�000,00, salgs�r: 2010, salgsmnd: 0
Salg: 2000 Alfa Romeo 156 1.8 TS, kr 259000,00, salgs�r: 2005
  34.500 km. servo, ABS, el.vindu, utetemp, sp.understell, 17'alu, klima, fj.st.
s.l�s, v.seter, cd, alu.v.dekk, skinnratt.


Total kj�pesum: 346000.0
Snitt alder: 2.0


Navn: ideX A.S.,
Adresse: 7053 Ranheim,
Tlf.: +47 73 919 232
Salg: 1996 Jaguar Six 3.2 Sport, kr 439�000,00, salgs�r: 2008
  44.830 km. Aut. aut, klima aut, skinn, abs, airbag, servo, 4el.vinduer/speil/s
oltak, el.just.seter, startsperre, alu, fj.sl�s, v.seter, kompl.s.hefte.
Salg: 2010 Audi A6 1.9TDi Avant, kr 379000,00, salgs�r: 2010, salgsmnd: 0
Mer info: Kontaktnavn: Erik Thoresen, kontakttlf.: +47 900 13 260

Total kj�pesum: 818000.0
Snitt alder: 6.0
*/