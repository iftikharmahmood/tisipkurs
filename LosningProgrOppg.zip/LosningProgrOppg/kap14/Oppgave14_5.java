/* *
 * Oppgave14_5.java  - "Programmering i Java", 4.utgave - 2011-02-16
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen og videreutviklet
 * av Hans Roar Sandberg for tidligere utgaver av boka.
 *
 * Programmet vedlikeholder et register over n�kkelkort.
 *
 * F�lgende oversikt viser de testdata som brukes:
 *
 *    Type kort  Nr     Tilgang d�rer natt    Tilgang d�rer dag
 *    Ansatt       0      1 2 4 5 6                 1 2 3 4 5 6 7 (eller alle)
 *    Ansatt       1      1 2 5 6                    1 2 3 4 5 6 7 (eller alle)
 *    Student     2      Ingen                      2 3 7
 *    Student     3      Ingen                      2 3
 *    Kurs          4      Ingen                      1 2 4 5
 *
 *
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.*;
import mittBibliotek.DataLeser; // se kap. 15.1, programliste 15.1 side 495-497, - brukes til � lese heltall

class Oppgave14_5 {
  public static void main(String[] args) {

    /* D�rene v�re har nummer 1, 2, .., 7. I prinsippet kan hvilke som helst
       d�rnummer brukes. Det ligger ikke inne noe kontroll av det. */

    final int d�rnrMaks = 7;

    /* Ansatte og studenter har en fast mengde d�rer de har adgang til */
    Ansatt.fastAdgang(1);
    Ansatt.fastAdgang(2);
    Ansatt.fastAdgang(5);
    Ansatt.fastAdgang(6);

    Student.fastAdgang(2);
    Student.fastAdgang(3);


    /* Oppretter et register og fyller det med noen tilfeldige kort. */
    KortRegister register = new KortRegister();

    /* To ansattkort */
    Ansatt aKort = new Ansatt();
    aKort.tillatD�r(4); // spesialtilgang, kort nr 0
    register.registrerNyttKort(aKort);
    register.registrerNyttKort(new Ansatt());  // kort nr 1

    /* To studentkort */
    Student sKort = new Student();
    sKort.tillatD�r(d�rnrMaks); // spesialtilgang til d�ren med h�yest nr
    register.registrerNyttKort(sKort); // kort nr 2
    register.registrerNyttKort(new Student()); // kort nr 3

    /* Ett kurskort */
    int[] kursdatoer = {20030201, 20030204, 20030208, 20030210};
    int[] kursd�rer = {2, 4, 5};
    Kort kKort = new Kurs(kursd�rer, kursdatoer, 800, 1530);
    register.registrerNyttKort(kKort);  // kort nr 4
    kKort.tillatD�r(1); // ekstra d�r p� dette kurs-kortet

    /* Hvilke d�rer har et kort tilgang til? */
    for (int kortIndeks = 0; kortIndeks < register.finnAntKort(); kortIndeks++) {
      Kort dette = register.finnKort(kortIndeks);
      System.out.println("\nKort nr " + kortIndeks + ", sperret? " + dette.isSperret());
      System.out.println("Tilgang midt p� dagen, d�r nr: " + register.finnD�rer(kortIndeks, 20030201, 1200));
      System.out.println("\nTilgang midt p� natta, d�r nr: " + register.finnD�rer(kortIndeks, 20030201, 2400));
    }

    /* Hvem har tilgang til d�rene? */
    for (int d�rNr = 1; d�rNr <= d�rnrMaks; d�rNr++) {
      System.out.print("\nTilgang til d�r nr " + d�rNr + " midt p� dagen: ");
      ArrayList kortNr = register.finnTilgang(d�rNr, 20030201, 1200);
      for (int i = 0; i < kortNr.size(); i++) {
        System.out.print(kortNr.get(i) + " ");
      }
      System.out.print("\nTilgang til d�r nr " + d�rNr + " midt p� natta: ");
      kortNr = register.finnTilgang(d�rNr, 20030201, 2400);
      for (int i = 0; i < kortNr.size(); i++) {
        System.out.print(kortNr.get(i) + " ");
      }
    }
    System.out.println();
    System.out.println();

    /* Har en bestemt person tilgang til en bestem d�r p� et bestemt tidspunkt? */
    for (int kortIndeks = 0; kortIndeks < register.finnAntKort(); kortIndeks++) {
      for (int d�rNr = 1; d�rNr <= d�rnrMaks; d�rNr++) {
        System.out.println("Middag,  kort nr " + kortIndeks + ", d�r nr: " + d�rNr + " " +
                                       register.tilgangOk(kortIndeks, d�rNr, 20030201, 1200));

        System.out.println("Midnatt, kort nr " + kortIndeks + ", d�r nr: " + d�rNr + " " +
                                       register.tilgangOk(kortIndeks, d�rNr, 20030201, 2400));
      }
      System.out.println();
    }
  }
}

/**
 * Klassen KortRegister
 *
 * Klassen inneholder en mengde d�rkort. Kortene har ikke egne identifikasjoner,
 * men identifiseres ved den plass (indeks) de har i ArrayListen 'liste'.
 * Denne indeksen blir dermed kortets nummer utad. Det g�r bra, fordi kort ikke
 * flyttes eller fjernes i listen.
 *
 * Klassen bruker ArrayLister til � lagre heltall (kortnummer, d�rnummer).
 */

class KortRegister {
  private ArrayList<Kort> liste = new ArrayList<Kort>();

  /**
   * Metoden finner antall kort registrert.
   */
  public int finnAntKort() {
    return liste.size();
  }

  /**
   * Metoden finner et bestemt kort. Returnerer null hvis ugyldig indeks.
   */
  public Kort finnKort(int indeks) {
    return (indeks >= 0 && indeks < liste.size()) ?(Kort) liste.get(indeks) : null;
  }

  /**
   * Returnerer nummerne til de d�rene som et bestemt kort har tilgang til
   * p� et bestemt tidspunkt.
   */
  public String finnD�rer(int kortIndeks, int dato, int klokkeslett) {
    Kort kort = finnKort(kortIndeks);
    return (kort != null) ? kort.finnAlleD�rerMedTilgang(dato, klokkeslett) : null;
  }

  /**
   * Returnerer en ArrayList med numrene p� kortene som har tilgang
   * til en bestemt d�r p� et bestemt klokkeslett.
   */
  public ArrayList<Integer> finnTilgang(int d�r, int dato, int klokkeslett) {
    ArrayList<Integer> tilgang = new ArrayList<Integer>();
    for (int i = 0; i < liste.size(); i++) {
      if (tilgangOk(i, d�r, dato, klokkeslett)) {
        tilgang.add(i);  // auto-boxing
      }
    }
    return tilgang;
  }

  /**
   * Metoden finner ut om en bestemt person har tilgang til en bestemt
   * d�r p� et bestemt klokkeslett.
   * Metoden returnerer false hvis kort med oppgitt indeks ikke fins,
   * eller personen ikke har tilgang.
   */
  public boolean tilgangOk(int kortIndeks, int d�r, int dato, int klokkeslett) {
    Kort kort = finnKort(kortIndeks);
    if (kort == null) {
      return false;  // RETUR
    }
    return (kort.tilgang(d�r, dato, klokkeslett));
  }

  /*   *
   * Metoden registrerer et nytt kort.
   */
  public void registrerNyttKort(Kort kort) {
    liste.add(kort);
  }

  /**
   * Metoden sperrer et kort.
   * Metoden returnerer false hvis kort med oppgitt indeks ikke fins.
   */
  public boolean sperrKort(int indeks) {
    Kort kort = finnKort(indeks);
    if (kort == null) {
      return false;
    }
    kort.setSperret(true);
    return true;
  }

  /**
   * Metoden opphever sperringen p� et kort.
   * Metoden returnerer false hvis kort med oppgitt indeks ikke fins.
   */
  public boolean �pneKort(int indeks) {
    Kort kort = finnKort(indeks);
    if (kort == null) {
      return false;
    }
    kort.setSperret(false);
    return true;
  }
}

/***** Her kommer klassen Kort med subklasser *****/

/* Disse klassene lagrer heltall (d�rnummer) som ArrayLister av Integer-objekter */

/**
 * Klassen Kort
 *
 */
abstract class Kort {
  public static final String SPERRET_BESKJED = "Kortet er sperret";
  public static final String ALLE_BESKJED = "Alle d�rer";
  public static final String INGEN_BESKJED = "Ingen d�rer";
  public static final int DAG_START = 700;  // kl 07:00
  public static final int DAG_SLUTT = 2300; // kl 23:00

  private boolean sperret = false;

  /**
   * For hvert kort lagrer vi de d�rene som kortet �pnes spesielt for.
   * I tillegg kommer en fast mengde d�rer for ansatte og for studenter.
   * Disse lagres i klassevariabler, se klassene Ansatt og Student.
   */
  private ArrayList<Integer> d�rer = new ArrayList<Integer>();

  /**
   * Metoden reurnerer true dersom dette kortet er sperret.
   */
  public boolean isSperret() {
    return sperret;
  }

  /**
   * Metoden brukes til � sette eller �pne sperring.
   */
  public void setSperret(boolean nySperret) {
    sperret = nySperret;
  }

  /**
   * Denne metoden brukes for � gi dette kortet tilgang til en bestemt d�r
   * (i tillegg til eventuelle faste d�rer).
   */
  public void tillatD�r(int d�r) {
    d�rer.add(d�r); // auto-boxing
  }

  /**
   * Metoden finner alle d�rer som dette kortet gir tilgang til p�
   * et bestemt tidspunkt. Returnerer en streng for � fange alle tilfeller.
   */
  abstract public String finnAlleD�rerMedTilgang(int dato, int klokkeslett);

  /**
   * Skal finne ut om kortet har tilgang til en bestemt d�r p� et bestemt tidspunkt.
   * Spesielle regler gjelder for alle grupper kort.
   */
  abstract public boolean tilgang(int d�r, int dato, int klokkeslett);

  /**
   * Metoden returnerer en ArrayList med alle d�rer som dette kortet har tilgang til.
   * Her kommer ikke faste d�rer med. Metoden implementeres derfor ogs� i subklassene
   * Ansatt og Student, for � f� med faste d�rer.
   */
  protected ArrayList<Integer> finnD�rer() {
    return d�rer;
  }

  /**
   * Denne metoden lager en streng med de d�rene som kortet har tilgang til.
   * Tar ikke hensyn til faste d�rer. Metoden implementeres derfor ogs� i subklassene
   * Ansatt og Student, for � f� med dette.
   */
  protected String finnTilgang() {
    if (sperret) {
      return SPERRET_BESKJED;
    }
    StringBuilder buf = new StringBuilder();
    for (int enD�r : d�rer) {
      buf.append(enD�r + " ");
    }
    return buf.toString();
  }
}

/**
 * Klassen Fast
 * Denne klassen tjener kun klassifiseringsform�l slik vi har laget den her.
 * Kunne eventuelt lagt konstantene DAG_START og DAG_SLUTT her.
 */
abstract class Fast extends Kort {
}

/**
 * Klassen Kurs
 *
 * Det finnes ikke en mengde faste d�rer som alle kursdeltakere har adgang til.
 * B�de d�rer og datoer for tilgang kodes for hvert enkelt kurskort.
 * Samme tidsperiode (klokkeslett fra - til) gjelder for alle datoene p� samme kort.
 */
final class Kurs extends Kort {
  private final int[] datoer;
  private final int fraKlokka;
  private final int tilKlokka;

  public Kurs(int[] startD�rer, int[] startDatoer, int startFraKlokka, int startTilKlokka) {
    datoer = startDatoer;
    fraKlokka = startFraKlokka;
    tilKlokka = startTilKlokka;
    for (int enD�r : startD�rer) {
      tillatD�r(enD�r);
    }
  }

  public String finnAlleD�rerMedTilgang(int dato, int klokkeslett) {
    if (isSperret()) {
      return SPERRET_BESKJED;
    }
    if (!tilgangTid(dato, klokkeslett)) {
      return INGEN_BESKJED;
    }
    return finnTilgang();
  }

  public boolean tilgang(int d�r, int dato, int klokkeslett) {
    if (isSperret()) {
      return false;
    }
    if (!tilgangTid(dato, klokkeslett)) {
      return false;
    }

    /* Sjekker d�rene */
    ArrayList<Integer> d�rer = finnD�rer();
    if (d�rer.indexOf(d�r) >= 0) {
      return true;  // s�ker etter heltall i ArrayListen
    }
    return false;
  }

  /* Privat hjelpemetode */
  private boolean tilgangTid(int dato, int klokkeslett) {
    /* Sjekker datoen */
    boolean datoFunnet = false;
    int datoIndeks = 0;
    while (!datoFunnet && datoIndeks < datoer.length) {
      if (dato == datoer[datoIndeks]) {
        datoFunnet = true;
      } else {
        datoIndeks++;
      }
    }

    /* Deretter m� klokkeslettet ligge innenfor lovlig intervall for dette kurskortet */
    if (datoFunnet && fraKlokka <= klokkeslett && klokkeslett <= tilKlokka) {
      return true;
    } else {
      return false;
    }
  }
}

/**
 * Klassen Ansatt
 *
 * Ansatte har tilgang til alle d�rer p� dagtid.
 * Ansatte har tilgang til et begrenset utvalg d�rer om natta, dog med kode.
 * Det begrensede utvalget d�rer best�r av en mengde faste d�rer (som er klassevariabel
 * i denne klassen), og en mengde spesielle d�rer, som bestemmes individuelt for
 * hvert kort.
 */
final class Ansatt extends Fast {
  private static ArrayList<Integer> fasteD�rer = new ArrayList<Integer>();

  public static void fastAdgang(int d�r) {
    fasteD�rer.add(d�r);
  }

  public String finnTilgang() {
    String tmp = super.finnTilgang();
    if (isSperret()) {
      return tmp;
    }
    return oversiktFasteD�rer() + tmp;
  }

  public String finnAlleD�rerMedTilgang(int dato, int klokkeslett) {
    if (isSperret()) {
      return SPERRET_BESKJED;
    }
    if (klokkeslett >= DAG_START && klokkeslett <= DAG_SLUTT) {
      return ALLE_BESKJED;
    }
    return finnTilgang();
  }

  public boolean tilgang(int d�r, int dato, int klokkeslett) {
    if (isSperret()) {
      return false;
    }
    if (klokkeslett >= DAG_START && klokkeslett <= DAG_SLUTT) {
      return true;
    }

    /*
     * P� natta har ansatte tilgang til faste d�rer og d�rer med
     * spesialtillatelse.
     */
    ArrayList<Integer> d�rerSpesial = finnD�rer();
    /* Sjekker om d�rnr er i en av de to ArrayListene */
    if (d�rerSpesial.indexOf(d�r) >= 0 || fasteD�rer.indexOf(d�r) >= 0) {
      return true;
    } else {
      return false;
    }
  }

  private static String oversiktFasteD�rer() {
    StringBuilder oversikt = new StringBuilder();
    for (int enD�r : fasteD�rer) {
      oversikt.append(enD�r + " ");
    }
    return oversikt.toString();
  }
}

/**
 * Klassen Student
 * Studenter har ikke tilgang til noen d�rer om natta.
 * De har tilgang til et begrenset utvalg d�rer p� dagtid.
 * Det begrensede utvalget d�rer best�r av en mengde faste d�rer (som er klassevariabel
 * i denne klassen), og en mengde spesielle d�rer, som bestemmes individuelt for
 * hvert kort.
 *
 */
final class Student extends Fast {
  private static ArrayList<Integer> fasteD�rer = new ArrayList<Integer>();

  public static void fastAdgang(int d�r) {
    fasteD�rer.add(d�r);
  }

  public String finnTilgang() {
    String tmp = super.finnTilgang();
    if (isSperret()) {
      return tmp;
    }
    return oversiktFasteD�rer() + tmp;
  }

  public String finnAlleD�rerMedTilgang(int dato, int klokkeslett) {
    if (isSperret()) {
      return SPERRET_BESKJED;
    }
    if (klokkeslett <= DAG_START || klokkeslett >= DAG_SLUTT) {
      return INGEN_BESKJED;
    }
    return finnTilgang();
  }

  public boolean tilgang(int d�r, int dato, int klokkeslett) {
    if (isSperret()) {
      return false;
    }
    if (klokkeslett <= DAG_START || klokkeslett >= DAG_SLUTT) {
      return false;
    }

    /* Sjekker d�ra */
    ArrayList d�rerSpesial = finnD�rer();
    /* Sjekker om d�rnr er i en av de to ArrayListene */
    if (d�rerSpesial.indexOf(d�r) >= 0 || fasteD�rer.indexOf(d�r) >= 0) {
      return true;
    }
    return false;
  }

  private static String oversiktFasteD�rer() {
    StringBuilder oversikt = new StringBuilder();
    for (int enD�r : fasteD�rer) oversikt.append(enD�r + " ");
    return oversikt.toString();
  }
}


/* Utskrift:

Kort nr 0, sperret? false
Tilgang midt p� dagen, d�r nr: Alle d�rer

Tilgang midt p� natta, d�r nr: 1 2 5 6 4

Kort nr 1, sperret? false
Tilgang midt p� dagen, d�r nr: Alle d�rer

Tilgang midt p� natta, d�r nr: 1 2 5 6

Kort nr 2, sperret? false
Tilgang midt p� dagen, d�r nr: 2 3 7

Tilgang midt p� natta, d�r nr: Ingen d�rer

Kort nr 3, sperret? false
Tilgang midt p� dagen, d�r nr: 2 3

Tilgang midt p� natta, d�r nr: Ingen d�rer

Kort nr 4, sperret? false
Tilgang midt p� dagen, d�r nr: 2 4 5 1

Tilgang midt p� natta, d�r nr: Ingen d�rer

Tilgang til d�r nr 1 midt p� dagen: 0 1 4
Tilgang til d�r nr 1 midt p� natta: 0 1
Tilgang til d�r nr 2 midt p� dagen: 0 1 2 3 4
Tilgang til d�r nr 2 midt p� natta: 0 1
Tilgang til d�r nr 3 midt p� dagen: 0 1 2 3
Tilgang til d�r nr 3 midt p� natta:
Tilgang til d�r nr 4 midt p� dagen: 0 1 4
Tilgang til d�r nr 4 midt p� natta: 0
Tilgang til d�r nr 5 midt p� dagen: 0 1 4
Tilgang til d�r nr 5 midt p� natta: 0 1
Tilgang til d�r nr 6 midt p� dagen: 0 1
Tilgang til d�r nr 6 midt p� natta: 0 1
Tilgang til d�r nr 7 midt p� dagen: 0 1 2
Tilgang til d�r nr 7 midt p� natta:

Middag,  kort nr 0, d�r nr: 1 true
Midnatt, kort nr 0, d�r nr: 1 true
Middag,  kort nr 0, d�r nr: 2 true
Midnatt, kort nr 0, d�r nr: 2 true
Middag,  kort nr 0, d�r nr: 3 true
Midnatt, kort nr 0, d�r nr: 3 false
Middag,  kort nr 0, d�r nr: 4 true
Midnatt, kort nr 0, d�r nr: 4 true
Middag,  kort nr 0, d�r nr: 5 true
Midnatt, kort nr 0, d�r nr: 5 true
Middag,  kort nr 0, d�r nr: 6 true
Midnatt, kort nr 0, d�r nr: 6 true
Middag,  kort nr 0, d�r nr: 7 true
Midnatt, kort nr 0, d�r nr: 7 false

Middag,  kort nr 1, d�r nr: 1 true
Midnatt, kort nr 1, d�r nr: 1 true
Middag,  kort nr 1, d�r nr: 2 true
Midnatt, kort nr 1, d�r nr: 2 true
Middag,  kort nr 1, d�r nr: 3 true
Midnatt, kort nr 1, d�r nr: 3 false
Middag,  kort nr 1, d�r nr: 4 true
Midnatt, kort nr 1, d�r nr: 4 false
Middag,  kort nr 1, d�r nr: 5 true
Midnatt, kort nr 1, d�r nr: 5 true
Middag,  kort nr 1, d�r nr: 6 true
Midnatt, kort nr 1, d�r nr: 6 true
Middag,  kort nr 1, d�r nr: 7 true
Midnatt, kort nr 1, d�r nr: 7 false

Middag,  kort nr 2, d�r nr: 1 false
Midnatt, kort nr 2, d�r nr: 1 false
Middag,  kort nr 2, d�r nr: 2 true
Midnatt, kort nr 2, d�r nr: 2 false
Middag,  kort nr 2, d�r nr: 3 true
Midnatt, kort nr 2, d�r nr: 3 false
Middag,  kort nr 2, d�r nr: 4 false
Midnatt, kort nr 2, d�r nr: 4 false
Middag,  kort nr 2, d�r nr: 5 false
Midnatt, kort nr 2, d�r nr: 5 false
Middag,  kort nr 2, d�r nr: 6 false
Midnatt, kort nr 2, d�r nr: 6 false
Middag,  kort nr 2, d�r nr: 7 true
Midnatt, kort nr 2, d�r nr: 7 false

Middag,  kort nr 3, d�r nr: 1 false
Midnatt, kort nr 3, d�r nr: 1 false
Middag,  kort nr 3, d�r nr: 2 true
Midnatt, kort nr 3, d�r nr: 2 false
Middag,  kort nr 3, d�r nr: 3 true
Midnatt, kort nr 3, d�r nr: 3 false
Middag,  kort nr 3, d�r nr: 4 false
Midnatt, kort nr 3, d�r nr: 4 false
Middag,  kort nr 3, d�r nr: 5 false
Midnatt, kort nr 3, d�r nr: 5 false
Middag,  kort nr 3, d�r nr: 6 false
Midnatt, kort nr 3, d�r nr: 6 false
Middag,  kort nr 3, d�r nr: 7 false
Midnatt, kort nr 3, d�r nr: 7 false

Middag,  kort nr 4, d�r nr: 1 true
Midnatt, kort nr 4, d�r nr: 1 false
Middag,  kort nr 4, d�r nr: 2 true
Midnatt, kort nr 4, d�r nr: 2 false
Middag,  kort nr 4, d�r nr: 3 false
Midnatt, kort nr 4, d�r nr: 3 false
Middag,  kort nr 4, d�r nr: 4 true
Midnatt, kort nr 4, d�r nr: 4 false
Middag,  kort nr 4, d�r nr: 5 true
Midnatt, kort nr 4, d�r nr: 5 false
Middag,  kort nr 4, d�r nr: 6 false
Midnatt, kort nr 4, d�r nr: 6 false
Middag,  kort nr 4, d�r nr: 7 false
Midnatt, kort nr 4, d�r nr: 7 false

*/