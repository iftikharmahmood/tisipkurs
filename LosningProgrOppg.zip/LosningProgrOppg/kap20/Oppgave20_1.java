/*
 * Oppgave20_1.java ST/EL 2006-01-24
 *
 * Denne oppgaven oppretter nye tr�der i det uendelige. Dette medf�rer at
 * etterhvert som programmet kj�rer, jo tregere g�r maskinen.
 */
import java.util.*;

public class Oppgave20_1 {
  public static void main(String[] args) {
    ArrayList<Tr�d> liste = new ArrayList<Tr�d>();
    while (true) {
      Tr�d tr�d = new Tr�d();
      tr�d.start();
      liste.add(tr�d);

      try {
        Thread.sleep(500);
      }
      catch(InterruptedException e) {

      }
    }
  }
}

/*
 * Klassen Tr�d
 */
class Tr�d extends Thread {
  public void run() {
    while (true) {

    }
  }
}
