/**
 * Oppgave10_5.java - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Tegner sirkler, kvadrater og rektangler tilfeldig plassert og i tilfeldige farger.
 * Alle figurene av samme type er like store.
 */

import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;

class Vindu extends JFrame {
  public static final int MAX_X = 1000;
  public static final int MAX_Y = 800;

  public Vindu(String tittel) {
    setTitle(tittel);
    setSize(MAX_X, MAX_Y); // bredde, h�yde
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Tegning tegningen = new Tegning();
    add(tegningen);
  }
}

class Tegning extends JPanel {
  private static final int ANT_FIGURER = 50;
  private static final int DIAMETER = 100;  // sirklene
  private static final int SIDE = 200;  // kvadratene
  private static final int BREDDE = 300;  // rektanglene
  private static final int H�YDE = 100; // rektanglene
  private static final Color[] farger = {Color.BLACK, Color.GRAY, Color.ORANGE, Color.YELLOW,
               Color.BLUE, Color.GREEN, Color.PINK, Color.CYAN, Color.LIGHT_GRAY,
               Color.RED, Color.DARK_GRAY, Color.MAGENTA, Color.WHITE};
  private static java.util.Random tallGen = new java.util.Random();

  public void paintComponent(Graphics tegneflate) {
    super.paintComponent(tegneflate);
    for (int i = 0; i < ANT_FIGURER; i++) {
      int fargeindeks = tallGen.nextInt(farger.length);  // trekker tilfeldig farge
      tegneflate.setColor(farger[fargeindeks]);
      int figurtype = tallGen.nextInt(3);  // trekker tilfeldig type figur
      System.out.println("Fargeindeks " + fargeindeks + ", figurtype: " + figurtype);
      switch (figurtype) {  // figurplasseringene er ogs� tilfeldige, se nedenfor
        case 0: // sirkel
          tegneflate.drawOval(tallGen.nextInt(Vindu.MAX_X - DIAMETER), tallGen.nextInt(Vindu.MAX_Y - DIAMETER), DIAMETER, DIAMETER);
          break;
        case 1: // kvadrat
          tegneflate.drawRect(tallGen.nextInt(Vindu.MAX_X - SIDE), tallGen.nextInt(Vindu.MAX_Y - SIDE), SIDE, SIDE);
          break;
        case 2:  // rektangel
          tegneflate.drawRect(tallGen.nextInt(Vindu.MAX_X - BREDDE), tallGen.nextInt(Vindu.MAX_Y - H�YDE), BREDDE, H�YDE);
          break;
        default:
          System.out.println("Feil! Hit skal det ikke v�re mulig � komme.");
          break;
      }
    }
  }
}

class Oppgave10_5 {
  public static void main(String[] args) {
    Vindu etVindu = new Vindu("Standardfargene i klassen Color");
    etVindu.setVisible(true);
  }
}