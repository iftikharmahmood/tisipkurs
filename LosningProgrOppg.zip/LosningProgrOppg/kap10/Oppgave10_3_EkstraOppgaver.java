/**
 * Oppgave10_3_EkstraOppgaver.java - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Filen inneholder tre klasser:
 * Vindu: En tegneflate med en tegning
 * Tegning: En tegning med fylte sirkler med streker mellom
 * TegnFlekkerMedLinjer: main()-metode som viser fram vinduet med tegningen
 */

import java.awt.*;
import javax.swing.*;
import java.util.Random;

class Vindu extends JFrame {
  public Vindu(String tittel) {
    setTitle(tittel);
    setSize(400, 300); // bredde, h�yde
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Tegning tegningen = new Tegning();
    add(tegningen);
  }
}

class Tegning extends JPanel {
  private static final int DIAMETER = 20;
  private static final int SENTRUM = DIAMETER / 2;
  private static final int ANT_STREKER = 10;
  private Random tallGen = new Random();
  private int maksXverdi;
  private int maksYverdi;

  /**
   * Ekstraoppgave 1: For at endringen skal vises p� figuren farges 1.sirkel og den nye linjen bl�.
   * Ekstraoppgave 2: En logiske variabel, fylt, styrer hvorvidt sirkelen skal v�re fylt eller ikke.
   */
  public void paintComponent(Graphics tegneflate) {
    super.paintComponent(tegneflate);
    maksXverdi = getWidth() - 1;
    maksYverdi = getHeight() - 1;
    boolean fylt = true; // ekstraoppgave 2
    int x = tallGen.nextInt(maksXverdi - DIAMETER);
    int y = tallGen.nextInt(maksYverdi - DIAMETER);
    int x1 = x; // Tar vare p� koordinatene til det f�rste punktet, ekstraoppgave 1
    int y1 = y;
    Color stdFarge = tegneflate.getColor();
    tegneflate.setColor(Color.BLUE); // f�rste sirkel er bl�
    tegneflate.fillOval(x, y, DIAMETER, DIAMETER);
    tegneflate.setColor(stdFarge);
    int teller = 0;
    while (teller < ANT_STREKER) {
      int forrigeX = x;
      int forrigeY = y;
      x = tallGen.nextInt(maksXverdi - DIAMETER);
      y = tallGen.nextInt(maksYverdi - DIAMETER);
      tegneflate.drawLine(forrigeX + SENTRUM, forrigeY + SENTRUM, x + SENTRUM, y + SENTRUM);
      if (fylt) {
        tegneflate.fillOval(x, y, DIAMETER, DIAMETER);
      } else {
        tegneflate.drawOval(x, y, DIAMETER, DIAMETER);
      }
      teller++;
      fylt = !fylt; // Ekstraoppgave 2, endrer verdien til den logiske variabelen
    }
    /* Tegner en linje mellom siste og f�rste sirkel */
    tegneflate.setColor(Color.BLUE); // linjen mellom siste og f�rste sirkel er bl�
    tegneflate.drawLine(x + SENTRUM, y + SENTRUM, x1 + SENTRUM, y1 + SENTRUM);
    tegneflate.setColor(stdFarge);
  }
}

class Oppgave10_3_EkstraOppgaver {
  public static void main(String[] args) {
    Vindu etVindu = new Vindu("Flekker med linjer");
    etVindu.setVisible(true);
  }
}