/**
 * Oppgave10_3.java  - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Filen inneholder tre klasser:
 * Vindu: En tegneflate med en tegning
 * Tegning: En tegning med fylte sirkler med streker mellom
 * TegnFlekkerMedLinjer: main()-metode som viser fram vinduet med tegningen
 */

import java.awt.*;
import javax.swing.*;
import java.util.Random;

class Vindu extends JFrame {
  public Vindu(String tittel) {
    setTitle(tittel);
    setSize(400, 300); // bredde, h�yde
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Tegning tegningen = new Tegning();
    add(tegningen);
  }
}

class Tegning extends JPanel {
  private static final int DIAMETER = 20;
  private static final int SENTRUM = DIAMETER / 2;
  private static final int ANT_STREKER = 10;
  private Random tallGen = new Random();
  private int maksXverdi;
  private int maksYverdi;

  public void paintComponent(Graphics tegneflate) {
    super.paintComponent(tegneflate);
    maksXverdi = getWidth() - 1;
    maksYverdi = getHeight() - 1;
    int x = tallGen.nextInt(maksXverdi - DIAMETER);
    int y = tallGen.nextInt(maksYverdi - DIAMETER);
    tegneflate.fillOval(x, y, DIAMETER, DIAMETER);
    int teller = 0;
    while (teller < ANT_STREKER) {
      int forrigeX = x;
      int forrigeY = y;
      x = tallGen.nextInt(maksXverdi - DIAMETER);
      y = tallGen.nextInt(maksYverdi - DIAMETER);
      tegneflate.drawLine(forrigeX + SENTRUM, forrigeY + SENTRUM, x + SENTRUM, y + SENTRUM);
      tegneflate.fillOval(x, y, DIAMETER, DIAMETER);
      teller++;
    }
  }
}

class Oppgave10_3 {
  public static void main(String[] args) {
    Vindu etVindu = new Vindu("Flekker med linjer");
    etVindu.setVisible(true);
  }
}