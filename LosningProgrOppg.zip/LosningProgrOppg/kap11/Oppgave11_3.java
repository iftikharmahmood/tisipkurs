/*
 * Oppgave11_3.java  - "Programmering i Java", 4.utgave - 2010-02-22
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen fra 1.utgave av boka (�r 2000).
 *
 * Denne oppgaven definerer en klasse Bok. Klientprogrammet oppretter tre
 * forskjellige b�ker, som s� benytter seg av metodene i klassen Bok for �
 * sammenlikne dem.
 */

class Oppgave11_3 {
  public static void main(String[] args) {

    /* Registrer et par b�ker. */
    Bok bok1 = new Bok("Hearts in Atlantis", "Stephen King", "Scribner", 1999, 523);
    Bok bok2 = new Bok("The Girl Who loved Tom Gordon", "Stephen King", "Pocked Books", 2000, 264);
    Bok bok3 = new Bok("False Memory", "Dean R. Koontz", "Bantam Doubleday Dell Pub", 1999, 627);

    /* Sammenlikn b�kene. */
    BokSammenlikner sammenlikner = new BokSammenlikner();
    javax.swing.JOptionPane.showMessageDialog(null, sammenlikner.sammenlikn(bok1, bok2)
                                                                                + sammenlikner.sammenlikn(bok1, bok3)
                                                                                + sammenlikner.sammenlikn(bok2, bok3));
  }
}

/**
 * Klasse som sammenlikner to b�ker og legger resultatet i en streng klar for utskrift.
 */
class BokSammenlikner {
  public String sammenlikn(Bok bok1, Bok bok2) {
    String resultat = "Sammenlikner\n" + bok1.toString() + "\nmed\n" + bok2.toString() + "\nResultat:\n";

    int forhold = bok1.sammenliknUtgivelses�r(bok2);
    if (forhold < 0) {
      resultat += bok1.getNavn() + " utgitt " + (-forhold) + " �r f�r " + bok2.getNavn() + "\n";
    } else if (forhold == 0) {
      resultat += bok1.getNavn() + " utgitt samme �r som " + bok2.getNavn() + "\n";
    } else {
      resultat += bok1.getNavn() + " utgitt " + forhold + " �r etter " + bok2.getNavn() + "\n";
    }

    forhold = bok1.sammenliknSideantall(bok2);
    if (forhold < 0) {
      resultat += bok1.getNavn() + " har " + (-forhold) + " mindre sider enn " + bok2.getNavn() + "\n";
    } else if (forhold == 0) {
      resultat += bok1.getNavn() + " har samme antall sider som " + bok2.getNavn() + "\n";
    } else {
      resultat += bok1.getNavn() + " har " + forhold + " flere sider enn " + bok2.getNavn() + "\n";
    }

    forhold = bok1.sammenliknForlag(bok2);
    if (forhold != 0) {
      resultat += bok1.getNavn() + " har annet forlag enn " + bok2.getNavn() + "\n";
    } else {
      resultat += bok1.getNavn() + " har samme forlag som " + bok2.getNavn() + "\n";
    }

    forhold = bok1.sammenliknForfatter(bok2);
    if (forhold != 0) {
      resultat += bok1.getNavn() + " har annen forfatter enn " + bok2.getNavn() + "\n";
    } else {
      resultat += bok1.getNavn() + " har samme forfatter som " + bok2.getNavn() + "\n";
    }

    return resultat + "\n";
  }
}

/**
 * Klassen Bok
 */
class Bok {
  private String navn;
  private String forfatter;
  private String forlag;
  private int utgivelses�r;
  private int sideantall;

  public Bok(String navn, String forfatter, String forlag, int utgivelses�r, int sideantall) {
    this.navn = navn;
    this.forfatter = forfatter;
    this.forlag = forlag;
    this.utgivelses�r = utgivelses�r;
    this.sideantall = sideantall;
  }

  public String getNavn() {
    return navn;
  }

  public String getForfatter() {
    return forfatter;
  }

  public String getForlag() {
    return forlag;
  }

  public int getUtgivelses�r() {
    return utgivelses�r;
  }

  public int getSideantall() {
    return sideantall;
  }

  public int sammenliknUtgivelses�r(Bok bok) {
    return utgivelses�r - bok.getUtgivelses�r();
  }

  public int sammenliknSideantall(Bok bok) {
    return sideantall - bok.getSideantall();
  }

  public int sammenliknForfatter(Bok bok) {
    return forfatter.compareTo(bok.getForfatter());
  }

  public int sammenliknForlag(Bok bok) {
    return forlag.compareTo(bok.getForlag());
  }

  public String toString() {
    return navn + " av " + forfatter + ", " + sideantall + " sider, utgitt �r " +  utgivelses�r + " p� forlaget " + forlag;
  }
}

/* Utskriftvindu:
Sammenlikner
Hearts in Atlantis av Stephen King, 523 sider, utgitt �r 1999 p� forlaget Scribner
med
The Girl Who loved Tom Gordon av Stephen King, 264 sider, utgitt �r 2000 p� forlaget Pocked Books
Resultat:
Hearts in Atlantis utgitt 1 �r f�r The Girl Who loved Tom Gordon
Hearts in Atlantis har 259 flere sider enn The Girl Who loved Tom Gordon
Hearts in Atlantis har annet forlag enn The Girl Who loved Tom Gordon
Hearts in Atlantis har samme forfatter som The Girl Who loved Tom Gordon

Sammenlikner
Hearts in Atlantis av Stephen King, 523 sider, utgitt �r 1999 p� forlaget Scribner
med
False Memory av Dean R. Koontz, 627 sider, utgitt �r 1999 p� forlaget Bantam Doubleday Dell Pub
Resultat:
Hearts in Atlantis utgitt samme �r som False Memory
Hearts in Atlantis har 104 mindre sider enn False Memory
Hearts in Atlantis har annet forlag enn False Memory
Hearts in Atlantis har annen forfatter enn False Memory

Sammenlikner
The Girl Who loved Tom Gordon av Stephen King, 264 sider utgitt �r 2000 p� forlaget Pocked Books
med
False Memory av Dean R. Koontz, 627 sider, utgitt �r 1999 p� forlaget Bantam Doubleday Dell Pub
Resultat:
The Girl Who loved Tom Gordon utgitt 1 �r etter False Memory
The Girl Who loved Tom Gordon har 363 mindre sider enn False Memory
The Girl Who loved Tom Gordon har annet forlag enn False Memory
The Girl Who loved Tom Gordon har annen forfatter enn False Memory
*/