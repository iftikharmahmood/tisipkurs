/**
 * Oppgave11_4_meny.java  - "Programmering i Java", 4.utgave - 2010-02-22
 * Menystyrt klientprogram til oppgave 11_4.
 */
import static javax.swing.JOptionPane.*;

/**
 * Klasse for brukerkommunikasjon.
 */
class DatoBGS {

  /* Konstanter til bruk i menyen */
  private final String[] ALTERNATIVER = {"Finn dagens dato", "Finn datoen x dager fram i tid fra en annen dato",
    "Sammenlign to datoer", "Antall dager mellom to datoer", "Antall hele �r mellom to datoer", "Avslutt"};
  private final int DAGENS_DATO = 0;   // tallverdiene svarer til indeksen i tabellen over
  private final int NY_DATO = 1;
  private final int SMLGN_DATOER = 2;
  private final int ANT_DG_MELLOM = 3;
  private final int ANT_�R_MELLOM = 4;
  private final int AVSLUTT = 5;

  /**
   * Viser menyen som en liste.
   * Metoden returnerer brukerens valg som en indeks i tabellen ALTERNATIVER.
   * Hvis brukeren vil avslutte, returneres en negativ verdi.
   */
  public int lesValg() {
    String valgtObjekt = (String) showInputDialog(null, "Gj�r et valg", "Datoprogram", DEFAULT_OPTION,
                                   null, ALTERNATIVER, ALTERNATIVER[0]);
    int valg = 0;
    if (valgtObjekt == null) {
      valg = -1;  // avslutter
    }
    for (int i = 0; i < ALTERNATIVER.length; i++) {
      if (valgtObjekt.equals(ALTERNATIVER[i])) {
        valg = i;
      }
    }
    if (valg == AVSLUTT) {
      valg = -1; // avslutter
    }
    return valg;
  }

  /**
   * Hovedflyt for utf�relse av valgt oppgave.
   */
  public void utf�rValgtOppgave(int valg) {
      switch (valg) {
      case DAGENS_DATO:
        dagensDato();
        break;
      case NY_DATO:
        nyDato();
        break;
      case SMLGN_DATOER:
        smlgnDatoer();
        break;
      case ANT_DG_MELLOM:
        antDgMellom();
        break;
      case ANT_�R_MELLOM:
        ant�rMellom();
        break;
      default:
        break;
    }
  }

  /**
   * Finner dagens dato.
   *
   * Innlesing fra brukeren: Ingen.
   * Utskrift: Dagens dato.
   */
  public void dagensDato() {
    Dato dagensDato = new Dato();
    showMessageDialog(null, "Dagens dato er " + dagensDato.format() + ".");
  }

  /**
   * Finner datoen x dager fram i tid fra en gitt dato.
   * Innlesing fra brukeren: Datoen og x.
   * Utskrift: Den nye datoen.
   */
  public void nyDato() {
    Dato startDato = lesDato("Oppgi startdatoen");
    int antDager = lesHeltall("Hvor mange dager skal vi legge til? ");
    String utskrift = "Dato " + startDato.format() + " + " + antDager + " gir ny dato ";
    Dato nyDato = startDato.nyDato(antDager);
    showMessageDialog(null, utskrift + nyDato.format() + ".");
  }

  /**
   * Sammenligner to datoer.
   *
   * Innlesing fra brukeren: To datoer.
   * Utskrift: Hvorvidt den ene er f�r, lik eller etter den andre.
   */
  public void smlgnDatoer() {
    Dato dato1 = lesDato("Oppgi den f�rste datoen");
    Dato dato2 = lesDato("Oppgi den andre datoen");
    int res = dato1.compareTo(dato2);
    String utskrift = "Dato1: " + dato1.format() + ", dato2: " + dato2.format() + ". ";
    if (res < 0) {
      utskrift += "Den f�rste datoen ligger foran den andre datoen i tid.";
    } else if (res > 0) {
      utskrift += "Den f�rste datoen ligger etter den andre datoen i tid.";
    } else {
      utskrift += "Datoene er like.";
    }
    showMessageDialog(null, utskrift);
  }

  /**
   * Antall dager mellom to datoer.
   *
   * Innlesing fra brukeren: De to datoene.
   * Utskrift: Antall dager mellom datoene.
   */
  public void antDgMellom() {
    Dato dato1 = lesDato("Oppgi den f�rste datoen");
    Dato dato2 = lesDato("Oppgi den andre datoen");
    String utskrift = dato2.format() + " - " + dato1.format() + " blir ";
    int antDager = dato1.dagerForskjell(dato2);
    showMessageDialog(null, utskrift + antDager + " dager.");
  }

  /**
   * Antall hele �r mellom to datoer.
   *
   * Innlesing fra brukeren: De to datoene.
   * Utskrift: Antall hele �r mellom datoene.
   */
  public void ant�rMellom() {
    Dato dato1 = lesDato("Oppgi den f�rste datoen");
    Dato dato2 = lesDato("Oppgi den andre datoen");
    String utskrift = "Antall hele �r fra " + dato1.format() + " til " + dato2.format() + " er ";
    int ant�r = dato1.antHele�rForskjell(dato2);
    showMessageDialog(null, utskrift + ant�r  + ".");
  }

  /*
   * Hjelpemetode. Leser inn et heltall. Unntaksh�ndtering, se kapittel 15.1.
   */
  private int lesHeltall(String ledetekst) {
    int tall = 0;
    boolean ok = false;
    String melding = ledetekst;
    do {
      String tallLest = showInputDialog(melding);
      try {
        tall = Integer.parseInt(tallLest);
        ok = true;
      } catch (NumberFormatException e) {
        melding = "Ugyldig heltall. Pr�v p� nytt. ";
      }
    } while (!ok);
    return tall;
  }

  /*
   * Hjelpemetode. Leser inn en dato. Unntaksh�ndtering, se kapittel 15.1
   */
  private Dato lesDato(String ledetekst) {
    Dato dato = null;
    boolean ok = false;
    String melding = ledetekst + " (format: " + Dato.DATOSTRENG + "): ";
    do {
      String datoLest = showInputDialog(melding);
      try {
        dato = new Dato(datoLest);
        ok = true;
      } catch (java.text.ParseException e) {
        melding = "Ugyldig dato. Pr�v p� nytt. Format: " + Dato.DATOSTRENG;
      }
    } while (!ok);
    return dato;
  }
}

class Oppgave11_4_meny {
  public static void main(String[] args) {
    DatoBGS bgs = new DatoBGS();
    int valg = bgs.lesValg();
    while (valg >= 0) {
      bgs.utf�rValgtOppgave(valg);
      valg = bgs.lesValg();
    }
  }
}