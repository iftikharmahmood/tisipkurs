/**
 * Oppgave11_2.java  - "Programmering i Java", 4.utgave - 2010-02-22
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen fra 1.utgave av boka (�r 2000).
 *
 * Et vindu med en enkel plakat.
 */
import java.awt.*;
import java.util.Random;
import javax.swing.*;
import static javax.swing.JOptionPane.*;

class Vindu extends JFrame {
  public Vindu(String tittel, String[] tekster) {
    setTitle(tittel);
    setSize(500, 250); // bredde, h�yde
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Plakat plakat = new Plakat(tekster);
    add(plakat);
  }
}

/**
 * Klassen Plakat
 *
 * En plakat inneholder et bestemt antall linjer med tekst. N�r paintComponent() kalles
 * i en plakat, sendes disse kallene videre til Linje-objektene. Med
 * andre ord: Plakaten samardbeider med linje-objektene om tegningen.
 */
class Plakat extends JPanel {
  private Linje[] linjer;
  public Plakat(String[] tekster) {
    linjer = new Linje[tekster.length];
    for (int i = 0; i < linjer.length; i++) {
      linjer[i] = new Linje();
      linjer[i].setLinjenr(i + 1);
      linjer[i].setTekst(tekster[i]);
    }
  }

  public void paintComponent(Graphics vindu) {
    super.paintComponent(vindu);
    for (int i = 0; i < linjer.length; i++) {
      linjer[i].paintComponent(vindu);
    }
  }
}

/**
 * Klassen Linje med tekst, linjenr, font og farge
 */
class Linje extends JPanel {
  private String tekst;
  private int linjenr;
  private Font font;
  private Color farge;

  private static final int MAKS_STR = 30;
  private static final Random randGen = new Random(17);

  /* Finner alle tilfeldige skrifttyper. */
  private static final GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
  private static final Font[] alleFonter = env.getAllFonts();

  public Linje() {
    /*
     * Generer en kraftig farge (algoritme: ST)
     * En mer primitiv metode er � bare trekke tall i intervallet [0..255] for hver av komponentene.
     * Enda mer primitivt er det � bruke standardfargene som det er gjort for eksempel i oppgave 5 side 346.
     */
    double r = randGen.nextDouble();
    double g = randGen.nextDouble();
    double b = randGen.nextDouble();
    double min = Math.min(r, Math.min(g, b));
    double max = Math.max(r, Math.max(g, b));
    r = (r - min) / (max - min);
    g = (g - min) / (max - min);
    b = (b - min) / (max - min);
    farge = new Color((float) r, (float) g, (float) b);

    int indeks = randGen.nextInt(alleFonter.length); // Finner et tilfeldig tall mellom 0 og antallet fonter.
    int st�rrelse = (int) (MAKS_STR * (0.5 + 0.5 * randGen.nextDouble())); // En passe st�rrelse.
    font = new Font(alleFonter[indeks].getName(), Font.PLAIN, st�rrelse);
  }

  public void setTekst(String nyTekst) {
    tekst = nyTekst;
  }

  public void setLinjenr(int nyttLinjenr) {
    linjenr = nyttLinjenr;
  }

  public void paintComponent(Graphics vindu) {
    if (tekst == null) {
      return;
    }
    vindu.setFont(font);
    vindu.setColor(farge);
    vindu.drawString(tekst, 0, linjenr * MAKS_STR);
  }
}

class Oppgave11_2 {
  public static void main(String[] args) {
    String antLest = showInputDialog("Antall linjer: ");
    int antLinjer = Integer.parseInt(antLest);
    String[] tekster = new String[antLinjer];
    for (int i = 0; i < tekster.length; i++) {
      tekster[i] = showInputDialog("Skriv linje " + (i + 1) + ": ");
    }
    Vindu etVindu = new Vindu("En plakat", tekster);
    etVindu.setVisible(true);
  }
}
