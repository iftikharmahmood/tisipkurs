/**
 * Oppgave12_2.java  - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Filen inneholder tre klasser:
 * Transaksjon med dato og bel�p.
 * Konto med kontonummer, navn, saldo og transaksjoner.
 * Klientprogram iht. oppgaveteksten: Oppretter en konto og registrerer transaksjoner
 * lest inn fra brukeren. Transaksjonsoversikt skrives ut for hver ny transaksjon.
 * Brukeren kan s� henet ut transaksjoner for en gitt periode.
 *
 * Datoer angis p� formen ����mmdd. Det foretas ingen kontroll av at datoene er gyldige.
 */

import static javax.swing.JOptionPane.*;

class Transaksjon  implements Comparable<Transaksjon> {
  private final int dato;  // format ����mmdd
  private final double bel�p;   // positivt hvis innskudd, negativt hvis uttak

  public Transaksjon(int dato, double bel�p) {
    this.dato = dato;
    this.bel�p = bel�p;
  }

  public int compareTo(Transaksjon denAndre) {
    System.out.println(denAndre);
    return dato - denAndre.dato;
  }

  public int getDato() {
    return dato;
  }

  public double getBel�p() {
    return bel�p;
  }

  public String toString() {
    java.util.Formatter f = new java.util.Formatter();
    f.format("%.2f", bel�p);
    return "Dato: " + dato + ", bel�p: NOK " + f.toString() + ".";
  }
}

class Konto {
  private final String kontonr;
  private final String navn;
  private double saldo;
  private Transaksjon[] transaksjoner = new Transaksjon[3]; // liten for testform�l, utvides hvis behov
  private int antTransaksjoner = 0;

  public Konto(String kontonr, String navn, double saldo) {
    this.kontonr = kontonr;
    this.navn = navn;
    this.saldo = saldo;
  }

  public String getKontonr() {
    return kontonr;
  }

  public double getSaldo() {
    return saldo;
  }

  public String getNavn() {
    return navn;
  }

  /**
   * Metoden returnerer false dersom det ikke er nok penger p� kontoen.
   * Ellers registreres den nye transaksjonen, og saldoen oppdateres.
   */
  public boolean registrerNyTransaksjon(int dato, double bel�p) {
    if (bel�p < 0 && saldo < -bel�p) {
      return false;   // RETUR, ikke nok penger p� konto
    }
    if (antTransaksjoner == transaksjoner.length) {
      utvidTabell();
    }
    transaksjoner[antTransaksjoner] = new Transaksjon(dato, bel�p);
    antTransaksjoner++;
    saldo += bel�p;
    return true;
  }

  private void utvidTabell() {
    Transaksjon[] nyTab = new Transaksjon[antTransaksjoner + 5];
    System.arraycopy(transaksjoner, 0, nyTab, 0, antTransaksjoner);
    transaksjoner = nyTab;
  }

  /**
   * Metoden returnerer alle transaksjonene innenfor en tidsperiode.
   * Transaksjonene er sortert etter dato.
   */
  public Transaksjon[] finnAlleTransaksjoner(int fraOgMedDato, int tilOgMedDato) {
    /* Lager f�rst en tabell med plass til alle transaksjonene */
    Transaksjon[] transFunnet = new Transaksjon[transaksjoner.length];
    int antall = 0;
    for (int i = 0; i < antTransaksjoner; i++) {
      int tDato = transaksjoner[i].getDato();
      if (tDato >= fraOgMedDato && tDato <= tilOgMedDato) {
        transFunnet[antall] = transaksjoner[i];
        antall++;
      }
    }
    /* Lager n� en tabell som har eksakt riktig st�rrelse, kopierer og sorterer*/
    Transaksjon[] trans = new Transaksjon[antall];
    System.arraycopy(transFunnet, 0, trans, 0, antall);
    java.util.Arrays.sort(trans);  // compareTo() blir brukt
    return trans;
  }

  public String toString() {
    java.util.Formatter f = new java.util.Formatter();
    f.format("%.2f", saldo);
    String res = "Kontoutskrift, kontonr " + kontonr + "\nNavn: " + navn + "\nSaldo: " + f.toString()
                  +  "\nAntall transaksjoner: " + antTransaksjoner + "\n\n";
    for (int i = 0; i < antTransaksjoner; i++) {
      res += transaksjoner[i] + "\n";
    }
    return res;
  }
}

/* Et enkelt program som tester klassen Konto */
class Oppgave12_2 {
  public static void main(String[] args) {
    String kontonr = showInputDialog("Oppgi kontonr: ");
    String navn = showInputDialog("Oppgi navn: ");
    double startSaldo = Double.parseDouble(showInputDialog("Oppgi startsaldoen: "));

    Konto kontoen = new Konto(kontonr, navn, startSaldo);

    String datoLest = showInputDialog("Oppgi transaksjonsdato (avslutt med Esc): ");
    while (datoLest != null) {
      int dato = Integer.parseInt(datoLest);
      double bel�p = Double.parseDouble(showInputDialog("Oppgi bel�p: "));
      if (kontoen.registrerNyTransaksjon(dato, bel�p)) {
        double saldo = kontoen.getSaldo();
        java.util.Formatter f = new java.util.Formatter();
        f.format("%.2f", saldo);
        showMessageDialog(null, "Transaksjon godkjent, ny saldo " + f.toString());
      } else {
        showMessageDialog(null, "Ikke penger nok p� kontoen.");
      }
      System.out.println("Status:\n" + kontoen);
      datoLest = showInputDialog("Oppgi transaksjonsdato (avslutt med Esc): ");
    }

    datoLest = showInputDialog("Oppgi trans.periode, start (avslutt med Esc):");
    while (datoLest != null) {
      int fraDato = Integer.parseInt(datoLest);
      int tilDato = Integer.parseInt(showInputDialog("Oppgi trans.periode, slutt: "));
      Transaksjon[] alleTrans = kontoen.finnAlleTransaksjoner(fraDato, tilDato);
      String utskrift = "Transaksjoner i perioden [" + fraDato + ", " + tilDato + "]:\n";
      for (int i = 0; i < alleTrans.length; i++) {
        utskrift += alleTrans[i].toString() + "\n";
      }
      showMessageDialog(null, utskrift);
      datoLest = showInputDialog("Oppgi trans.periode, start (avslutt med Esc):");
    }
  }
}