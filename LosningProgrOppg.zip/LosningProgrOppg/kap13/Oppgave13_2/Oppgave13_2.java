/**
 * Oppgave13_2.java  - "Programmering i Java", 4.utgave - 2011-02-03
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen og videreutviklet av Vidar Vestnes
 * for tidligere utgaver av boka.
 *
 * L�sningen inkluderer ekstraoppgaven.
 *
 * Denne oppgaven beskriver et modifiserbart vareregister. Utskrift via
 * toString() i register gir en alfabetisk oversikt.
 */
import java.util.*;
import static javax.swing.JOptionPane.*;
import mittBibliotek.DataLeser;

/**
 * Klassen Register
 */
class Register {
  private ArrayList<Vare> liste = new ArrayList<Vare>();

  public int finnAntallVarer() {
    return liste.size();
  }

  /**
   * Henter ut vare med et bestemt nummer.
   * Returnerer null hvis vare med dette nummer ikke fins.
   */
  public Vare finnVare(int varenr) {
    for (Vare enVare : liste) {
      if (enVare.getVarenr() == varenr) {
        return enVare;
      }
    }
    return null;
  }

  /**
   * Registrerer ny vare.
   * Returnerer false hvis vare med dette nummer allerede er registrert.
   */
  public boolean regNyVare(Vare vare) {
    if (finnVare(vare.getVarenr()) != null)  {
      return false;  // RETUR, vare med dette nr fins fra f�r
    }
    liste.add(vare);
    return true;
  }

  /**
   * Fjerner en vare fra registerer.
   * Returnerer false hvis vare med dette nummer allerede er registrert.
   */
  public boolean fjernVare(int varenr) {
    for (int i = 0; i < liste.size(); i++) {
      Vare vare = liste.get(i);
      if (vare.getVarenr() == varenr) {
        liste.remove(i);
        return true;
      }
    }
    return false;
  }

  /**
   * Registrerer endring i varebeholdningen.
   * Returnerer -1 hvis vare med dette nummer allerede er registrert.
   * Returnerer 0 hvis ikke nok p� lager. Endringen registreres ikke.
   * Returnerer 1 hvis OK.
   */
  public int oppdaterVarebeholdning(int varenr, int antSolgt){
    Vare vare = finnVare(varenr);
    if (vare == null) {
      return -1;
    } else {
      if (vare.endreLagerbeholdning(antSolgt)) {
        return 1;
      } else {
        return 0;
      }
    }
  }

  /**
   * Lager bestillingsliste.
   */
  public String lagBestillingsliste() {
    String rapport = "";
    for (Vare enVare : liste) {
      double mengde = enVare.finnBestKvantum();
      if (mengde > 0.000001) {
        rapport += enVare.getVarenavn() + " bestill : "+ mengde;
      }
    }
    return rapport;
  }

  public String toString() {
    ArrayList<String> tabell = new ArrayList<String>();
    for (Vare enVare : liste) {
      tabell.add(enVare.toString());
    }
    java.text.Collator koll = java.text.Collator.getInstance(); // norsk sortering, se side 407-408
    StringBuilder buffer = new StringBuilder(); // se side 278
    while (tabell.size() != 0) {
      int minst = 0;
      for (int i = 1; i < tabell.size(); i++) {
        String varelinje = tabell.get(i);
        if (koll.compare(varelinje, tabell.get(minst)) < 0) minst = i;
      }
      buffer.append(tabell.get(minst) + "\n");
      tabell.remove(minst);
    }
    return buffer.toString();
  }
}

/**
 * Klasse som inneholder kommunikasjonen mellom register-objektet og brukeren.
 */
class VareRegBGS {
  private Register register;

  public VareRegBGS(Register startRegister) {
    register = startRegister;
  }

  /**
   * Registrer en ny vare.
   */
  public void regNyVare() {
    String varenavn = DataLeser.lesTekst("Varenavn: ");
    int varenr = DataLeser.lesHeltall("Varenr: ");
    double pris = DataLeser.lesDesimaltall("Pris: ");
    int antall = DataLeser.lesHeltall("Antall p� lager: ");
    int minGrense = DataLeser.lesHeltall("Laveste lagergrense: ");

    if (register.regNyVare(new Vare(varenavn, varenr, pris, antall, minGrense))){
      showMessageDialog(null, "Ny vare registrert.");
    } else {
      showMessageDialog(null, "Varenr eksisterer fra f�r.");
    }
  }

  /**
   * Selger et vist antall av en vare.
   */
  public void regSalg() {
    int varenr = DataLeser.lesHeltall("Varenr: ");
    int endring = DataLeser.lesHeltall("Antall: ");
    int status = register.oppdaterVarebeholdning(varenr, endring);

    if (status < 0) {
      showMessageDialog(null, "Ugyldig varenr");
    } else if (status == 0) {
      showMessageDialog(null, "Ikke nok p� lager");
    } else {
      showMessageDialog(null, "Varebeholdning oppdatert til " + register.finnVare(varenr).getP�Lager());
    }
  }

  /**
   * Fjerner en vare.
   */
  public void fjernVare() {
    int varenr   = DataLeser.lesHeltall("Varenr:");
    if (register.fjernVare(varenr)) {
      showMessageDialog(null, "Vare fjernet.");
    } else {
      showMessageDialog(null, "Illegalt varenr.");
    }
  }

  /**
   * Bestiller varer.
   */
  public void bestillVare() {
    showMessageDialog(null, "Bestilte varer \n" + register.lagBestillingsliste());
  }

  /**
   * Viser registrerte varer.
   */
  public void visVarer() {
    showMessageDialog(null, "Registrerte varer \n" + register);
  }
}

/**
 * Klassen som inneholder main()
 */
public class Oppgave13_2 {
  public static void main(String[] args) {
    final String[] ALTERNATIV = { "Registrer ny vare",
                                  "Oppdater varebeholdning",
                                  "Slett vare",
                                  "Bestill",
                                  "Vis varer",
                                  "Avslutt" };
    final int NY = 0;
    final int SELG = 1;
    final int SLETT = 2;
    final int BESTILL = 3;
    final int VIS = 4;
    final int AVSLUTT = 5;

    /* Oppretter et register. */
    Register register = new Register();

    /* Legger til 2 varer - for � ha noe � starte med. */
    register.regNyVare(new Vare("Anir vertikal mus PS/2 kontakt", 1, 399.0, 20,10));
    register.regNyVare(new Vare("Logitech Cordless Mousemann Wheel PS2", 2, 549.0, 50, 20));

    /* Oppretter objekt som tar seg av brukerkommunikasjonen. */
    VareRegBGS bgs = new VareRegBGS(register);

    int valg = AVSLUTT;
    do {
      String valget = (String) showInputDialog(null, "Velg et alternativ:", "Hovedmeny",
                       DEFAULT_OPTION, null, ALTERNATIV, ALTERNATIV[0]);
      if (valget == null) {
        valg = AVSLUTT;
      } else {
        for (int i = 0; i < ALTERNATIV.length; i++) {
          if (valget.equals(ALTERNATIV[i])) {
            valg = i;
            break;
          }
        }
      }
      switch(valg) {
        case NY:
          bgs.regNyVare();
          break;
        case SELG:
          bgs.regSalg();
          break;
        case SLETT:
          bgs.fjernVare();
          break;
        case BESTILL:
          bgs.bestillVare();
          break;
        case VIS:
          bgs.visVarer();
          break;
        default:
          break;
      }
    } while (valg != AVSLUTT);
  }
}

/* Eksempel p� kj�ring:
***Inndata: F�lgende er valgt: Registrer ny vare.
***Inndata: Varenavn: Microsoft Cordless Wheel mus PS/2
***Inndata: Varenr: 3
***Inndata: Pris: 289.0
***Inndata: Antall p� lager: 50
***Inndata: Laveste lagergrense: 20
Ny vare registrert.

***Inndata: F�lgende er valgt: Oppdater varebeholdning.
***Inndata: Varenr: 2
***Inndata: Antall: -35
Varebeholdning oppdatert til 15.

***Inndata: F�lgende er valgt: Slett vare.
***Inndata: Varenr: 1
Vare fjernet.

***Inndata: F�lgende er valgt: Bestill.
Bestilte varer
Logitech Cordless Mousemann Wheel PS2 bestilt: 80

***Inndata: F�lgende er valgt: Vis varer.
Registrerte varer
2: Logitech Cordless Mousemann Wheel PS2(2), kr 549,00. Antall p� lager: 15, nedre grense for bestilling: 20
3: Microsoft Cordless Wheel mus PS/2(3), kr 289.00. Antall p� lager: 50, nedre grense for bestilling: 20

***Inndata: F�lgende er valgt: Avsutt.
*/