/**
 * Vare.java
 * Modifisert utgave av klassen Vare, side 186.
 */

class Vare {
  public static final double MOMS = 24.0;
  public static final double MOMSFAKTOR = 1.0 + MOMS / 100.0;
  public static final int BESTILLINGSFAKTOR = 4;

  private final String varenavn;
  private final int varenr;
  private double pris; // pris pr. enhet
  private int p�Lager;
  private int grense; // for bestilling

  public Vare(String varenavn, int varenr, double pris, int p�Lager, int grense) {
    this.varenavn = varenavn;
    this.varenr = varenr;
    this.pris = pris;
    this.p�Lager = p�Lager;
    this.grense = grense;
  }

  public Vare(String varenavn, int varenr, int p�Lager, int grense) {
    this(varenavn, varenr, 0.0, p�Lager, grense);
  }

  public String getVarenavn() {
    return varenavn;
  }

  public int getVarenr() {
    return varenr;
  }

  public double getPris() {
    return pris;
  }

  public void setPris(double pris) {
    this.pris = pris;
  }

  public int getGrense() {
    return grense;
  }

  public void setGrense(int nyGrense) {
    grense = nyGrense;
  }

  public int getP�Lager() {
    return p�Lager;
  }

  public void setP�Lager(int nyP�Lager) {
    p�Lager = nyP�Lager;
  }

  public int finnBestKvantum() {
    return (p�Lager < grense) ? BESTILLINGSFAKTOR * grense : 0;
  }

  /**
   * Endring av lagerbeholdning.
   * Den kan v�re positiv eller negativ. Men det er ikke
   * mulig � ta ut mer enn det som fins p� lager. Hvis klienten
   * pr�ver p� det, vil metoden returnere false, og intet uttak gj�res.
   */
  public boolean endreLagerbeholdning(int endring) {
    if (p�Lager + endring < 0) {
      return false;
    } else {
      p�Lager += endring;
      return true;
    }
  }

  public String toString() {
    java.util.Formatter f = new java.util.Formatter();
    f.format("%.2f", pris);
    return varenr + ": " + varenavn + ", pris pr. enhet kr " + f.toString() + " u.moms.\n"
                         + "Antall p� lager: " + p�Lager + ", nedre grense for bestilling: " + grense + ".";
  }
}