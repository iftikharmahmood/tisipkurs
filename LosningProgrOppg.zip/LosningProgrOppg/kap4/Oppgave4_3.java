/**
 * Oppgave4_3.java - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Program som skriver ut tallverdiene for et intervall av tegn.
 *
 */
import static javax.swing.JOptionPane.*;
class Oppgave4_3 {
  public static void main(String[] args) {
    String startLest = showInputDialog("Oppgi nedre grense som ett tegn: ");
    String sluttLest = showInputDialog("Oppgi nedre grense som ett tegn: ");
    char start = startLest.charAt(0);
    char slutt = sluttLest.charAt(0);
    if (start <= slutt) {
      String res = ""; // bygger opp resultat som kan vises i dialogboks
      for (char tegn = start; tegn <= slutt; tegn++) {
        res += "Tegnet " + tegn + " har tallverdien " + (int) tegn + ".\n";
      }
      showMessageDialog(null, res);
    } else {
      showMessageDialog(null, "Slutt-tegnet (" + slutt + ") ligger foran start-tegnet (" + start + ") i rekkef�lge. Avslutter.");
    }
  }
}

/* Kj�ring av programmet:
Tegnet 0 har tallverdien 48.
Tegnet 1 har tallverdien 49.
Tegnet 2 har tallverdien 50.
Tegnet 3 har tallverdien 51.
Tegnet 4 har tallverdien 52.
Tegnet 5 har tallverdien 53.
Tegnet 6 har tallverdien 54.
Tegnet 7 har tallverdien 55.
Tegnet 8 har tallverdien 56.
Tegnet 9 har tallverdien 57.
*/