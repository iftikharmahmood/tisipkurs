/*
 * Oppgave24_4.java ST/EL 2006-01-20
 *
 */
import java.sql.*;
import static javax.swing.JOptionPane.*;

public class Oppgave24_4 {
  public static void main(String[] args) throws Exception {

    /* Oppretter kontakt med databasen. */
    String databasedriver = "oracle.jdbc.driver.OracleDriver";
    Class.forName(databasedriver);

    String brukernavn = showInputDialog("Brukernavn:");
    String passord = showInputDialog("Passord:");

    String databasenavn = "jdbc:oracle:thin:@oracle.stud.aitel.hist.no:1521:oracle";
    Connection forbindelse = DriverManager.getConnection(databasenavn, brukernavn, passord);

    /* Oppretter et setningsobjekt. */
    Statement setning = forbindelse.createStatement();

    /* Utf�rer et SQL query. */
    String sql = showInputDialog("SQL:");
    while (sql != null) {
      System.out.println("Statement:\t" + sql);
      try {
        if (sql.length() < 6 || !sql.substring(0, 6).equalsIgnoreCase("select"))
          System.out.println("Resultat:\t" + setning.executeUpdate(sql));
        else {
          ResultSet res = setning.executeQuery(sql);

          ResultSetMetaData md = res.getMetaData();
          int columns = md.getColumnCount();

          StringBuffer buf = new StringBuffer(); // Se online API-dok.
          for (int i = 1; i <= columns; i++) {
            buf.append(md.getColumnLabel(i) + "\t");
          }
          System.out.println("Resultat:\n" + buf.toString());

          while (res.next()) {
            buf = new StringBuffer(); // Se online API-dok.
            for (int i = 1; i <= columns; i++) {
              buf.append(res.getObject(i) + "\t");
            }
            System.out.println(buf.toString());
          }
        }
      } catch(SQLException e) {
        System.out.println(e.toString());
      }
      sql = showInputDialog("SQL:");
    }

    /* Lukker forbindelsen. */
    forbindelse.close();
  }
}