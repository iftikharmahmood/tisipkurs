/*
 * lagDatabase.java EL 2006-01-17
 *
 * Programmet lager databasen etter f�lgende script:
 *
 *    create table bok(
 *        isbn varchar(50) primary key,
 *        forfatter  varchar(50) not null,
 *        tittel varchar(50) not null,
 *        reservert varchar(50))      // verdien null dersom ikke reservert
 *
 *    create table eksemplar(
 *        isbn varchar(50) not null,
 *        eksnr integer not null,
 *        laant_av varchar(50),       // verdien null dersom ikke l�nt ut
 *        primary key(isbn, eksnr),
 *        foreign key (isbn) references bok)
 *
 * Meget primitiv unntaksh�ndtering i dette programmet.
 */
import java.sql.*;
import static javax.swing.JOptionPane.*;
class lagDatabase {
  public static void main(String[] args) throws Exception {
    Class.forName(Databasekonstanter.dbDriver);
    String brukernavn = showInputDialog(null, "Brukernavn: ", "Innlogging", QUESTION_MESSAGE);
    String passord = showInputDialog(null, "Brukernavn: ", "Innlogging", QUESTION_MESSAGE);
    Connection forbindelse  = DriverManager.getConnection(Databasekonstanter.dbNavn, brukernavn, passord);
    Statement setning = forbindelse.createStatement();

    /* F�lgende to setninger m� ev. kommenteres bort. */
    setning.executeUpdate("drop table eksemplar");
    setning.executeUpdate("drop table bok");

    setning.executeUpdate("create table bok(isbn varchar(50) primary key, forfatter  varchar(50) not null,  tittel varchar(50) not null, reservert varchar(50))");
    setning.executeUpdate("create table eksemplar(isbn varchar(50) not null, eksnr integer not null, laant_av varchar(50), primary key(isbn, eksnr), foreign key (isbn) references bok)");
    setning.executeUpdate("insert into bok values ('0-201-50998-X', 'J. Rumbaugh, I. Jacobson, G. Booch', 'The Unified Modeling Language Reference Manual', null)");
    setning.executeUpdate("insert into bok values ('0-07-241163-5', 'J. P. Cohoon, J. W. Davidson', 'C++ Program Design', null)");
    setning.executeUpdate("insert into bok values ('0-596-00123-1', 'Brett Mclaughlin', 'Bulding Java Enterprise Applications', null)");
    setning.executeUpdate("insert into eksemplar values ('0-201-50998-X', 1, null)");
    setning.executeUpdate("insert into eksemplar values ('0-201-50998-X', 2, null)");
    setning.executeUpdate("insert into eksemplar values ('0-07-241163-5', 1, null)");
    setning.executeUpdate("insert into eksemplar values ('0-596-00123-1', 1, null)");

    ResultSet res = setning.executeQuery("select * from bok, eksemplar where bok.isbn = eksemplar.isbn");
    while (res.next()) {
      System.out.println(res.getString("isbn") + " " + res.getString("forfatter") + ": " + res.getString("tittel") +
                                         ", eks.nr " + res.getInt("eksNr"));
    }
    res.close();
    setning.close();
    forbindelse.close();
  }
}