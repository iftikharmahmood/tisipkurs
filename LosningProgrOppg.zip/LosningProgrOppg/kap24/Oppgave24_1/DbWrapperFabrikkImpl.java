/*
 * DbWrapperFabrikkImpl.java E.L. 2006-01-18
 */
import java.rmi.*;
import java.rmi.server.*;
import mittBibliotek.database.DatabasePool;  // se side 734

public class DbWrapperFabrikkImpl extends UnicastRemoteObject implements DbWrapperFabrikk {
  private DatabasePool dbPool;
  private int feilkode; // brukes i regNyBok() i klassen DatabaseImpl

  public DbWrapperFabrikkImpl(int poolKapasitet, String dbDriver, String dbNavn, String brukernavn, String passord,
         int startFeilkode) throws Exception {
    dbPool = new DatabasePool(poolKapasitet, dbDriver, dbNavn, brukernavn, passord);
    feilkode = startFeilkode;
  }

  public Bibliotek lagDbWrapper() throws RemoteException {
    return new BibliotekImpl(dbPool, feilkode);
  }

  public void stengDatabasePool() {
    dbPool.lukkAlleForbindelser();
  }
}
