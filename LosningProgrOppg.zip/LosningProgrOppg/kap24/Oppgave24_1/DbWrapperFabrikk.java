/*
 * DbWrapperFabrikk.java E.L. 2006-01-16
 *
 */

import java.rmi.*;
public interface DbWrapperFabrikk extends Remote {
  Bibliotek lagDbWrapper() throws Exception;
}
