/*
 * BibliotekImpl.java E.L. 2006-01-18
 */
import java.rmi.*;
import java.rmi.server.*;
import java.sql.*;
import java.util.ArrayList;
import mittBibliotek.database.DatabasePool;  // se side 734
import mittBibliotek.database.Forbindelse; // se side 735

public class BibliotekImpl extends UnicastRemoteObject implements Bibliotek {
  private DatabasePool dbPool;
  private int kodePrim�rn�kkel; // Returkode fra databasesystemet dersom konflikt mellom prim�rn�kkelverdier.

  public BibliotekImpl(DatabasePool startDbPool, int startKode) throws RemoteException {
    dbPool = startDbPool;
    kodePrim�rn�kkel = startKode;
  }

  /*
   * Data om boka, samt f�rste eksemplar registreres. Det f�r nummer 1.
   * Mulige exceptions: ugyldigIsbn
   * Transaksjonsh�ndtering er n�dvendig p� grunn av at to
   * oppdateringssetninger skal kj�res mot databasen.
   */
  public void regNyBok(Bok nyBok) throws RemoteException, BiblException {
    Forbindelse forbindelse = null;
    Connection conn = null;
    Statement setning = null;
    try {
      forbindelse = dbPool.reserverForbindelse();
      conn = forbindelse.finnForbindelse();
      conn.setAutoCommit(false);  // *** transaksjon starter
      setning = conn.createStatement();

      /* Oppdaterer boktabellen */
      String sql = "insert into bok values('" + nyBok.finnIsbn() + "', '" + nyBok.finnForfatter() +
                   "', '" + nyBok.finnTittel() + "', null)"; // siste felt er tomt
      System.out.println("SQL-setning: " + sql);
      setning.executeUpdate(sql);

      /* Oppdaterer eksemplar-tabellen */
      sql = "insert into eksemplar values('" + nyBok.finnIsbn() +
            "', 1, null)";  // 1 for eksemplar nr. 1, og siste felt er tomt
      System.out.println("SQL-setning: " + sql);
      setning.executeUpdate(sql);

      conn.commit();   // *** transaksjon slutt

    } catch (SQLException e) {
      rullTilbake(conn);  // *** transaksjon avbrutt
      if (e.getErrorCode() == kodePrim�rn�kkel) { // bok med denne ISBN eksisterer allerede
        throw new BiblException(Returkode.ugyldigIsbn.toString());
      } else skrivMelding(e, "regNyBok()");

    } finally {
      settAutocommit(conn);    // *** setter p� autocommit igjen
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
  }

  /*
   * Registrerer nytt eksemplar.
   * Hvis ok, s� returnerer denne metoden eksemplarnummeret
   *    Mulige exceptions: ugyldigIsbn
   *    NB! Denne metoden kontrollerer ikke om boka er reservert,  se i tilfelle neste metode
   * Transaksjonsh�ndteringen l�ses her p� samme m�te som i metoden registrerNyperson()
   * p� side 724 i boka.
   */
  public int regNyttEksemplar(String isbn) throws RemoteException, BiblException {
    int eksNr = 0;
    boolean ok = true;
    do {
      Forbindelse forbindelse = null;
      Statement setning = null;
      ResultSet res = null;
      try {
        forbindelse = dbPool.reserverForbindelse();
        setning = (forbindelse.finnForbindelse()).createStatement();

        /* Finner eksemplar-nummer og oppdaterer eksemplar-tabellen */
        String sql = "select max(eksNr) as maksNr from eksemplar where isbn = '" + isbn + "'";
        System.out.println("SQL-setning: " + sql);
        res = setning.executeQuery(sql);
        if (!res.next()) throw new BiblException(Returkode.ugyldigIsbn.toString());
        eksNr = res.getInt("maksNr") + 1;
        res.close();
        sql = "insert into eksemplar values('" + isbn + "', " + eksNr + ", null)";
        System.out.println("SQL-setning: " + sql);
        setning.executeUpdate(sql);

      } catch (SQLException e) {
        if (e.getErrorCode() == kodePrim�rn�kkel) ok = false;
        else  skrivMelding(e, "regNyttEksemplar()");
      } finally {
        lukkResSet(res);
        lukkSetning(setning);
        dbPool.frigiForbindelse(forbindelse.finnNr());
      }
    } while (!ok);
    return eksNr;
  }

  /*
   * Finner hvem som har reservert ei bok. Returnerer null hvis boka ikke er reservert.
   *   Mulige exceptions: ugyldigIsbn
   */
  public String finnReservertAv(String isbn) throws RemoteException, BiblException {
    Forbindelse forbindelse = null;
    Statement setning = null;
    ResultSet res = null;
    String reservertAv = null;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = forbindelse.finnForbindelse().createStatement();

      String sql = "select reservert from bok where isbn = '" + isbn + "'";
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql);
      if (!res.next()) throw new BiblException(Returkode.ugyldigIsbn.toString());
      reservertAv = res.getString("reservert");

    } catch (SQLException e) {
      skrivMelding(e, "finnReservertAv()");
    } finally {
      lukkResSet(res);
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return reservertAv;
  }

  /*
   * Registrerer utl�n av et eksemplar.
   *  Mulige exceptions: ugyldigIsbn, ugyldigEksNr, alleredeUtl�nt, reservert
   */
  public void l�nUtEksemplar(String isbn, String navn, int eksNr) throws RemoteException, BiblException {
    navn = navn.trim().toUpperCase();
    Forbindelse forbindelse = null;
    Statement setning = null;
    try {
      if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
      if (!eksemplarEksisterer(isbn, eksNr)) throw new BiblException(Returkode.ugyldigEksNr.toString());
      if (finnReservertAv(isbn) != null) throw new BiblException(Returkode.reservert.toString());

      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();

      /* oppdaterer eksemplar-tabellen */
      String sql = "update eksemplar set laant_av = '" + navn + "' where laant_av is null and isbn = '"
                           + isbn + "' and eksnr = " + eksNr;
      System.out.println("SQL-setning: " + sql);
      int antOppd = setning.executeUpdate(sql);
      if (antOppd == 0) throw new BiblException(Returkode.alleredeUtl�nt.toString());

    } catch (SQLException e) {
      skrivMelding(e, "l�nUtEksemplar()");
    } finally {
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
  }

  /*
   * Her reserverer vi ei bok.
   * Kun en person kan reservere ei bok av gangen, selv om det fins flere eksemplarer av boka.
   * Mulige exceptions: ugyldigIsbn, reserveringUn�dv (der er eksemplarer inne), alleredeReservert
   */
  public void reserverEksemplar(String isbn, String navn) throws RemoteException, BiblException {
    navn = navn.trim().toUpperCase();
    Forbindelse forbindelse = null;
    Statement setning = null;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();

      if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
      if (finnAntEksInne(isbn) > 0) throw new BiblException(Returkode.reserveringUn�dv.toString());

      /* Skal fors�ke � reservere boka */
      String sql = "update bok set reservert = '" + navn + "' where isbn = '" + isbn + "' and reservert is null";
      System.out.println("SQL-setning: " + sql);
      int antall = setning.executeUpdate(sql);
      if (antall == 0) throw new BiblException(Returkode.erReservertFraF�r.toString());

    } catch (SQLException e) {
      skrivMelding(e, "reserverEksemplar()");
    } finally {
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
  }

  /*
   * Kanselerer reservasjon. Mulige exceptions: ugyldigIsbn
   */
  public void kanselerReservasjon(String isbn) throws RemoteException, BiblException {
    if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());

    Forbindelse forbindelse = null;
    Statement setning = null;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();
      String sql = "update bok set reservert = null where isbn = '" + isbn + "'";
      System.out.println("SQL-setning: " + sql);
      int antall = setning.executeUpdate(sql);
      if (antall == 0) throw new BiblException(Returkode.ugyldigIsbn.toString());

    } catch (SQLException e) {
      skrivMelding(e, "kanselerReservasjon()");
    } finally {
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
  }

  /*
   * Returnerer et bestemt eksemplar.  Transaksjonsh�ndtering med to update-setninger.
   * Mulige exceptions: ugyldigIsbn, ugyldigEksNr, reservert
   */
  public void returnerEksemplar(String isbn, int eksNr) throws RemoteException, BiblException {
      Forbindelse forbindelse = null;
      Connection conn = null;
      Statement setning = null;
      try {
        if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
        if (!eksemplarEksisterer(isbn, eksNr)) throw new BiblException(Returkode.ugyldigEksNr.toString());

        /*
        * Er boka reservert? I tilfelle skal det rapporteres til klienten.
        * Samtidig skal reservasjonen oppheves, slik at boka kan l�nes ut.
        * Bibliotekaren m� selv s�rge for � legge boka til side og l�ne den ut til riktig person.
        */
        forbindelse = dbPool.reserverForbindelse();
        conn = forbindelse.finnForbindelse();
        setning = conn.createStatement();

        String navn = finnReservertAv(isbn);   // tar vare p� navnet p� den som har reservert

        conn.setAutoCommit(false);  // *** transaksjon starter

        /* Opphever reservasjonen */
        String sql = "update bok set reservert = null where isbn = '" + isbn + "' and reservert is not null";
        System.out.println("SQL-setning: " + sql);
        int antall = setning.executeUpdate(sql);  // antall lik 0 dersom boka ikke var reservert

        /* Opphever utl�net */
        sql = "update eksemplar set laant_av = null where isbn = '" + isbn + "' and eksnr = " + eksNr;
        System.out.println("SQL-setning: " + sql);
        setning.executeUpdate(sql);

        conn.commit();  // *** transaksjon slutt

        if (antall > 0) throw new BiblException(Returkode.reservert.toString() + " Reservert av " + navn);

    } catch (SQLException e) {
      rullTilbake(conn);  // *** transaksjon avbrutt
      skrivMelding(e, "returnerEksemplar()");
    } finally {
      settAutocommit(conn);    // *** setter p� autocommit igjen
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
  }

  /*
   * Finner l�ntakere. Mulige exceptions: ugyldigIsbn
   */
  public ArrayList<String> finnL�ntakere(String isbn) throws RemoteException, BiblException {
    Forbindelse forbindelse = null;
    Statement setning = null;
    ResultSet res = null;
    ArrayList<String> liste = new ArrayList<String>();
    try {
      if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();

      String sql = "select laant_av from eksemplar where isbn = '" + isbn + "' and laant_av is not null";
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql);
      while (res.next()) {
        liste.add(res.getString("laant_av"));
      }

    } catch (SQLException e) {
      skrivMelding(e, "finnL�ntakere()");
    } finally {
      lukkResSet(res);
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return liste;
  }

 /*
  * Finner hvilke eksemplarer som er inne.  Mulige exceptions: ugyldigIsbn
  */
  public ArrayList<Integer> finnEksInne(String isbn) throws RemoteException, BiblException {
    if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
    String sql = "select eksnr from eksemplar where isbn = '" + isbn + "' and laant_av is null";
    System.out.println("SQL-setning: " + sql);
    return finnEksemplarer(sql);
  }

 /*
  * Finner hvilke eksemplarer som er l�nt ut.  Mulige exceptions: ugyldigIsbn
  */
  public ArrayList<Integer> finnEksUte(String isbn) throws RemoteException, BiblException {
    if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
    String sql = "select eksnr from eksemplar where isbn = '" + isbn + "' and laant_av is not null";
    System.out.println("SQL-setning: " + sql);
    return finnEksemplarer(sql);
  }

   /*
    * Finner antall eksemplarer som er inne.  Mulige exceptions: ugyldigIsbn
    */
  public int finnAntEksInne(String isbn) throws RemoteException, BiblException {
    if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
    String sql = "select count(*) as antall from eksemplar where isbn = '" + isbn + "' and laant_av is null";
    System.out.println("SQL-setning: " + sql);
    return finnAntEks(sql);
  }

 /*
  * Finner antall eksemplarer som er utl�nt.  Mulige exceptions: ugyldigIsbn
  */
  public int finnAntEksUte(String isbn) throws RemoteException, BiblException {
    if (!bokEksisterer(isbn)) throw new BiblException(Returkode.ugyldigIsbn.toString());
    String sql = "select count(*) as antall from eksemplar where isbn = '" + isbn + "' and laant_av is not null";
    System.out.println("SQL-setning: " + sql);
    return finnAntEks(sql);
  }

  /*
   *  Returnerer en streng med bokinformasjon.
   *  Navn p� l�ntakerne er ikke med. Det fins en egen metode for dette.
   *  Mulige exceptions: ugyldigIsbn
   */
  public String finnBokInfo(String isbn) throws RemoteException, BiblException {
    Forbindelse forbindelse = null;
    Statement setning = null;
    ResultSet res = null;
    String resultat = "";
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();

      /* F�rst, eksemplar-informasjon (unntatt l�ntakere, egen metode for disse) */
      String sql = "select * from eksemplar where isbn = '" + isbn + "'";
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql);
      if (!res.next()) throw new BiblException(Returkode.ugyldigIsbn.toString());
      int antEks = 0;
      int antUtl�nt = 0;
      do {
        antEks++;
        String l�ntAv = res.getString("laant_av");
        if (l�ntAv != null) antUtl�nt++;
      } while (res.next());
      res.close();

      /* S�, informasjon om forfatter og tittel */
      sql = "select * from bok where isbn = '" + isbn + "'";
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql); // eksakt �n rad
      res.next();
      resultat = isbn + Bok.sep + res.getString("forfatter") + ", " +
               res.getString("tittel") + ", " + antEks + " eksemplarer, " + antUtl�nt + " er utl�nt ";
      String reservertAv = res.getString("reservert");
      if (reservertAv == null) resultat += " Ikke reservert.";
      else resultat += " Reservert av " + reservertAv;
      res.close();

    } catch (SQLException e) {
      skrivMelding(e, "finnBokInfo()");
    } finally {
      lukkResSet(res);
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return resultat;
  }

  /*
   *  Returnerer en tabell med strenger med bokinformasjon.
   *  Et element i tabellen for hver boktittel (hver isbn).
   *  Navn p� l�ntakerne er ikke med. Det fins en egen metode for dette.
   *  Mulige exceptions: ugyldigIsbn
   */
  public String[] finnAlleB�ker() throws RemoteException {
    Forbindelse forbindelse = null;
    Statement setning = null;
    ResultSet res = null;
    String [] alle = null;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();
      String sql = "select isbn from bok";
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql);
      ArrayList<String> alleIsbn = new ArrayList<String>();
      while (res.next()) {
        String isbn = res.getString("isbn");
        alleIsbn.add(isbn);
      }
      res.close();

      alle = new String[alleIsbn.size()];
      for (int i = 0; i < alle.length; i++) {
        String denneIsbn = alleIsbn.get(i);
        alle[i] = finnBokInfo(denneIsbn);
      }
     } catch (BiblException e) {  // skal ikke forekomme
       skrivMelding(e, "BiblException, finnAlleB�ker()");
     } catch (SQLException e) {
       skrivMelding(e, "finnAlleB�ker()");
     } finally {
       lukkResSet(res);
       lukkSetning(setning);
       dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return alle;
  }

  /*
   * Privat hjelpemetode. Finner om isbn er gyldig.
   */
  private boolean bokEksisterer(String isbn) throws RemoteException {
    Forbindelse forbindelse = null;
    Statement setning = null;
    ResultSet res = null;
    boolean eksisterer = false;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();
      String sql = "select * from bok where isbn = '" + isbn + "'";
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql);
      if (res.next()) eksisterer = true;

    } catch (SQLException e) {
      skrivMelding(e, "bokEksisterer()");
    } finally {
      lukkResSet(res);
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return eksisterer;
  }

  /*
   * Privat hjelpemetode. Finner om isbn og eksemplarnr er gyldig.
   */
  private boolean eksemplarEksisterer(String isbn, int eksnr) throws RemoteException {
    Forbindelse forbindelse = null;
    Statement setning = null;
    ResultSet res = null;
    boolean eksisterer = false;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();
      String sql = "select count(*) as antall from eksemplar where isbn = '" + isbn + "' and eksnr = " + eksnr;
      System.out.println("SQL-setning: " + sql);
      res = setning.executeQuery(sql);
      res.next();
      int antall = res.getInt("antall");
      if (antall > 0) eksisterer = true;
      res.close();
    } catch (SQLException e) {
      skrivMelding(e, "eksemplarEksisterer()");
    } finally {
       lukkResSet(res);
       lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return eksisterer;
  }

  /*
   * Privat hjelpemetode. Finner eksemplarnr gitt sql-setning.
   * Sql-setningen m� referere til feltet "eksnr" i databasen.
   */
  private ArrayList<Integer> finnEksemplarer(String sql) throws RemoteException {
    Forbindelse forbindelse = null;
    ResultSet res = null;
    Statement setning = null;
    ArrayList<Integer> liste = new ArrayList<Integer>();
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();
      res = setning.executeQuery(sql);
      while (res.next()) {
        liste.add(new Integer(res.getInt("eksnr")));
      }

    } catch (SQLException e) {
      skrivMelding(e, "finnEksemplarer()");
    } finally {
      lukkResSet(res);
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return liste;
  }

  /*
   * Privat hjelpemetode. Finner antall fra gitt sql-setning.
   * Forutsetter at sql-setningen returnerer kun en rad.
   * Sql-setningen m� referere til feltet "antall" i databasen.
   */
public int finnAntEks(String sql) throws RemoteException, BiblException {
    Forbindelse forbindelse = null;
    ResultSet res = null;
    Statement setning = null;
    int antall = 0;
    try {
      forbindelse = dbPool.reserverForbindelse();
      setning = (forbindelse.finnForbindelse()).createStatement();
      res = setning.executeQuery(sql);
      res.next();
      antall = res.getInt("antall");

    } catch (SQLException e) {
      skrivMelding(e, "finnAntEks()");
    } finally {
      lukkResSet(res);
      lukkSetning(setning);
      dbPool.frigiForbindelse(forbindelse.finnNr());
    }
    return antall;
  }

  /*
   * N� f�lger en rekke hjelpemetoder med enkel funksjonalitet.
   * Hovedhensikten med disse metodene er � unng� flere
   * niv� av exceptionh�ndtering i de kallende metodene.
   */
  private void settAutocommit(Connection conn) {
    try {
      if (conn != null && !conn.getAutoCommit()) {
        conn.setAutoCommit(true);
      }
    } catch (SQLException e) {
      skrivMelding(e, "lukkResSet()");
    }
  }

  private void rullTilbake(Connection conn) {
    try {
      if (conn != null) {
        conn.rollback();
      }
    } catch (SQLException e) {
      skrivMelding(e, "rullTilbake()");
    }
  }

  private void lukkResSet(ResultSet res) {
    try {
      if (res != null) res.close();
    } catch (SQLException e) {
      skrivMelding(e, "lukkResSet()");
    }
  }

  private void lukkSetning(Statement stm) {
    try {
      if (stm != null) stm.close();
    } catch (SQLException e) {
      skrivMelding(e, "lukkSetning()");
    }
  }

  private void skrivMelding(Exception e, String metode) {
    System.err.println("*** Feil oppst�tt i klassen BibliotekImpl, metode " + metode + ". ***");
    e.printStackTrace(System.err);
  }
}