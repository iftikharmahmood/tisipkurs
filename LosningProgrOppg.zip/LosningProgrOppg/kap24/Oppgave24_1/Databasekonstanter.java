/*
 * Databasekonstanter.java  EL 2006-01-17
 *
 */
public class Databasekonstanter {
  public static final String dbDriver = "oracle.jdbc.driver.OracleDriver";
  public static final String dbNavn = "jdbc:oracle:thin:@oracle.stud.aitel.hist.no:1521:oracle";
  public static final int kodePrim�rn�kkel = 1; // returkode hvis prim�rn�kkelverdi eksisterer fra f�r
  public static final int poolKapasitet = 3;  // se boka kap. 20.5
}
