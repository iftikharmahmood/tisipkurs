/*
 * BibliotekTjener.java   E.L. 2006-01-19
 *
 * Klassen genererer et fabrikkobjekt for databasekontakt og registrerer dette i rmi-registeret.
 * Setter opp forbindelse til en bestemt Oracle-database.
 *
 */

import java.rmi.Naming;
import static javax.swing.JOptionPane.*;

public class BibliotekTjener {
  public static void main(String[] args) throws Exception {
    String brukernavn = showInputDialog(null, "Brukernavn: ", "Innlogging", QUESTION_MESSAGE);
    String passord = showInputDialog(null, "Brukernavn: ", "Innlogging", QUESTION_MESSAGE);
    DbWrapperFabrikkImpl fabrikk = new DbWrapperFabrikkImpl(
                      Databasekonstanter.poolKapasitet,
                      Databasekonstanter.dbDriver,
                      Databasekonstanter.dbNavn,
                      brukernavn,
                      passord,
                      Databasekonstanter.kodePrim�rn�kkel);
    Naming.rebind("Boktjener", fabrikk);
    showMessageDialog(null,
                     "N� er databasepoolen oppe. Trykk Ok n�r den skal stenges.");
    fabrikk.stengDatabasePool();
    System.exit(0);
  }
}