/*
 * Oppgave18_3.java  - "Programmering i Java", 4.utgave - 2011-02-28
 *
 * Filnavnet settes i main(), og sendes til vinduet via konstrukt�ren.
 * Filen leses , og teksten vises i tekstomr�det.
 * Editerte data skrives til filen i det brukeren trykker p� Skriv-knappen,
 * det vil si i metoden actionPerformed() i klassen KnappeLytter.
 *
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import static javax.swing.JOptionPane.*;

class TekstVindu extends JFrame {

  private static final String STANDARDTEKST =
    "Du kan skrive noe her dersom du skriver inn riktig passord.";
  private JTextField brukernavnFelt = new JTextField(15);
  private JPasswordField passordFelt = new JPasswordField(15);
  private JTextArea tekstfelt = new JTextArea(10, 20);
  private JButton skriveknapp = new JButton("Skriv");
  private JLabel meldingsfelt = new JLabel("Her kommer meldinger...");
  private String filnavn;

  public TekstVindu(String tittel, String startFilnavn) {
    setTitle(tittel);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    filnavn = startFilnavn;

    setLayout(new BorderLayout(5, 5)); // mellomrom mellom panelene
    add(new InnloggingsPanel(), BorderLayout.NORTH);
    add(new TekstomraadePanel(), BorderLayout.CENTER);
    add(new KnappePanel(), BorderLayout.SOUTH);
    pack();
  }

  public String lesDataFraFil() {
    String tekst = "";
    BufferedReader leser = null;
    try {
      FileReader forbindelse = new FileReader(filnavn);
      leser = new BufferedReader(forbindelse);

      String linje = leser.readLine();
      while (linje != null) {
        tekst += linje + "\n";
        linje = leser.readLine();
      }
    } catch(IOException e) {
      showMessageDialog(null, "Feil ved fil�pning/lesing: " + e + "\nBruker standardteksten");
      tekst = STANDARDTEKST;
    } finally {
      if (leser != null) {
        try {
         leser.close();
        } catch (IOException e) {
        }
      }
    }
    return tekst;
  }

  /* Beskriver nordre panel */
  private class InnloggingsPanel extends JPanel {
    public InnloggingsPanel() {
      setLayout(new GridLayout(2, 2, 5, 5));
      add(new JLabel("Brukernavn:", JLabel.RIGHT));
      add(brukernavnFelt);
      brukernavnFelt.setInputVerifier(new BrukernavnKontroll());
      add(new JLabel("Passord:", JLabel.RIGHT));
      add(passordFelt);
      passordFelt.setInputVerifier(new PassordKontroll());
      passordFelt.addFocusListener(new Fokuslytter());
    }
  }

  /* Beskriver midtre panel */
  private class TekstomraadePanel extends JPanel {
    public TekstomraadePanel() {
      tekstfelt.setLineWrap(true);
      tekstfelt.setWrapStyleWord(true);
      tekstfelt.setEditable(false);
      tekstfelt.setText(lesDataFraFil());
      JScrollPane rullefelt = new JScrollPane(tekstfelt);
      add(rullefelt);
    }
  }

  /* Beskriver s�ndre panel */
  private class KnappePanel extends JPanel {
    public KnappePanel() {
      KnappeLytter knappelytteren = new KnappeLytter();
      skriveknapp.addActionListener(knappelytteren);
      skriveknapp.setEnabled(false);
      skriveknapp.setMnemonic('S');
      add(skriveknapp);
      add(meldingsfelt);
    }
  }

  /* Kontrollerer brukernavn */
  class BrukernavnKontroll extends InputVerifier {
    public boolean verify(JComponent inndata) {
      JTextField tekstfelt = (JTextField) inndata;
      String data = tekstfelt.getText();
      return (data.equals("test"));
    }

    public boolean shouldYieldFocus(JComponent inndata) {
      boolean ok = super.shouldYieldFocus(inndata);
      if (ok) {
        meldingsfelt.setText("Brukernavn ok");
      } else {
        meldingsfelt.setText("Ugyldig brukernavn");
      }
      return ok;
    }
  }

  /* Kontrollerer passordet */
  class PassordKontroll extends InputVerifier {
    public boolean verify(JComponent inndata) {
      char[] riktigPassord = {'t', 'e', 's', 't'};
      JPasswordField tekstfelt = (JPasswordField) inndata;
      char[] passord = passordFelt.getPassword();
      return (Arrays.equals(passord, riktigPassord));
    }

    public boolean shouldYieldFocus(JComponent inndata) {
      boolean ok = super.shouldYieldFocus(inndata);
      if (ok) {
        meldingsfelt.setText("Ok. Du kan begynne � skrive.");
      } else {
        meldingsfelt.setText("Ugyldig passord");
      }
      return ok;
    }
  }

  /**
   * Dersom brukernavn og passord er riktig skal tekstomr�det �pnes. N� er det ikke
   * mulig � forlate brukernavnfeltet f�r brukernavnet er ok, og det er heller ikke
   * mulig � forlate passordfeltet f�r passordet er ok. Vi lager derfor en lytter
   * som lytter etter den hendelsen at fokus forlater passordfeltet.
   */
  private class Fokuslytter implements FocusListener {
    public void focusLost(FocusEvent hendelse) {
      skriveknapp.setEnabled(true);
      tekstfelt.setEditable(true);
      tekstfelt.requestFocus();
    }
    public void focusGained(FocusEvent hendelse) {
    }
  }

  /* Beskriver objekter som lytter etter knappetrykk */
  private class KnappeLytter implements ActionListener {
    public void actionPerformed(ActionEvent hendelse) {
      String tekst = tekstfelt.getText();
      PrintWriter skriver = null;
      try {
        FileWriter forbindelse = new FileWriter(filnavn, false);
        skriver = new PrintWriter(new BufferedWriter(forbindelse));
        skriver.println(tekst);
        showMessageDialog(null, "N� er teksten lagret p� filen " + filnavn);
      } catch (IOException e) {
        showMessageDialog(null, "Problemer med skriving til fil: " + e);
      } finally {
        if (skriver != null) {
          skriver.close();
        }
      }
    }
  }
}

class Oppgave18_3 {
  public static void main(String[] args) {
    final String filnavn = "mineData.txt";
    TekstVindu etVindu = new TekstVindu("Ulike tekstkomponenter", filnavn);
    etVindu.setVisible(true);
  }
}