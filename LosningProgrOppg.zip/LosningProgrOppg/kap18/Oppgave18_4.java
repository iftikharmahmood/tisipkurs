/**
 * Oppgave18_4.java  - "Programmering i Java", 4.utgave - 2011-02-28
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen og videreutviklet
 * av Hans Roar Sandberg for tidligere utgaver av boka.
 *
 * Denne applikasjonen presenterer et brukergrensesnitt for begrenset vedlikehold
 * av grupper og personer.
 *
 * En allerede etablert gruppe kan ikke utvides eller endres.
 * Nye personer m� alltid legges inn i nye grupper som etableres etter at de er lagt inn.
 *
 * For � l�se denne oppgaven er det tatt i bruk en s�kalt HashMap (se kap. 21.9)
 * for � forenkle de interne data-strukturene.
 *
 * Metoden setListData() i klassen JList krever enten Vector eller Object[] som argument.
 * Velger den siste varianten. Metoden toArray() henter ut elementene i en
 * ArrayList() som en tabell av Object.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import static javax.swing.JOptionPane.*;

public class Oppgave18_4 {
  public static void main(String[] args) {
    /* Oppretter en HashMap og legger inn en rekke grupper. */
    HashMap<String, ArrayList<Integer>> grupper = new HashMap<String, ArrayList<Integer>>();

    ArrayList<String> personer = new ArrayList<String>();
    personer.add("Arild Nybraaten");
    personer.add("Arne Bj�rn Mikalsen");
    personer.add("Arne Morten Uglem");
    personer.add("Bj�rn Klefstad");
    personer.add("Bj�rn Tore Larsen");
    personer.add("Andreas Lopen");
    personer.add("Audun Aspevoll");
    personer.add("Bj�rn Tore Johansen");
    personer.add("Camilla Kvalfors");
    personer.add("Christian Lyng");
    personer.add("Per Brandvol");
    personer.add("Knut Gilboe");
    personer.add("Bj�rn Peresen Bratvik");
    personer.add("Kjell Helgesen");
    personer.add("Asbj�rg Iversen");
    personer.add("Oddny Aarset");
    personer.add("Ingunn T�vik Andersen");
    personer.add("Arve Arstad");
    personer.add("Per �yvind Aspen");
    personer.add("Rune Berdal");

    grupper.put("Alle", new ArrayList<Integer>());

    ArrayList<Integer> liste1 = new ArrayList<Integer>();
    for (int i = 0; i < 5; i++) {
      liste1.add(i);
    }
    grupper.put("Ansatte, IDB", liste1);

    ArrayList<Integer> liste2 = new ArrayList<Integer>();
    for (int i = 5; i < 10; i++) {
      liste2.add(i);
    }
    grupper.put("Studenter, IDB", liste2);

    ArrayList<Integer> liste3 = new ArrayList<Integer>();
    for (int i = 10; i < 15; i++) {
      liste3.add(i);
    }
    grupper.put("Ansatte, IBM", liste3);

    ArrayList<Integer> liste4 = new ArrayList<Integer>();
    for (int i = 15; i < 20; i++) {
      liste4.add(i);
    }
    grupper.put("Studenter, IBM", liste4);

    /* Oppretter et vindu. */
    MittVindu vindu = new MittVindu("Oppgave18_4", grupper, personer);
    vindu.pack();
    vindu.setVisible(true);

    vindu.visGrupper();
    vindu.visPersoner();
  }
}

/**
 * Klassen MittVindu
 */
class MittVindu extends JFrame {

  private HashMap<String, ArrayList<Integer>> grupper;
  private ArrayList<String> personer;
  private JList boksA = new JList();
  private JList boksB = new JList();

  public MittVindu(String tittel, HashMap<String, ArrayList<Integer>> startGrupper, ArrayList<String> startPersoner) {
    super(tittel);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    /* Setter opp grensesnittet. */
    boksA.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    boksA.addListSelectionListener(new GruppeLytter());

    JScrollPane rullefeltA = new JScrollPane(boksA);
    add(rullefeltA, BorderLayout.WEST);

    JScrollPane rullefeltB = new JScrollPane(boksB);
    add(rullefeltB, BorderLayout.EAST);

    TrykkPanel trykkPanel = new TrykkPanel();
    add(trykkPanel, BorderLayout.SOUTH);

    /* Tilordner data. */
    grupper = startGrupper;
    personer = startPersoner;
  }

  void visGrupper() {
    ArrayList<String> liste = new ArrayList<String>();
    Set<String> n�kler = grupper.keySet();
    Object[] navn = n�kler.toArray();
    for (Object etNavn : navn) {
      liste.add((String) etNavn);
    }
    boksA.setListData(liste.toArray());
    boksA.setListData(navn);
    boksA.setSelectedValue("Alle", true);
  }

  void visPersoner() {
    String verdi = (String) boksA.getSelectedValue();
    if (verdi == null || verdi.equals("Alle")) {
      boksB.setListData(personer.toArray());
    } else {
      ArrayList<String> fullListe = new ArrayList<String>();
      ArrayList<Integer> liste = grupper.get(verdi);
      for (int indeks : liste) {
        fullListe.add(personer.get(indeks));
      }
      boksB.setListData(fullListe.toArray());
    }
  }

  /* Beskriver TrykkPanel. */
  private class TrykkPanel extends JPanel {
    public TrykkPanel() {
      setLayout(new GridLayout(1, 2));

      JButton knapp = new JButton("Ny Gruppe");
      knapp.setMnemonic('G');
      knapp.addActionListener(new Knappelytter());
      add(knapp);

      knapp = new JButton("Ny Person");
      knapp.setMnemonic('P');
      knapp.addActionListener(new Knappelytter());
      add(knapp);
    }
  }

  /* Lytter etter knappetrykk. */
  private class Knappelytter implements ActionListener {
    public void actionPerformed(ActionEvent hendelse) {
      if (hendelse.getActionCommand().equals("Ny Person")) {
        String enPerson = showInputDialog("Oppgi navn p� ny person:");
        if (enPerson == null) {
          return;  // RETUR
        }
        personer.add(enPerson);
        visPersoner();
        boksA.setSelectedValue("Alle", true);

      } else if (hendelse.getActionCommand().equals("Ny Gruppe")) {
        Object[] verdier = boksB.getSelectedValues();
        if (verdier.length == 0) {
          showMessageDialog(null, "Ingen personer er valgt.", "Error", ERROR_MESSAGE);
          return; // RETUR
        }

        ArrayList<Integer> gruppe = new ArrayList<Integer>();
        for (Object etNavn : verdier) {
          gruppe.add(personer.indexOf(etNavn));
        }

        String gruppeNavn = showInputDialog("Oppgi Ny Gruppe:");
        if (gruppeNavn != null) {
          grupper.put(gruppeNavn, gruppe);
        }
        visGrupper();
      }
    }
  }

  /* Lytter etter gruppevalg. */
  private class GruppeLytter implements ListSelectionListener {
    public void valueChanged(ListSelectionEvent hendelse) {
      visPersoner();
    }
  }
}
