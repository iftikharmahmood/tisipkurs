/**
 * Oppgave19_5.java  - "Programmering i Java", 4.utgave - 2011-03-04
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen og videreutviklet
 * av Hans Roar Sandberg for tidligere utgaver av boka.
 *
 * Denne oppgaven beskriver et grensesnitt til oppgave 5, kapittel 14.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.*;
import static javax.swing.JOptionPane.*;

import mittBibliotek.DataLeser; // se kap. 15.1 - brukes til � lese heltall

public class Oppgave19_5 {
  public static void main(String[] args) {

    /* D�rene v�re har nummer 1, 2, .., 7. I prinsippet kan hvilke som helst
       d�rnummer brukes. Det ligger ikke inne noe kontroll av det. */

    final int D�RNR_MAKS = 7;

    /* Ansatte og studenter har en fast mengde d�rer de har adgang til */
    Ansatt.fastAdgang(1);
    Ansatt.fastAdgang(2);
    Ansatt.fastAdgang(5);
    Ansatt.fastAdgang(6);

    Student.fastAdgang(2);
    Student.fastAdgang(3);


    /* Oppretter et register og fyller det med noen tilfeldige kort. */
    KortRegister register = new KortRegister();

    /* To ansattkort */
    Ansatt aKort = new Ansatt();
    aKort.tillatD�r(4); // spesialtilgang, kort nr 0
    register.registrerNyttKort(aKort);
    register.registrerNyttKort(new Ansatt());  // kort nr 1

    /* To studentkort */
    Student sKort = new Student();
    sKort.tillatD�r(D�RNR_MAKS); // spesialtilgang til d�ren med h�yest nr
    register.registrerNyttKort(sKort); // kort nr 2
    register.registrerNyttKort(new Student()); // kort nr 3

    /* Ett kurskort */
    int[] kursdatoer = {20110201, 20110204, 20110208, 20110210};
    int[] kursd�rer = {2, 4, 5};
    Kort kKort = new Kurs(kursd�rer, kursdatoer, 800, 1530);
    register.registrerNyttKort(kKort);  // kort nr 4
    kKort.tillatD�r(1); // ekstra d�r p� dette kurs-kortet

    /* Oppretter et vindu. */
    MittVindu vindu = new MittVindu("Oppgave19_5", register);
    vindu.setVisible(true);
  }
}

/**
 * Klassen MittVindu
 */
class MittVindu extends JFrame {
  private KortRegister register;

  private RegisterModell kortdata;
  private JTable kortliste;

  private JButton knappNyttKort = new JButton("Nytt Kort");
  private JButton knappEndreSperring = new JButton("Endre Sperring");
  private JButton knappDato = new JButton("Sjekk D�r og Tidspunkt");
  private JButton knappSpesialtilgang = new JButton("Spesialtilgang");


  public MittVindu(String tittel, KortRegister register) {
    super(tittel);
    this.register = register;

    kortdata = new RegisterModell(register);
    kortliste = new JTable(kortdata);

    add(new JScrollPane(kortliste), BorderLayout.NORTH);
    add(new TrykkPanel(), BorderLayout.SOUTH);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
  }

  /* Beskriver TrykkPanel */
  private class TrykkPanel extends JPanel {
    public TrykkPanel() {
      setLayout(new GridLayout(1, 2));

      knappNyttKort.setMnemonic('N');
      knappNyttKort.addActionListener(new Knappelytter());
      add(knappNyttKort);

      knappEndreSperring.setMnemonic('S');
      knappEndreSperring.addActionListener(new Knappelytter());
      add(knappEndreSperring);

      knappDato.setMnemonic('D');
      knappDato.addActionListener(new Knappelytter());
      add(knappDato);

      knappSpesialtilgang.setMnemonic('T');
      knappSpesialtilgang.addActionListener(new Knappelytter());
      add(knappSpesialtilgang);
    }
  }

  /* Lytter etter knappetrykk. */
  private class Knappelytter implements ActionListener {

    /**
     * Har laget en hjelpemetode for hver knapp. De finner du rett
     * under metoden actionPerformed().
     */
    public void actionPerformed(ActionEvent hendelse) {
      JButton knapp = (JButton) hendelse.getSource();
      if (knapp == knappNyttKort) {
        handterNyttKort();
      } else if (knapp == knappEndreSperring) {
        handterEndreSperring();
      } else if (knapp == knappDato) {
        handterSjekkTidspunkt();
      } else if (knapp == knappSpesialtilgang) {
        handterGiSpesialtilgang();
      } else {
        showMessageDialog(null, "Feil. Hit skal man ikke komme :-)");
      }

      /*
       * N� er dataene endret. Vi m� varsle fra om det,
       * slik at disse endringene kommer til syne p� skjermen.
       */
      kortdata.fireTableDataChanged();
    }

    /**
     * Metoden lar brukeren velge korttype, og s�rger for at kort av
     * riktig type blir laget.
     */
    private void handterNyttKort() {
      final String[] TYPER = { "Ansatt", "Student", "Kurs" };
      String type = (String) showInputDialog(null, "Velg korttype:", "Nytt Kort", INFORMATION_MESSAGE, null, TYPER, TYPER[0]);

      /* Ansatt- og student-kort er enkelt */
      if (type.equals("Ansatt")) {
        register.registrerNyttKort(new Ansatt());
      } else if (type.equals("Student")) {
        register.registrerNyttKort(new Student());
      }

      /*
       * Kurskort, leser inn d�rer, datoer og fra- og til klokkeslett.
       * Ingen kontroll av om datoer eller klokkeslett er gyldige.
       * Se eventuelt l�sningen til oppgave 4 side 387.
       */
      else {
        int[] d�rer = lesD�rer("Hvilke d�rer skal dette kurskortet ha adgang til? ");
        int antall = DataLeser.lesHeltall("Hvor mange datoer? ");
        int[] datoer = new int[antall];
        for (int i = 0; i < datoer.length; i++) {
          datoer[i] = DataLeser.lesHeltall("Oppgi dato nr " + (i + 1) + " (����mmdd): ");
        }
        int fra = DataLeser.lesHeltall("Kurs fra kl (ttmm): ");
        int til = DataLeser.lesHeltall("Kurs til kl (ttmm): ");

        register.registrerNyttKort(new Kurs(d�rer, datoer, fra, til));
      }
    }

    /**
     * Metoden tar tak i de kortene brukeren har valgt. Dersom kortet er sperret,
     * �pnes det, og dersom det ikke er sperret, s� sperres det.
     */
    private void handterEndreSperring() {
      int[] verdier = kortliste.getSelectedRows();
      if (verdier.length == 0) {
        showMessageDialog(null, "Ingen kort valgt.", "Feil", WARNING_MESSAGE);
      } else {
        for (int valgtKort : verdier) {
          Kort kort = (Kort) register.finnKort(valgtKort);
          if (kort != null) {
            kort.setSperret(!kort.isSperret());
          }
        }
      }
    }

    /**
     * Metoden tar inne et d�rnummer, en dato og et klokkeslett.
     * Den finner ut hvilke kort som har tilgang p� denne datoen.
     */
    private void handterSjekkTidspunkt() {
      int d�r = DataLeser.lesHeltall("Oppgi d�rnummer: ");
      int dato = DataLeser.lesHeltall("Oppgi dato (����mmdd): ");
      int klokkeslett = DataLeser.lesHeltall("Oppgi klokkeslett (ttmm): ");

      ArrayList<Integer> liste = register.finnTilgang(d�r, dato, klokkeslett);
      if (liste.size() == 0) {
        showMessageDialog(null, "Ingen kort har tilgang til d�r " +  d�r + ", " +
            TidFormat.formaterDato(dato) + ", kl " +
            TidFormat.formaterKlokkeslett(klokkeslett), "Tilgang", INFORMATION_MESSAGE);
      } else {

        StringBuilder buffer = new StringBuilder();
        for (int etKort: liste) {
          buffer.append(etKort + " ");
        }

        showMessageDialog(null, "Kort med tilgang til d�r " + d�r + ", " +
            TidFormat.formaterDato(dato) + ", kl " + TidFormat.formaterKlokkeslett(klokkeslett) +
            ": " + buffer.toString(), "Tilgang", INFORMATION_MESSAGE);
      }
    }

    /**
     * Student- og ansatt-kort har en del d�rer de alltid har tilgang til. Det bestemmes
     * med klassemetoden fastAdgang(). Her er dette satt i main().
     * I tillegg kan enkelte kort f� tilgang til bestemte d�rer. Denne metoden
     * lar brukeren angi spesialtilgang for valgte kort. Hvert valgt kort f�r tilgang
     * til et eget sett med d�rer.
     */
    private void handterGiSpesialtilgang() {
      int[] verdier = kortliste.getSelectedRows(); // henter valgte kort
      if (verdier.length == 0) {
        showMessageDialog(null, "Ingen kort valgt.", "Feil", WARNING_MESSAGE);
      } else {

        /* Hvert gjenoml�p av l�kkekroppen behandler et bestemt kort */
        for (int valgtKort : verdier) {
          Kort kort = (Kort) register.finnKort(valgtKort);
          if (kort != null) {
            int[] d�rer = lesD�rer("Oppgi ekstra d�rer for kort nr " + valgtKort);
            for (int enD�r : d�rer) {
              kort.tillatD�r(enD�r);  // gir tilgang
            }
          }
        }
      }
    }

    private int[] lesD�rer(String ledetekst) {
      String ekstra = showInputDialog(ledetekst);

      /* Mellomrom og komma aksepteres som skilletegn mellom d�rnummer */
      StringTokenizer tekst = new StringTokenizer(ekstra, ", ");
      int[] d�rer = new int[tekst.countTokens()];
      int d�rIndeks = 0;
      try {
        while (tekst.hasMoreTokens()) {
          d�rer[d�rIndeks] = Integer.parseInt(tekst.nextToken());
          d�rIndeks++;
        }
        return d�rer;  // RETUR, alle d�rnumer registrert
      } catch (NumberFormatException e) {
        showMessageDialog(null, "Ugyldig tall. Ingen d�rer registrert");
        return new int[0];
      }
    }
  }
}

/**
 * Klassen RegisterModell
 *
 */
class RegisterModell extends AbstractTableModel {
  private static final String[] KOLONNENAVN = { "KortNr", "Type", "Tilgang", "Kommentar" };
  private KortRegister register;

  public RegisterModell(KortRegister startRegister) {
    register = startRegister;
  }

  /*
   * TableModel metoder
   *
   * Dette er metoder som JTable benytter til � finne st�rrelse og data. Ved �
   * lage v�re egne utgaver av disse kan vi lage en direkte kobling til
   * registeret.  Se kapittel 19.9.
   */

  /* Kolonnenavnene */
  public String getColumnName(int indeks) {
    return (indeks >= 0 && indeks < KOLONNENAVN.length) ? KOLONNENAVN[indeks] : "";
  }

  /* Brukeren skal ikke kunne editere i dataene */
  public boolean isCellEditable(int rad, int kolonne) {
    return false;
  }

  /* Antall kolonner. */
  public int getColumnCount() {
    return 4;
  }

  /* Antall rader er lik antall kort i registeret. */
  public int getRowCount() {
    return (register == null) ? 0 : register.finnAntKort();
  }

  /* Verdier som skal plasseres i tabellen. */
  public Object getValueAt(int rad, int kolonne) {
    switch (kolonne) {
      case 0:
        return new Integer(rad);

      case 1:
        return new String(register.finnKort(rad).finnType());

      case 2:
        return new String(register.finnKort(rad).finnTilgang());

      case 3:
        return new String(register.finnKort(rad).finnKommentar());

      default:
        return null;
    }
  }
}

/***** Her kommer problemdomeneklassene *****/

/**
 * Klassen KortRegister
 *
 * Klassen inneholder en mengde d�rkort. Kortene har ikke egne identifikasjoner,
 * men identifiseres ved den plass (indeks) de har i ArrayListen 'liste'.
 * Denne indeksen blir dermed kortets nummer utad. Det g�r bra, fordi kort ikke
 * flyttes eller fjernes i listen.
 *
 * Klassen bruker ArrayLister til � lagre heltall (kortnummer, d�rnummer).
 */

class KortRegister {
  private ArrayList<Kort> liste = new ArrayList<Kort>();

  /**
   * Metoden finner antall kort registrert.
   */
  public int finnAntKort() {
    return liste.size();
  }

  /**
   * Metoden finner et bestemt kort. Returnerer null hvis ugyldig indeks.
   */
  public Kort finnKort(int indeks) {
    return (indeks >= 0 && indeks < liste.size()) ? (Kort) liste.get(indeks) : null;
  }

  /**
   * Returnerer nummerne til de d�rene som et bestemt kort har tilgang til
   * p� et bestemt tidspunkt.
   */
  public String finnD�rer(int kortIndeks, int dato, int klokkeslett) {
    Kort kort = finnKort(kortIndeks);
    return (kort != null) ? kort.finnAlleD�rerMedTilgang(dato, klokkeslett) : null;
  }

  /**
   * Returnerer en ArrayList med numrene p� kortene som har tilgang
   * til en bestemt d�r p� et bestemt klokkeslett.
   */
  public ArrayList<Integer> finnTilgang(int d�r, int dato, int klokkeslett) {
    ArrayList<Integer> tilgang = new ArrayList<Integer>();
    for (int i = 0; i < liste.size(); i++) {
      if (tilgangOk(i, d�r, dato, klokkeslett)) {
        tilgang.add(i);  // auto-boxing
      }
    }
    return tilgang;
  }

  /**
   * Metoden finner ut om en bestemt person har tilgang til en bestemt
   * d�r p� et bestemt klokkeslett.
   * Metoden returnerer false hvis kort med oppgitt indeks ikke fins,
   * eller personen ikke har tilgang.
   */
  public boolean tilgangOk(int kortIndeks, int d�r, int dato, int klokkeslett) {
    Kort kort = finnKort(kortIndeks);
    return (kort == null) ? false : kort.tilgang(d�r, dato, klokkeslett);
  }

  /*   *
   * Metoden registrerer et nytt kort.
   */
  public void registrerNyttKort(Kort kort) {
    liste.add(kort);
  }

  /**
   * Metoden sperrer et kort.
   * Metoden returnerer false hvis kort med oppgitt indeks ikke fins.
   */
  public boolean sperrKort(int indeks) {
    Kort kort = finnKort(indeks);
    if (kort == null) {
      return false;
    }
    kort.setSperret(true);
    return true;
  }

  /**
   * Metoden opphever sperringen p� et kort.
   * Metoden returnerer false hvis kort med oppgitt indeks ikke fins.
   */
  public boolean �pneKort(int indeks) {
    Kort kort = finnKort(indeks);
    if (kort == null) {
      return false;
    }
    kort.setSperret(false);
    return true;
  }
}

/***** Her kommer klassen Kort med subklasser *****/

/* Disse klassene lagrer heltall (d�rnummer) som ArrayLister av Integer-objekter */

/**
 * Klassen Kort
 *
 */
abstract class Kort {
  public static final String SPERRET_BESKJED = "Kortet er sperret";
  public static final String ALLE_BESKJED = "Alle d�rer";
  public static final String INGEN_BESKJED = "Ingen d�rer";
  public static final int DAG_START = 700;  // kl 07:00
  public static final int DAG_SLUTT = 2300; // kl 23:00

  private boolean sperret = false;

  /**
   * For hvert kort lagrer vi de d�rene som kortet �pnes spesielt for.
   * I tillegg kommer en fast mengde d�rer for ansatte og for studenter.
   * Disse lagres i klassevariabler, se klassene Ansatt og Student.
   */
  private ArrayList<Integer> d�rer = new ArrayList<Integer>();

  abstract public String finnType(); // **** NY i oppgave 19-5 ****
  abstract public String finnKommentar(); // **** NY i oppgave 19-5 ****


  /**
   * Metoden reurnerer true dersom dette kortet er sperret.
   */
  public boolean isSperret() {
    return sperret;
  }

  /**
   * Metoden brukes til � sette eller �pne sperring.
   */
  public void setSperret(boolean nySperret) {
    sperret = nySperret;
  }

  /**
   * Denne metoden brukes for � gi dette kortet tilgang til en bestemt d�r
   * (i tillegg til eventuelle faste d�rer).
   */
  public void tillatD�r(int d�r) {
    d�rer.add(d�r); // auto-boxing
  }

  /**
   * Metoden finner alle d�rer som dette kortet gir tilgang til p�
   * et bestemt tidspunkt. Returnerer en streng for � fange alle tilfeller.
   */
  abstract public String finnAlleD�rerMedTilgang(int dato, int klokkeslett);

  /**
   * Skal finne ut om kortet har tilgang til en bestemt d�r p� et bestemt tidspunkt.
   * Spesielle regler gjelder for alle grupper kort.
   */
  abstract public boolean tilgang(int d�r, int dato, int klokkeslett);

  /**
   * Metoden returnerer en ArrayList med alle d�rer som dette kortet har tilgang til.
   * Her kommer ikke faste d�rer med. Metoden implementeres derfor ogs� i subklassene
   * Ansatt og Student, for � f� med faste d�rer.
   */
  protected ArrayList<Integer> finnD�rer() {
    return d�rer;
  }

  /**
   * Denne metoden lager en streng med de d�rene som kortet har tilgang til.
   * Tar ikke hensyn til faste d�rer. Metoden implementeres derfor ogs� i subklassene
   * Ansatt og Student, for � f� med dette.
   */
  protected String finnTilgang() {
    if (sperret) {
      return SPERRET_BESKJED;
    }
    StringBuilder buf = new StringBuilder();
    for (int enD�r : d�rer) {
      buf.append(enD�r + " ");
    }
    return buf.toString();
  }
}

/**
 * Klassen Fast
 * Denne klassen tjener kun klassifiseringsform�l slik vi har laget den her.
 * Kunne eventuelt lagt konstantene DAG_START og DAG_SLUTT her.
 */
abstract class Fast extends Kort {
}

/**
 * Klassen Kurs
 *
 * Det finnes ikke en mengde faste d�rer som alle kursdeltakere har adgang til.
 * B�de d�rer og datoer for tilgang kodes for hvert enkelt kurskort.
 * Samme tidsperiode (klokkeslett fra - til) gjelder for alle datoene p� samme kort.
 */
final class Kurs extends Kort {
  private final int[] datoer;
  private final int fraKlokka;
  private final int tilKlokka;

  public Kurs(int[] startD�rer, int[] startDatoer, int startFraKlokka, int startTilKlokka) {
    datoer = startDatoer;
    fraKlokka = startFraKlokka;
    tilKlokka = startTilKlokka;
    for (int enD�r : startD�rer) {
      tillatD�r(enD�r);
    }
  }

  public String finnType() {  // **** NY i oppgave 19-5 ****
    return "Kurs";
  }

  public String finnKommentar() {  // **** NY i oppgave 19-5 ****
    StringBuilder buf = new StringBuilder();
    buf.append("Datoer: ");
    for (int enDato : datoer) {
      buf.append(TidFormat.formaterDato(enDato) + ", ");
    }
    buf.append(" tidsperiode, fra kl " + TidFormat.formaterKlokkeslett(fraKlokka) +
               " til kl " + TidFormat.formaterKlokkeslett(tilKlokka));
    return buf.toString();
  }

  public String finnAlleD�rerMedTilgang(int dato, int klokkeslett) {
    if (isSperret()) {
      return SPERRET_BESKJED;
    }
    if (!tilgangTid(dato, klokkeslett)) {
      return INGEN_BESKJED;
    }
    return finnTilgang();
  }

  public boolean tilgang(int d�r, int dato, int klokkeslett) {
    if (isSperret()) {
      return false;
    }
    if (!tilgangTid(dato, klokkeslett)) {
      return false;
    }

    /* Sjekker d�rene */
    ArrayList<Integer> d�rer = finnD�rer();
    if (d�rer.indexOf(d�r) >= 0) {
      return true;  // s�ker etter heltall i ArrayListen
    }
    return false;
  }

  /* Privat hjelpemetode */
  private boolean tilgangTid(int dato, int klokkeslett) {
    /* Sjekker datoen */
    boolean datoFunnet = false;
    int datoIndeks = 0;
    while (!datoFunnet && datoIndeks < datoer.length) {
      if (dato == datoer[datoIndeks]) {
        datoFunnet = true;
      } else {
        datoIndeks++;
      }
    }

    /* Deretter m� klokkeslettet ligge innenfor lovlig intervall for dette kurskortet */
    if (datoFunnet && fraKlokka <= klokkeslett && klokkeslett <= tilKlokka) {
      return true;
    } else {
      return false;
    }
  }
}

/**
 * Klassen Ansatt
 *
 * Ansatte har tilgang til alle d�rer p� dagtid.
 * Ansatte har tilgang til et begrenset utvalg d�rer om natta, dog med kode.
 * Det begrensede utvalget d�rer best�r av en mengde faste d�rer (som er klassevariabel
 * i denne klassen), og en mengde spesielle d�rer, som bestemmes individuelt for
 * hvert kort.
 */
final class Ansatt extends Fast {
  private static ArrayList<Integer> fasteD�rer = new ArrayList<Integer>();

  public static void fastAdgang(int d�r) {
    fasteD�rer.add(d�r);
  }

  public String finnType() {  // **** NY i oppgave 19-5 ****
    return "Ansatt";
  }

  public String finnKommentar() {  // **** NY i oppgave 19-5 ****
    return "Kode kreves mellom kl " + TidFormat.formaterKlokkeslett(DAG_SLUTT) + " - " +
                   TidFormat.formaterKlokkeslett(DAG_START);
  }

  public String finnTilgang() {
    String tmp = super.finnTilgang();
    if (isSperret()) {
      return tmp;
    }
    return oversiktFasteD�rer() + tmp;
  }

  public String finnAlleD�rerMedTilgang(int dato, int klokkeslett) {
    if (isSperret()) {
      return SPERRET_BESKJED;
    }
    if (klokkeslett >= DAG_START && klokkeslett <= DAG_SLUTT) {
      return ALLE_BESKJED;
    }
    return finnTilgang();
  }

  public boolean tilgang(int d�r, int dato, int klokkeslett) {
    if (isSperret()) {
      return false;
    }
    if (klokkeslett >= DAG_START && klokkeslett <= DAG_SLUTT) {
      return true;
    }

    /*
     * P� natta har ansatte tilgang til faste d�rer og d�rer med
     * spesialtillatelse.
     */
    ArrayList<Integer> d�rerSpesial = finnD�rer();
    /* Sjekker om d�rnr er i en av de to ArrayListene */
    return(d�rerSpesial.indexOf(d�r) >= 0 || fasteD�rer.indexOf(d�r) >= 0) ? true : false;
  }

  private static String oversiktFasteD�rer() {
    StringBuilder oversikt = new StringBuilder();
    for (int enD�r : fasteD�rer) {
      oversikt.append(enD�r + " ");
    }
    return oversikt.toString();
  }
}

/**
 * Klassen Student
 * Studenter har ikke tilgang til noen d�rer om natta.
 * De har tilgang til et begrenset utvalg d�rer p� dagtid.
 * Det begrensede utvalget d�rer best�r av en mengde faste d�rer (som er klassevariabel
 * i denne klassen), og en mengde spesielle d�rer, som bestemmes individuelt for
 * hvert kort.
 *
 */
final class Student extends Fast {
  private static ArrayList<Integer> fasteD�rer = new ArrayList<Integer>();

  public static void fastAdgang(int d�r) {
    fasteD�rer.add(d�r);
  }

  public String finnType() {  // **** NY i oppgave 19-5 ****
    return "Student";
  }

  public String finnKommentar() {  // **** NY i oppgave 19-5 ****
    return "kl " + TidFormat.formaterKlokkeslett(DAG_START) + " - " +
                   TidFormat.formaterKlokkeslett(DAG_SLUTT);
  }

  public String finnTilgang() {
    String tmp = super.finnTilgang();
    return (isSperret())? tmp : oversiktFasteD�rer() + tmp;
  }

  public String finnAlleD�rerMedTilgang(int dato, int klokkeslett) {
    if (isSperret()) {
      return SPERRET_BESKJED;
    }
    if (klokkeslett <= DAG_START || klokkeslett >= DAG_SLUTT) {
      return INGEN_BESKJED;
    }
    return finnTilgang();
  }

  public boolean tilgang(int d�r, int dato, int klokkeslett) {
    if (isSperret()) {
      return false;
    }
    if (klokkeslett <= DAG_START || klokkeslett >= DAG_SLUTT) {
      return false;
    }

    /* Sjekker d�ra */
    ArrayList d�rerSpesial = finnD�rer();
    /* Sjekker om d�rnr er i en av de to ArrayListene */
    return (d�rerSpesial.indexOf(d�r) >= 0 || fasteD�rer.indexOf(d�r) >= 0) ? true : false;
  }

  private static String oversiktFasteD�rer() {
    StringBuilder oversikt = new StringBuilder();
    for (int enD�r : fasteD�rer) {
      oversikt.append(enD�r + " ");
    }
    return oversikt.toString();
  }
}

/* Ny i oppgave 19-5, for � skrive ut tidspunkt p� en leselig m�te */
class TidFormat {
  public static String formaterDato(int dato) { // ����mmdd
    int �r = dato / 10000;
    int mndDag = dato % 10000;
    int mnd = mndDag / 100;
    int dag = mndDag % 100;

    String tid = "";
    if (dag < 10) {
      tid += "0";
    }
    tid += dag + "-";
    if (mnd < 10) {
      tid += "0";
    }
    tid += mnd + "-" + �r;
    return tid;
  }

  public static String formaterKlokkeslett(int klokkeslett) { // ttmm
    int time = klokkeslett / 100;
    int min = klokkeslett % 100;

    String tid = "";
    if (time < 10) {
      tid += "0";
    }
    tid += time + ":";
    if (min < 10) {
      tid += "0";
    }
    tid += min;
    return tid;
  }
}