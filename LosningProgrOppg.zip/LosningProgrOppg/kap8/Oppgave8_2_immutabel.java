/**
 * Oppgave8_2_immutabel.java - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Klassen endrer ikke p� den opprinnelige teksten.
 * Resultatet fra en operasjon er et String-objekt med den modifiserte teksten
 *
 */
class NyString {
  private StringBuilder teksten;

  public NyString(String teksten) {
    this.teksten = new StringBuilder(teksten);
  }

  public String hentTeksten() {
    return teksten.toString();
  }

  public String slett(char tegn) {
    String resultat = "";
    for (int i = 0; i < teksten.length(); i++) {
      char detteTegnet = teksten.charAt(i);
      if (detteTegnet != tegn) {
        resultat += ("" + detteTegnet);
      }
    }
    return resultat;
  }

  public String forkort() {
    String resultat = "";
    int pos = finnNesteIkkeBlanke(0);
    while (pos >= 0) {
      resultat += teksten.charAt(pos);
      pos = teksten.indexOf(" ", pos + 1);
      if (pos >= 0) {
        pos = finnNesteIkkeBlanke(pos + 1);
      }
    }
    return resultat;
  }

  private int finnNesteIkkeBlanke(int startPos) {
    int pos = startPos;
    while (startPos < teksten.length() && teksten.charAt(startPos) == ' ') {
      startPos++;
    }
    return (startPos == teksten.length()) ? -1 : startPos;
  }
}

class Oppgave8_2_immutabel {
  public static void main(String[] args) {
    System.out.println("NyString: 6 tester.");
    NyString enTekst = new NyString("    dette e     g hh   jk kkkk     ");
    if (enTekst.forkort().equals("deghjk")) {
      System.out.println("NyString: Test 1 vellykket.");
    }
    if (enTekst.slett('r').equals("    dette e     g hh   jk kkkk     ")) {
      System.out.println("NyString; Test 2 vellykket.");
    }
    if (enTekst.slett(' ').equals("detteeghhjkkkkk")) {
      System.out.println("NyString; Test 3 vellykket.");
    }
    if (enTekst.slett('k').equals("    dette e     g hh   j      ")) {
      System.out.println("NyString; Test 4 vellykket.");
    }
    NyString tomTekst = new NyString("");
    if (tomTekst.forkort().equals("") && tomTekst.slett('a').equals("")) {
      System.out.println("NyString: Test 5 vellykket.");
    }
    NyString blankTekst = new NyString(" ");
    if (blankTekst.forkort().equals("") && blankTekst.slett('a').equals(" ")) {
      System.out.println("NyString: Test 6 vellykket.");
    }
  }
}







