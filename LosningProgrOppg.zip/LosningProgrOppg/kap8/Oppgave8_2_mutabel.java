/**
 * Oppgave8_2_mutabel.java - "Programmering i Java", 4.utgave - 2010-02-22
 *
 * Klassen endrer ikke p� den opprinnelige teksten.
 * Resultatet fra en operasjon er et String-objekt med dem modifiserte teksten
 *
 */
class NyString {
  private StringBuilder teksten;

  public NyString(String teksten) {
    this.teksten = new StringBuilder(teksten);
  }

  public String hentTeksten() {
    return teksten.toString();
  }

  public String slett(char tegn) {
    for (int i = teksten.length() - 1; i >= 0; i--) {  // sletter bakfra for at indeksene ikke skal forandre seg
      char detteTegnet = teksten.charAt(i);
      if (detteTegnet == tegn) {
        teksten.deleteCharAt(i);
      }
    }
    return teksten.toString();
  }

  public String forkort() {  // jobber oss bakfra og forover
    int startPos = teksten.length() - 1;
    int pos = finnNesteIkkeBlankeBakfra(startPos);
    while (pos >= 0) {
      pos = teksten.lastIndexOf(" ", pos);
      if (pos >= 0) {
        if (pos >= startPos) {  // ingenting mer � slette
          return teksten.toString();
        }
        teksten.delete(pos + 2, startPos + 1);
        startPos = pos;
        pos = finnNesteIkkeBlankeBakfra(startPos);
      }
    }
    pos = teksten.lastIndexOf(" ");
    if (pos >= 0) {
      teksten.delete(0, pos + 1);  // sletter tegn i begynnelsen av teksten
    }
    return teksten.toString();
  }

  private int finnNesteIkkeBlankeBakfra(int startPos) {
    while (startPos >= 0 && teksten.charAt(startPos) == ' ') {
      startPos--;
    }
    return (startPos == -1) ? -1 : startPos;
  }
}

class Oppgave8_2_mutabel {
  public static void main(String[] args) {
    System.out.println("NyString: 6 tester.");
    NyString enTekst = new NyString("    dette e     g hh   jk kkkk     ");
    if (enTekst.forkort().equals("deghjk")) {
      System.out.println("NyString: Test 1 vellykket.");
    }
    enTekst = new NyString("    dette e     g hh   jk kkkk     ");
    if (enTekst.slett('r').equals("    dette e     g hh   jk kkkk     ")) {
      System.out.println("NyString; Test 2 vellykket.");
    }
    enTekst = new NyString("    dette e     g hh   jk kkkk     ");
    if (enTekst.slett(' ').equals("detteeghhjkkkkk")) {
      System.out.println("NyString; Test 3 vellykket.");
    }
    enTekst = new NyString("    dette e     g hh   jk kkkk     ");
    if (enTekst.slett('k').equals("    dette e     g hh   j      ")) {
      System.out.println("NyString; Test 4 vellykket.");
    }
    NyString tomTekst1 = new NyString("");
    NyString tomTekst2 = new NyString("");
    if (tomTekst1.forkort().equals("") && tomTekst2.slett('a').equals("")) {
      System.out.println("NyString: Test 5 vellykket.");
    }
    NyString blankTekst1 = new NyString(" ");
    NyString blankTekst2 = new NyString(" ");
    if (blankTekst1.forkort().equals("") && blankTekst2.slett('a').equals(" ")) {
      System.out.println("NyString: Test 6 vellykket.");
    }
  }
}







