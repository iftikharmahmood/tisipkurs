/**
 * Oppgave17_2.java  - "Programmering i Java", 4.utgave - 2011-02-28
 *
 * Klassen Kalkulator beskriver en kalkulator med grafisk brukergrensesnitt.
 * Denne kalkulatoren er begrenset til kun � utf�re regnestykker med to operander og �n operator.
 * Brukeren m� trykke p� tastene (knappene) for � sette opp regnestykket, eller det kan skrives inn direkte i tekstfeltet.
 *
 * L�sningen benytter i stor grad klassen  StringBuilder, se side 253 og 278
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Kalkulator extends JFrame {

  private JTextField display = new JTextField("Skriv regnestykket her eller trykk p� tastene.");

  public Kalkulator(String tittel) {
    setTitle(tittel);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    display.selectAll(); // merker hele feltet for at overskriving skal skje
    add(display, BorderLayout.NORTH);
    display.addActionListener(new Tekstlytter());

    Knappepanel knapper = new Knappepanel();
    add(knapper, BorderLayout.SOUTH);
    pack();
  }

  /* Lytter etter trykk p� Enter-tasten fra tekstfeltet (se side 606) */
  private class Tekstlytter implements ActionListener {
   public void actionPerformed(ActionEvent hendelse) {
     Uttrykk uttrykket = new Uttrykk(display.getText());
     try {
       display.setText("" + uttrykket.beregnResultat());
     } catch (NumberFormatException e) {
       display.setText("Kan ikke beregne uttrykket: " + display.getText());
     }
   }
 }

  /* Lytter etter knappetrykk. */
  private class Knappelytter implements ActionListener {
    private boolean feltBlanket = false;
    public void actionPerformed(ActionEvent hendelse) {
      if (!feltBlanket) {       // f�rste gang
        display.setText("");
        feltBlanket = true;
      }
      String knapp = hendelse.getActionCommand();
      if (knapp.equals("=")) {
        Uttrykk uttrykket = new Uttrykk(display.getText());
        try {
          display.setText("" + uttrykket.beregnResultat());
        } catch (NumberFormatException e) {
          display.setText("Kan ikke beregne uttrykket: " + display.getText());
        }

      } else if (knapp.equals("C")) {
        display.setText("");
      } else {
        display.setText(display.getText() + knapp);
      }
    }
  }

  /* Beskriver knappepanel. */
  private class Knappepanel extends JPanel {
    public Knappepanel() {
      setLayout(new GridLayout(4, 4));
      Knappelytter knappelytteren = new Knappelytter();

      String knapper = new String("123+456-789*0=C/");
      for (int i = 0; i < 16; i++) {
        JButton knapp = new JButton(knapper.substring(i, i + 1));
        knapp.addActionListener(knappelytteren);
        add(knapp);
      }
    }
  }
}

/**
 * Klasse om beskriver et matematisk uttrykk.
 *
 * Konstrukt�ren tar uttrykket som tekst.
 * Det m� best� av to operander atskilt av en operator.
 * Operandene kan ha fortegn + eller -.
 * Uttrykket kan, men m� ikke, avsluttes med likhetstegn.
 */
class Uttrykk {
  private StringBuilder operand1;
  private StringBuilder operand2;
  private char operator = '\0';;
  public Uttrykk(String uttrykk) {
    uttrykk = fjernBlanke(uttrykk);
    System.out.println("Uttrykk: " + uttrykk);
    char sisteTegn = uttrykk.trim().charAt(uttrykk.length() - 1);
    if (sisteTegn == '=') {  // fjerner ev. likhetstegn bakerst
      uttrykk = uttrykk.substring(0, uttrykk.length() - 1);
    }

    int indeks = finnOperand1(uttrykk);
    finnOperand2(indeks, uttrykk);
  }

  public int beregnResultat() throws NumberFormatException  {
    int tall1 = Integer.parseInt(operand1.toString());
    int tall2 = Integer.parseInt(operand2.toString());
    if (operator == '+') {
      return tall1 + tall2;
    } else if (operator == '-') {
      return tall1 - tall2;
    } else if (operator == '*') {
      return tall1 * tall2;
    } else if (operator == '/') {
      if (tall2 == 0) {
        return 0;
      } else {
        return tall1 / tall2;
      }
    } else {
      return 0; // skal ikke komme hit
    }
  }

  /**
  * Hjelpemetoder f�lger.
  */
  private String fjernBlanke(String uttrykk) {
    StringBuilder uttrykkSB = new StringBuilder();
    for (int i = 0; i < uttrykk.length(); i++) {
      if (uttrykk.charAt(i) != ' ') {
        uttrykkSB.append(uttrykk.charAt(i));
      }
    }
    return uttrykkSB.toString();
  }

  private int finnOperand1(String uttrykk) {
    operand1 = new StringBuilder();
    // fortegn foran 1.operand?
    int indeks = 0;
    if (uttrykk.charAt(0) == '-' || uttrykk.charAt(0) == '+') {
      if (uttrykk.charAt(0) == '-') {  // parseInt() klarer ikke fortegn +
        operand1.append(uttrykk.charAt(0));
      }
      indeks = 1;
    }
    while (indeks < uttrykk.length() && Character.isDigit(uttrykk.charAt(indeks))) {
      operand1.append(uttrykk.charAt(indeks));
      indeks++;
    }
    System.out.println("1.operand: " + operand1.toString());
    return indeks;
  }

  private char finnOperand2(int indeks, String uttrykk) {
    operand2 = new StringBuilder();
    if (indeks < uttrykk.length() - 1) {
      operator =  uttrykk.charAt(indeks);
      indeks++;
      char tegn = uttrykk.charAt(indeks);
      if (tegn == '+' || tegn == '-') {  // fortegn 2.operand
        if (tegn == '-') {  // parseInt() klarer ikke fortegn +
          operand2.append(tegn);
        }
        indeks++;
      }
    }
    while (indeks < uttrykk.length() && Character.isDigit(uttrykk.charAt(indeks))) {
      operand2.append(uttrykk.charAt(indeks));
      indeks++;
    }
    System.out.println("2.operand: " + operand2.toString());
    return operator;
  }
}

class Oppgave17_2 {
  public static void main(String[] args) {
    Kalkulator etVindu = new Kalkulator("Kalkulator. Kun heltall og to operander av gangen.");
    etVindu.setVisible(true);
  }
}
