/**
 * Oppgave17_3.java  - "Programmering i Java", 4.utgave - 2011-02-28
 * L�sningen bygger p� en l�sning utviklet av Simon Toresen for 1.utgave av boka.
 *
 * I denne oppgaven lager vi et program hvor brukeren f�r muligheten til � pr�ve
 * � finne magiske kvadrater. En magisk kvadrat har lik sum i alle retninger,
 * ogs� diagonalt.
 *
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MagiskKvadrat extends JFrame{
  private JTextField display;
  private JTextField[] ruter = new JTextField[16];
  private JLabel[] sumHorisontal = new JLabel[4];
  private JLabel[] sumVertikal = new JLabel[4];
  private JLabel sumDiag1 = new JLabel("0");
  private JLabel sumDiag2 = new JLabel("0");

  public MagiskKvadrat(String tittel) {
    setTitle(tittel);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new GridLayout(7, 5));
    leggUtKvadratet();
    pack();
  }

  /* Legger ut rutenettet og omkringliggende informasjon */
  private void leggUtKvadratet() {
    int ruteIndeks = 0;
    for (int linje = 0; linje < 4; linje++) {
      for (int kolonne = 0; kolonne < 4; kolonne++) {
        ruter[ruteIndeks] = new JTextField("0");
        add(ruter[ruteIndeks]);
        ruteIndeks++;
      }
      sumHorisontal[linje] = new JLabel("0");
      add(sumHorisontal[linje]);
    }
    for (int kolonne = 0; kolonne < 4; kolonne++) {
      sumVertikal[kolonne] = new JLabel("0");
      add(sumVertikal[kolonne]);
    }
    add(new JLabel(""));
    add(new JLabel("Sum diagonal 1: "));
    add(sumDiag1);
    add(new JLabel("Sum diagonal 2: "));
    add(sumDiag2);
    add(new JLabel());
    JButton knapp = new JButton("Magisk?");
    knapp.addActionListener(new Knappelytter());
    add(knapp);
    display = new JTextField();
    add(display);
  }

  /* Lytter etter knappetrykk. */
  private class Knappelytter implements ActionListener {
    public void actionPerformed(ActionEvent hendelse) {
      int[] tall = new int[16];
      try {
        for (int i = 0; i < 16; i++) {
          tall[i] = Integer.parseInt(ruter[i].getText().toString());
        }
      } catch(NumberFormatException e) {
        display.setText("Ulovlig verdi");
        return;  // RETUR
      }

      /* Beregner diagonale summer */
      int diag1 = tall[0] + tall[5] + tall[10] + tall[15];
      int diag2 = tall[3] + tall[6] + tall[9] + tall[12];
      sumDiag1.setText("" + diag1);
      sumDiag2.setText("" + diag2);

      int[] vertikal = new int[4];
      int[] horisontal = new int[4];

      /* Beregner horisontale og vertikale summer. */
      for (int i = 0; i < 4; i++) {
        horisontal[i] = tall[i*4] + tall[i*4 + 1] + tall[i*4 + 2] + tall[i*4 + 3];
        vertikal[i] = tall[i]   + tall[i + 4]   + tall[i + 8]   + tall[i + 12];
        sumHorisontal[i].setText("" + horisontal[i]);
        sumVertikal[i].setText("" + vertikal[i]);
      }

      /* Tester summene */
      if (diag1 != diag2) {
        display.setText("Nei!");
        return;  // RETUR
      }

      for (int i = 0; i < 4; i++) {
        if (diag1 != vertikal[i] || diag1 != horisontal[i]) {
          display.setText("Nei!");
          return;  // RETUR
        }
      }

      display.setText("Ja!");
    }
  }
}

class Oppgave17_3 {
  public static void main(String[] args) {
    MagiskKvadrat etVindu = new MagiskKvadrat("Magisk kvadrat");
    etVindu.setVisible(true);
  }
}
