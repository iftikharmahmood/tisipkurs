/*
 * BiblException.java  E.L. 2006-01-16
 */

public class BiblException extends Exception {
  private Returkode kode;

  public BiblException() {
    super("Feil hos tjeneren");
  }

  public BiblException(String melding) {
    super(melding);
  }

  public BiblException(Returkode startKode) {
    kode = startKode;
  }
}






