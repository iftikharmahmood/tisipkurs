/**
 * Bok.java EL 2006-01-16
 *
 * Objekter av denne klassen sendes som argumenter til RMI-kall.
 * Derfor implementerer klassen Serializable.
 */

public class Bok implements java.io.Serializable {
  public static final String sep = " : "; // skiller ISBN fra resten av bok-info i en streng
  private String isbn;
  private String tittel;
  private String forfatter;

  public Bok(String startIsbn, String startTittel, String startForfatter) {
    isbn = startIsbn;
    tittel = startTittel;
    forfatter = startForfatter;
  }

  public String finnIsbn() {
    return isbn;
  }

  public String finnTittel() {
    return tittel;
  }

  public String finnForfatter() {
    return forfatter;
  }

  public String toString() {
    return isbn + sep + forfatter + ", " + tittel;
  }
}

