/**
 * Biblioteksbok.java EL 2006-01-16
 *
 * Konstrukt�ren legger inn f�rste eksemplar i eksemplarlisten.
 *
 * Returkodene hentes fra en definert enum-type.
 * Denne klassen brukes bare p� tjenersiden.
 */

import java.util.*;

public class Biblioteksbok extends Bok {

  private String reservertAv = null; // navn

  /* Et element i tabell-listen for hvert eksemplar av boka.
     Eksemplarnummeret er lik indeksen + 1.
     Hvis elementet har verdien null betyr det at eksemplaret er inne,
     hvis ikke s� har elementet verdi lik navnet til l�neren. */

  private ArrayList<String> eksemplarer = new ArrayList<String>();

  public Biblioteksbok(String startIsbn, String startTittel, String startForfatter) {
    super(startIsbn, startTittel, startForfatter);
    eksemplarer.add(null);
  }

  public String finnReservertAv() {
    return reservertAv;
  }

  /* Legger til et nytt eksemplar av tittelen */
  public int leggTilNyttEksemplar() {
    eksemplarer.add(null);
    return eksemplarer.size();
  }

  /* Registrerer utl�n av et bestemt eksemplar */
  public void l�nUt(String navn, int eksNr) throws BiblException {
    navn = navn.trim();
    if (reservertAv == null) {
      int indeks = eksNr - 1;
      if (indeks < 0 || indeks >= eksemplarer.size()) throw new BiblException(Returkode.ugyldigEksNr.toString());
      if (eksemplarer.get(indeks) != null) throw new BiblException(Returkode.alleredeUtl�nt.toString());
      eksemplarer.set(indeks, navn);
    } else throw new BiblException(Returkode.reservert.toString());
  }

  /* Finner hvilke eksemplarer som er inne */
  public ArrayList<Integer> finnEksInne() {
    ArrayList<Integer> inne = new ArrayList<Integer>();
    for (int i = 0; i < eksemplarer.size(); i++) {
      if (eksemplarer.get(i) == null) inne.add(i + 1);      // eksnr = indeks + 1
    }
    return inne;
  }

  /* Finner antall eksemplarer som er inne */
  public int finnAntallInne() {
    return finnEksInne().size();
  }

  /* Finner hvilke eksemplarer som er utl�nt */
  public ArrayList<Integer> finnEksUte() {
    ArrayList<Integer> ute = new ArrayList<Integer>();
    for (int i = 0; i < eksemplarer.size(); i++) {
      if (eksemplarer.get(i) != null) ute.add(i + 1);      // eksnr = indeks + 1
    }
    return ute;
  }

  /* Finner antall eksemplarer som er utl�nt */
  public int finnAntallUtl�nt() {
    return finnEksUte().size();
  }

  /* Reserverer en tittel */
  public void reserver(String navn) throws BiblException {
    navn = navn.trim();
    if (reservertAv != null) {
      throw new BiblException(Returkode.erReservertFraF�r.toString());
    }
    if (finnAntallInne() > 0) {
      throw new BiblException(Returkode.reserveringUn�dv.toString());
    }
    reservertAv = navn;
  }

  /* Kanselerer reservasjon */
  public void kanselerReservasjon() {
    reservertAv = null;
  }

  /* Registrerer at en utl�ner har returnert et bestemt eksemplar */
  public void returnerEksemplar(int eksNr) throws BiblException {
    int indeks = eksNr - 1;
    if (indeks < 0 || indeks >= eksemplarer.size()) {
      throw new BiblException(Returkode.ugyldigEksNr.toString());
    }
    eksemplarer.set(indeks, null);
    if (reservertAv != null) {
      String navn = reservertAv;
      reservertAv = null;
      throw new BiblException(Returkode.reservert.toString() + ". Reservert av " + navn);
    }
  }

  /* Finner navn p� alle l�ntakerne */
  public ArrayList<String> finnL�ntakere() {
    ArrayList<String> l�nere = new ArrayList<String>();
    for (String eksemplar : eksemplarer) {
      if (eksemplar != null) l�nere.add(eksemplar);
    }
    return l�nere;
  }

  public String toString() {

    /* F�rst, informasjon om eksemplarer */
    int antRetjenert = 0;
    int antUtl�nt = 0;
    for (String etEksemplar : eksemplarer) {
      if (etEksemplar != null) antUtl�nt++;
    }

    /* S�, om boka */
    String resultat = finnIsbn() + sep + finnForfatter() + ", " +  // sep, se klassen Bok
             finnTittel() + ", " + eksemplarer.size() + " eksemplarer, " + antUtl�nt + " er ute. ";

    if (reservertAv == null) resultat += " Ikke reservert.";
    else resultat += " Reservert av " + reservertAv + ".";
    return resultat;
  }
}