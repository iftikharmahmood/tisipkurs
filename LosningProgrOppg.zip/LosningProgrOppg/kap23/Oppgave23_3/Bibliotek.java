/*
 * Bibliotek.java E.L. 2006-01-16
 *
 * BiblException kastes dersom operasjonen ikke kan utf�res.
 */

import java.rmi.*;
import java.util.ArrayList;
interface Bibliotek extends Remote {

  /* Data om boka, samt f�rste eksemplar registreres. Det f�r nummer 1.
     Mulige exceptions: ugyldigIsbn */
  void regNyBok(Bok nyBok) throws RemoteException, BiblException;

  /* Hvis ok, s� returnerer denne metoden eksemplarnummeret
     Mulige exceptions: ugyldigIsbn
     NB! Denne metoden kontrollerer ikke om boka er reservert,
     se i tilfelle neste metode */
  int regNyttEksemplar(String nyIsbn) throws RemoteException, BiblException;

  /* Mulige exceptions: ugyldigIsbn */
  boolean erReservert(String isbn) throws RemoteException, BiblException;

  /* Mulige exceptions: ugyldigIsbn, ugyldigEksNr, alleredeUtl�nt, reservert */
  void l�nUtEksemplar(String isbn, String navn, int eksNr) throws RemoteException, BiblException;

  /* Mulige exceptions: ugyldigIsbn, reserveringUn�dv (der er eksemplarer inne), alleredeReservert */
  void reserverEksemplar(String isbn, String navn) throws RemoteException, BiblException;

  /* Mulige exceptions: ugyldigIsbn */
  void kanselerReservasjon(String isbn) throws RemoteException, BiblException;

  /* Mulige exceptions: ugyldigIsbn, ugyldigEksNr, reservert */
  void returnerEksemplar(String isbn, int eksNr) throws RemoteException, BiblException;

  /* Finner l�ntakere. Mulige exceptions: ugyldigIsbn  */
  ArrayList<String> finnL�ntakere(String isbn) throws RemoteException, BiblException;

  /* Finner hvilke eksemplarer som er inne.  Mulige exceptions: ugyldigIsbn  */
  ArrayList<Integer> finnEksInne(String isbn) throws RemoteException, BiblException;

  /* Finner hvilke eksemplarer som er l�nt ut.  Mulige exceptions: ugyldigIsbn  */
  ArrayList<Integer> finnEksUte(String isbn) throws RemoteException, BiblException;

  /* Finner antall eksemplarer som er inne.  Mulige exceptions: ugyldigIsbn  */
  int finnAntEksInne(String isbn) throws RemoteException, BiblException;

  /* Finner antall eksemplarer som er l�nt ut.  Mulige exceptions: ugyldigIsbn  */
  int finnAntEksUte(String isbn) throws RemoteException, BiblException;

  /* Returnerer strenger med bok- og eksemplar-informasjon.
      Den f�rste metoden kan kaste ugyldigIsbn-exception. */
  String finnBokInfo(String isbn) throws RemoteException, BiblException;
  String[] finnAlleB�ker() throws RemoteException;
}
