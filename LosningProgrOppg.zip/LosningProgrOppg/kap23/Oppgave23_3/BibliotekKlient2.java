/*
 * BibliotekKlient2.java EL 2006-01-16
 *
 * Denne klienten brukes til � registrere utl�n, innlevering og reservering av b�ker.
 */
import java.io.*;
import java.rmi.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import static javax.swing.JOptionPane.*;

class Klient2GUI extends JFrame {
  private DefaultListModel listeInnhold = new DefaultListModel();
  private JList alleB�ker = new JList(listeInnhold);

  private JButton utl�nKnapp = new JButton("L�ne ut");
  private JButton reserverKnapp = new JButton("Reservere");
  private JButton kanselReservKnapp = new JButton("Kanselere reservasjon");
  private JButton visL�ntakerKnapp = new JButton("Vis l�ntakere");
  private JButton leverInnKnapp = new JButton("Levere inn");

  private JButton oppfriskKnapp = new JButton("Gjenoppfrisk data");

  private Bibliotek bibliotek;

  public Klient2GUI(String[] infoAlleB�ker, Bibliotek startTjener) {
    bibliotek = startTjener;
    setTitle("Registrering av utl�n, innlevering og reservering av b�ker");
    setLocation(200, 300);
    add(new JLabel("Alle b�ker i biblioteket"), BorderLayout.NORTH);
    for (String bokinfo : infoAlleB�ker) {
      listeInnhold.addElement(bokinfo);
    }
    alleB�ker.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    alleB�ker.setSelectedIndex(0);
    JScrollPane listeMedScrollbar = new JScrollPane(alleB�ker);
    add(listeMedScrollbar, BorderLayout.CENTER);
    add(new Knappepanel(), BorderLayout.SOUTH);
    pack();
  }

  private class Knappepanel extends JPanel {
    public Knappepanel() {
      add(utl�nKnapp);
      add(reserverKnapp);
      add(kanselReservKnapp);
      add(visL�ntakerKnapp);
      add(leverInnKnapp);
      add(oppfriskKnapp);
      Knappelytter lytter = new Knappelytter();
      utl�nKnapp.addActionListener(lytter);
      reserverKnapp.addActionListener(lytter);
      kanselReservKnapp.addActionListener(lytter);
      visL�ntakerKnapp.addActionListener(lytter);
      leverInnKnapp.addActionListener(lytter);
      oppfriskKnapp.addActionListener(lytter);
    }
  }

  private class Knappelytter implements ActionListener {
    public void actionPerformed(ActionEvent hendelse) {
      JButton kilde = (JButton) hendelse.getSource();
      int bokIndeks = alleB�ker.getSelectedIndex(); // til bruk ved oppdatering av listen
      String bokInfo = (String) alleB�ker.getSelectedValue();

      /* Bok-info'en er p� �n linje. Trenger ISBN som er f�rst p� linjen */
      int pos = bokInfo.indexOf(Bok.sep);
      String isbn = bokInfo.substring(0, pos).trim();

      try {
        if (kilde == oppfriskKnapp) {
          String[] infoAlleB�ker = bibliotek.finnAlleB�ker();
          listeInnhold.clear();
          for (String bokinfo : infoAlleB�ker) {
            listeInnhold.addElement(bokinfo);
          }
          alleB�ker.setSelectedIndex(0);

        } else if (kilde == utl�nKnapp) { // L�ner ut et eksemplar av ei bok
          ArrayList<Integer> eksemplarer = bibliotek.finnEksInne(isbn);
          int eksNr = velgEksemplarnr(eksemplarer, "Eksemplarer til utl�n");
          if (eksNr > 0) {
            String navn = showInputDialog(null, "Navnet p� kunden: ", "Utl�n", QUESTION_MESSAGE);
            if (navn != null && navn.trim().length() > 0) {
              bibliotek.l�nUtEksemplar(isbn, navn, eksNr);
              showMessageDialog(null, "Utl�n av isbn  " + isbn + ", eksnr " + eksNr + " er registrert.", "Utl�n", INFORMATION_MESSAGE);
            } else showMessageDialog(null, "Utl�n er ikke registrert.", "Utl�n", INFORMATION_MESSAGE);
          }

        } else if (kilde == reserverKnapp) {  // Reserverer ei bok
          String navn = showInputDialog(null, "Navnet p� kunden: ", "Reservasjon", QUESTION_MESSAGE);
          if (navn != null && navn.trim().length() > 0) {
            bibliotek.reserverEksemplar(isbn, navn);
            showMessageDialog(null, "Reservasjon av isbn  " + isbn + " er registrert.", "Reservasjon", INFORMATION_MESSAGE);
          } else showMessageDialog(null, "Reservasjon er ikke registrert.", "Reservasjon", INFORMATION_MESSAGE);

        } else if (kilde == kanselReservKnapp) { // Kanselerer reservasjon
          bibliotek.kanselerReservasjon(isbn);
          showMessageDialog(null, "Reservasjon av isbn  " + isbn + " er kanselert.", "Reservasjon", INFORMATION_MESSAGE);

        } else if (kilde == visL�ntakerKnapp) {
          ArrayList<String> l�nere = bibliotek.finnL�ntakere(isbn);
          if (l�nere.size() == 0) showMessageDialog(null, "Ingen l�ntakere.", "L�ntakere", INFORMATION_MESSAGE);
          else {
            String liste = "L�ntakerne:\n";
            for (String enL�ner : l�nere) liste += enL�ner + "\n";
            showMessageDialog(null,  liste, "L�ntakere", INFORMATION_MESSAGE);
            }
          } else {  // Returnerer ei bok
            ArrayList<Integer> eksemplarer = bibliotek.finnEksUte(isbn);
            int eksNr = velgEksemplarnr(eksemplarer, "Eksemplarer ute ");
            if (eksNr > 0) {
              bibliotek.returnerEksemplar(isbn, eksNr);
              showMessageDialog(null, "Retur av eksemplar nr " + eksNr + " er registrert.", "Retur av bok", INFORMATION_MESSAGE);
            } else showMessageDialog(null, "Retur av bok er ikke registrert.", "Retur av bok", INFORMATION_MESSAGE);
          }
          listeInnhold.set(bokIndeks, bibliotek.finnBokInfo(isbn));

      } catch (BiblException e) {
        showMessageDialog(null, e.getMessage(), "Melding", ERROR_MESSAGE);
        try { // oppdaterer raden dersom mulig
          listeInnhold.set(bokIndeks, bibliotek.finnBokInfo(isbn));
        } catch (Exception ex) {
        }
      } catch (RemoteException e) {
        showMessageDialog(null, "Kommunikasjonsproblem: " + e, "Melding", ERROR_MESSAGE);
        e.printStackTrace(); // til konsollvinduet
      }
    }

    private int velgEksemplarnr(ArrayList<Integer> eksemplarer, String tittel) {
      int valgtNr = 0;
      if (eksemplarer.size() > 0) {
        String[] valgmuligheter = new String[eksemplarer.size()];
        for (int i = 0; i < eksemplarer.size(); i++) {
          valgmuligheter[i] = "Eksemplar nr " + eksemplarer.get(i);
        }
        String valg = (String) showInputDialog(null, "Velg eksemplarnr", tittel, QUESTION_MESSAGE,
                                                null,  valgmuligheter, valgmuligheter[0]);
        if (valg  != null) {
          int pos = valg.lastIndexOf(' ');  // skal finne tallet som angir det valgte eksemplarnummeret
          String valgS = valg.substring(pos + 1);
          valgtNr = Integer.parseInt(valgS);  // skal aldri feile (!)
        }
      } else showMessageDialog(null, "Ingen eksemplarer", tittel, INFORMATION_MESSAGE);
      return valgtNr;
    }
  }
}

/* Klient for oppgave 19-3 */
class BibliotekKlient2 {
  public static void main(String[] args) throws Exception {
    Bibliotek tjener = (Bibliotek)Naming.lookup("rmi://localhost/Boktjener");
    String[] infoAlleB�ker = tjener.finnAlleB�ker();
    if (infoAlleB�ker.length == 0) {  // legger inn testdata dersom ingen data er lagt inn
      showMessageDialog(null, "Legger inn testdata\n", "Initiering", INFORMATION_MESSAGE);
      tjener.regNyBok(new Biblioteksbok("0-201-11743-6", "Turbo Pascal. A Problem Solving Approach",
                                                              "Elliot B. Koffamn"));
      tjener.regNyBok(new Biblioteksbok("0-13-089571-7", "C++ How to Program", "H. M. Deitel & P. J. Deitel"));
      tjener.regNyBok(new Biblioteksbok("0-13-081934-4", "Core Java Volume II - Advanced Features",
                                                              "Cay S. Horstmann, Gary Cornell"));
      tjener.regNyBok(new Biblioteksbok("0-596-00123-1", "Building Java Enterprise Applications",
                                                              "Brett McLaughlin"));
    }

    infoAlleB�ker = tjener.finnAlleB�ker();
    Klient2GUI gui = new Klient2GUI(infoAlleB�ker, tjener);
    gui.setVisible(true);
    gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
}

/* Klient for oppgave 20-1
class BibliotekKlient2 {
  public static void main(String[] args) throws Exception {
    DbWrapperFabrikk fabrikk = (DbWrapperFabrikk) Naming.lookup("rmi://localhost/Boktjener");
    Bibliotek tjener = fabrikk.lagDbWrapper();
    String[] infoAlleB�ker = tjener.finnAlleB�ker();
    Klient2GUI gui = new Klient2GUI(infoAlleB�ker, tjener);
    gui.setVisible(true);
    gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
} */