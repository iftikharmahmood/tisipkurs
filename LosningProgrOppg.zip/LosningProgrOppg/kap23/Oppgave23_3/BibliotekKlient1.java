/*
 * BibliotekKlient1.java EL 2006-01-16
 *
 * Denne klienten brukes til � registrere nye b�ker.
 * (Merk at kun en person kan reservere ei bok av gangen.)
 */

import java.io.*;
import java.rmi.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import mittBibliotek.MinDialog;
import static javax.swing.JOptionPane.*;

class RegistrerNyeB�kerVindu extends JFrame {
  private DefaultListModel listeInnhold = new DefaultListModel();
  private JList alleB�ker = new JList(listeInnhold);
  private BokDialog bokDialog = new BokDialog(this);

  private JButton nyBokKnapp = new JButton("Ny bok");
  private JButton nyttEksKnapp = new JButton("Nytt eksemplar av valgt bok");
  private JButton visL�ntakerKnapp = new JButton("Vis l�ntakere");
  private JButton oppfriskKnapp = new JButton("Gjenoppfrisk data");

  private Bibliotek bibliotek;

  public RegistrerNyeB�kerVindu(String[] infoAlleB�ker, Bibliotek startTjener) {
    setTitle("Registrering av nye b�ker");
    setLocation(200, 300);
    bokDialog.setLocation(300, 400);
    bibliotek = startTjener;
    add(new JLabel("Alle b�ker i biblioteket"), BorderLayout.NORTH);
    for (String bokinfo : infoAlleB�ker) {
      listeInnhold.addElement(bokinfo);
    }
    alleB�ker.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    alleB�ker.setSelectedIndex(0);
    JScrollPane listeMedScrollbar = new JScrollPane(alleB�ker);
    add(listeMedScrollbar, BorderLayout.CENTER);
    add(new Knappepanel(), BorderLayout.SOUTH);
    pack();
  }

  private class Knappepanel extends JPanel {
    public Knappepanel() {
      add(nyBokKnapp);
      add(nyttEksKnapp);
      add(visL�ntakerKnapp);
      add(oppfriskKnapp);
      Knappelytter lytter = new Knappelytter();
      nyBokKnapp.addActionListener(lytter);
      nyttEksKnapp.addActionListener(lytter);
      visL�ntakerKnapp.addActionListener(lytter);
      oppfriskKnapp.addActionListener(lytter);
    }
  }

  private class Knappelytter implements ActionListener {
    public void actionPerformed(ActionEvent hendelse) {
      try {
        JButton kilde = (JButton) hendelse.getSource();

        if (kilde == nyBokKnapp) { // Ei ny bok og f�rste eks. av denne.
          Bok boka = bokDialog.visDialog();
          if (boka != null) {
            bibliotek.regNyBok(boka);
            listeInnhold.addElement(boka.toString());
            showMessageDialog(null, "Ny boktittel er registrert", "Ny boktittel", INFORMATION_MESSAGE);
          } else showMessageDialog(null, "Ny boktittel er ikke registrert", "Ny boktittel", INFORMATION_MESSAGE);
        } else if (kilde == nyttEksKnapp) {  // Et nytt eks. av en eksisterende bok
          int bokindeks = alleB�ker.getSelectedIndex(); // til bruk ved oppdatering av listen
          String bokInfo = (String) alleB�ker.getSelectedValue();

          /* Bok-info'en er p� �n linje. Trenger ISBN som er f�rst p� linjen */
          int pos = bokInfo.indexOf(Bok.sep);
          String isbn = bokInfo.substring(0, pos).trim();
          int nr = bibliotek.regNyttEksemplar(isbn);
          showMessageDialog(null, "Ok. Det nye eksemplaret f�r nummer " + nr, "Nytt eksemplar", INFORMATION_MESSAGE);
          listeInnhold.set(bokindeks, bibliotek.finnBokInfo(isbn));

        } else if (kilde == visL�ntakerKnapp) {
          String bokInfo = (String) alleB�ker.getSelectedValue();
          if (bokInfo != null) {

            /* Bok-info'en er p� �n linje. Trenger ISBN som er f�rst p� linjen */
            int pos = bokInfo.indexOf(Bok.sep);
            String isbn = bokInfo.substring(0, pos).trim();
            ArrayList<String> l�nere = bibliotek.finnL�ntakere(isbn);
            if (l�nere.size() == 0) showMessageDialog(null, "Ingen l�ntakere.", "L�ntakere", INFORMATION_MESSAGE);
            else {
               String liste = "L�ntakerne:\n";
               for (String enL�ner : l�nere) liste += enL�ner + "\n";
               showMessageDialog(null,  liste, "L�ntakere", INFORMATION_MESSAGE);
             }
           }
        } else { // henter friske data fra tjeneren
          String[] infoAlleB�ker = bibliotek.finnAlleB�ker();
          listeInnhold.clear();
          for (String bokinfo : infoAlleB�ker) {
            listeInnhold.addElement(bokinfo);
          }
          alleB�ker.setSelectedIndex(0);
        }
      } catch (BiblException e) {
        showMessageDialog(null, e.getMessage(), "Melding", ERROR_MESSAGE);
      } catch (RemoteException e) {
        showMessageDialog(null, "Kommunikasjonsproblemer: " + e, "Melding", ERROR_MESSAGE);
        e.printStackTrace(); // til konsollvinduet
      }
    }
  }
}

class BokDialog extends MinDialog {
  private JTextField isbn = new JTextField(10);
  private JTextField tittel = new JTextField(10);
  private JTextField forfatter = new JTextField(10);

  public BokDialog(JFrame foreldre) {
    super(foreldre, "Ny bok");
    add(new JLabel("Legg inn data:"), BorderLayout.NORTH);
    add(new DataPanel(), BorderLayout.CENTER);
    add(finnKnappepanel(), BorderLayout.SOUTH);
    pack();
  }

  private class DataPanel extends JPanel {
    public DataPanel() {
      setLayout(new GridLayout(3, 2));  // tre linjer
      add(new JLabel("ISBN", JLabel.RIGHT));
      add(isbn);
      add(new JLabel("Tittel", JLabel.RIGHT));
      add(tittel);
      add(new JLabel("Forfatter", JLabel.RIGHT));
      add(forfatter);
    }
  }

  protected boolean okData() { // erstatter den arvede utgaven
    if (isbn.getText().trim().equals("") ||
        tittel.getText().trim().equals("") ||
        forfatter.getText().trim().equals("")) {
      showMessageDialog(null, "Du m� skrive inn data i alle feltene", "Melding", ERROR_MESSAGE);
      settOk(false);
      return false;
    } else {
      settOk(true);
      return true;
    }
  }

  public Bok visDialog() {
    isbn.setText("");
    tittel.setText("");
    forfatter.setText("");
    settOk(false);
    setVisible(true);
    if (erOk()) return new Bok(isbn.getText().trim(), tittel.getText().trim(), forfatter.getText().trim());
    else return null;
  }
}

/* Klient for oppgave 19-3 */
class BibliotekKlient1 {
  public static void main(String[] args) throws Exception {
    Bibliotek tjener = (Bibliotek) Naming.lookup("rmi://localhost/Boktjener");
    String[] infoAlleB�ker = tjener.finnAlleB�ker();
    if (infoAlleB�ker.length == 0) { // legger inn testdata dersom ingen data er lagt inn
      showMessageDialog(null, "Legger inn testdata\n", "Initiering", INFORMATION_MESSAGE);
      tjener.regNyBok(new Biblioteksbok("0-201-11743-6", "Turbo Pascal. A Problem Solving Approach",
                                                              "Elliot B. Koffamn"));
      tjener.regNyBok(new Biblioteksbok("0-13-089571-7", "C++ How to Program", "H. M. Deitel & P. J. Deitel"));
      tjener.regNyBok(new Biblioteksbok("0-13-081934-4", "Core Java Volume II - Advanced Features",
                                                              "Cay S. Horstmann, Gary Cornell"));
      tjener.regNyBok(new Biblioteksbok("0-596-00123-1", "Building Java Enterprise Applications",
                                                              "Brett McLaughlin"));
    }
    infoAlleB�ker = tjener.finnAlleB�ker();
    RegistrerNyeB�kerVindu gui = new RegistrerNyeB�kerVindu(infoAlleB�ker, tjener);
    gui.setVisible(true);
    gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
}

/* Klient for oppgave 20-1
class BibliotekKlient1 {
  public static void main(String[] args) throws Exception {
    DbWrapperFabrikk fabrikk = (DbWrapperFabrikk) Naming.lookup("rmi://localhost/Boktjener");
    Bibliotek tjener = fabrikk.lagDbWrapper();
    String[] infoAlleB�ker = tjener.finnAlleB�ker();
    RegistrerNyeB�kerVindu gui = new RegistrerNyeB�kerVindu(infoAlleB�ker, tjener);
    gui.setVisible(true);
    gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
} */
