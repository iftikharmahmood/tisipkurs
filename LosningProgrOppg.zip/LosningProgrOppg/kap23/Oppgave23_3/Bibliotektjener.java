/*
 * Bibliotektjener.java EL 2006-01-16
 *
 * Lager og registrerer et nytt Bibliotek-objekt
 */
import java.rmi.Naming;
import static javax.swing.JOptionPane.*;
class Bibliotektjener {
  public static void main(String[] args) throws Exception {
      Bibliotek tjener = new BibliotekImpl();
      String objektnavn = "Boktjener";
      System.out.println("Tjeneren er laget.");
      Naming.rebind(objektnavn, tjener);
      System.out.println("Tjeneren er registrert som " + objektnavn);
      showMessageDialog(null, "Trykk OK for � stoppe tjeneren.", "Bibliotek", INFORMATION_MESSAGE);
      Naming.unbind(objektnavn);
      System.exit(0);
  }
}
