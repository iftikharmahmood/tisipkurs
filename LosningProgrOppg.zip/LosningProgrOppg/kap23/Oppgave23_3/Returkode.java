/*
 * Returkode.java   2006-01-16
 * Returkoder for RMI bibliotekssystem
 */

public enum Returkode {
  ugyldigIsbn("Ugyldig ISBN."),
  erReservertFraF�r("Boka er reservert fra f�r."),
  alleredeUtl�nt("Dette eksemplaret er allerede utl�nt."),
  ugyldigEksNr("Ugyldig eksemplarnummer."),
  reserveringUn�dv("Ikke n�dvendig � reservere, det er eksemplarer inne."),
  reservert("Denne boka er reservert. Legg den til side.") ;

  private String tekst;
  Returkode(String startTekst) {
    tekst = startTekst;
  }

  public String toString() {
    return tekst;
  }
}

