/*
 * BibliotekImpl.java E.L. 2006-01-16
 *
 * BibliotekImpl er mutabel og kan n�s av flere klienter. Alle metodene er derfor
 * synkroniserte. Hashtable har synkroniserte metoder. Klassen Bibliotekbok har
 * imidlertid ikke det. Den klassen bruker ogs� ArrayList, som heller ikke har
 * synkroniserte metoder. Dette g�r bra p� grunn av at disse objektene er 100%
 * gjemt inne i BibliotekImpl-objektet, og dermed er beskyttet av de metodene som er der.
 */
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

class BibliotekImpl extends UnicastRemoteObject implements Bibliotek {

  /* Hashtabellen inneholder objekter av klassen BibliotekImpl, isbn er n�kkelen */
  private Hashtable<String, Biblioteksbok> b�ker = new Hashtable<String, Biblioteksbok>();

  public BibliotekImpl() throws RemoteException {
  }

  public synchronized void regNyBok(Bok nyBok) throws RemoteException, BiblException {
    if (b�ker.get(nyBok.finnIsbn()) != null) {
      throw new BiblException(Returkode.ugyldigIsbn.toString());
    }
    /* F�rste eksemplar registreres i konstrukt�ren */
    Biblioteksbok bok = new Biblioteksbok(nyBok.finnIsbn(), nyBok.finnTittel(), nyBok.finnForfatter());
    b�ker.put(bok.finnIsbn(), bok);
  }

  public synchronized int regNyttEksemplar(String nyIsbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(nyIsbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    return bok.leggTilNyttEksemplar();
  }

  public synchronized boolean erReservert(String isbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    return (bok.finnReservertAv() != null);
  }

  public synchronized void l�nUtEksemplar(String isbn, String navn, int eksNr) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    bok.l�nUt(navn, eksNr);
  }

  public synchronized void reserverEksemplar(String isbn, String navn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    bok.reserver(navn);
  }

  public synchronized void kanselerReservasjon(String isbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    bok.kanselerReservasjon();
  }

  public synchronized void returnerEksemplar(String isbn, int eksNr) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    bok.returnerEksemplar(eksNr);
  }

  public synchronized ArrayList<String> finnL�ntakere(String isbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    return bok.finnL�ntakere();
  }

  public synchronized ArrayList<Integer> finnEksInne(String isbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    return bok.finnEksInne();
  }

  public synchronized ArrayList<Integer> finnEksUte(String isbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    return bok.finnEksUte();
  }

  public synchronized int finnAntEksInne(String isbn) throws RemoteException, BiblException {
    return finnEksInne(isbn).size();
  }

  public synchronized int finnAntEksUte(String isbn) throws RemoteException, BiblException {
    return finnEksUte(isbn).size();
  }

  public synchronized String finnBokInfo(String isbn) throws RemoteException, BiblException {
    Biblioteksbok bok = b�ker.get(isbn);
    if (bok == null) throw new BiblException(Returkode.ugyldigIsbn.toString());
    else return bok.toString();
  }

  public synchronized String[] finnAlleB�ker() throws RemoteException {
    String[] alle = new String[b�ker.size()];
    /* Bruker Enumeration for � finne alle elementene i hashtabellen.
       Enumeration gir oss alle n�klene (isbn's), se online-API dok. */
    int indeks = 0;
    Enumeration<Biblioteksbok> enBok = b�ker.elements();
    while (enBok.hasMoreElements()) {
      Biblioteksbok bok = enBok.nextElement();
      alle[indeks] =  bok.toString();
      indeks++;
    }
    return alle;
  }
}
