/*
 * KlientImpl.java ST 2000-05-22
 *
 * Implementasjonen av interfacet Klient.
 */
import java.rmi.*;
import java.rmi.server.*;

public class KlientImpl extends UnicastRemoteObject implements Klient {
	/*
 	 * Objektvariabler
 	 */
  private String navn;
  
	/*
   * Konstrukt�r
 	 */
  public KlientImpl(String startNavn) throws RemoteException {
    navn = startNavn;
  }
  
	/*
	 * Finn-metoder
 	 */  
  public String finnNavn() throws RemoteException {
    return navn;
  }

	/*
	 * Andre metoder
 	 */  
  public void skrivTekst(String tekst) throws RemoteException {
    System.out.println(tekst);
  }
}
