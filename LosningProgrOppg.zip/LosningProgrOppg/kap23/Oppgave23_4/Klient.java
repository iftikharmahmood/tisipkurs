/*
 * Klient.java ST 2000-05-22
 * 
 * Definerer interfacet Klient.
 */
import java.rmi.*;
import java.rmi.server.*;

public interface Klient extends Remote {
  String finnNavn() throws RemoteException;
  void skrivTekst(String tekst) throws RemoteException;
}
