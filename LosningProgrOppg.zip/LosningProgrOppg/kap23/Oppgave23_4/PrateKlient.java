/*
 * PrateKlient.java ST/EL 2006-01-20
 *
 * Oppretter og kommuniserer ved hjelp av en Klient.
 */
import java.io.*;
import java.rmi.*;

public class PrateKlient {
  public static void main(String[] args) throws Exception {
    Tjener tjener = (Tjener) Naming.lookup("rmi://localhost/Pratetjener");

    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Kun en linje pr innlegg. Tom linje angir utmelding fra praten.");
    System.out.print("Navn: ");
    Klient klient = new KlientImpl(in.readLine());
    tjener.registrerMeg(klient);

    String linje = in.readLine();
    while (!linje.trim().equals("")) {
      tjener.sendTekst(klient.finnNavn() + ": " + linje);
      linje = in.readLine();
    }

    tjener.meldMegUt(klient);
    System.exit(0); // Avslutt.
  }
}
