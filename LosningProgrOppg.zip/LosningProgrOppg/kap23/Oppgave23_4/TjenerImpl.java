/*
 * TjenerImpl.java ST/EL 2006-01-20
 *
 * Implementasjon av interfacet Tjener.
 */
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

public class TjenerImpl extends UnicastRemoteObject implements Tjener {
  /*
   * Objektvariabler
   */
  private ArrayList<Klient> klienter = new ArrayList<Klient>();

  /*
   * Konstrukt�r
   */
  public TjenerImpl() throws RemoteException {
  }

  /*
   * Andre metoder
   */
  public void registrerMeg(Klient klient) throws RemoteException {
    sendTekst(klient.finnNavn() + " registrert.");
    klienter.add(klient);
    System.out.println("N� er " + klient.finnNavn() + " registrert.");
  }

  public void meldMegUt(Klient klient) throws RemoteException {
   for (int i = 0; i < klienter.size(); i++) {
      Klient enKlient = klienter.get(i);
      if (enKlient.equals(klient)) {
        klienter.remove(i);
        System.out.println("N� er " + klient.finnNavn() + " meldt ut.");
      }
    }
    sendTekst(klient.finnNavn() + " meldt ut.");
  }

  public void sendTekst(String tekst) throws RemoteException {
    int i = 0;
    while (i < klienter.size()) {
      Klient klient = klienter.get(i);

     /*
      * Fors�ker � n� en klient. Dersom den er koplet ned,
      * kastes ConnectException, og vi stryker klienten fra listen.
      */
      try {
        klient.skrivTekst(tekst);
        i++; // Denne utf�res ikke dersom ConnectException kastes.
      } catch(ConnectException e) {
        System.out.println("Exception i sendTekst: " + e);
        klienter.remove(i); // Gj�r gjeldende indeks p� nytt gyldig.
      }
    }
  }
}
