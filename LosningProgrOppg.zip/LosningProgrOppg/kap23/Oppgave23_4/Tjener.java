/*
 * Tjener.java ST 2000-05-22
 *
 * Definerer interfacet Tjener.
 */
import java.rmi.*;
import java.rmi.server.*;

public interface Tjener extends Remote {
  void registrerMeg(Klient klient) throws RemoteException;
  void meldMegUt(Klient klient) throws RemoteException;
  void sendTekst(String tekst) throws RemoteException;
}
