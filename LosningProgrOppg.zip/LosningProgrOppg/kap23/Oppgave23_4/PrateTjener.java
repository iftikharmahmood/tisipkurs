/*
 * PrateTjener.java EL 2006-01-20
 *
 * Oppretter og registrerer en tjener.
 */
import java.rmi.*;
import java.rmi.server.*;

public class PrateTjener {
  public static void main(String[] args) throws Exception {
    String objektnavn = "Pratetjener";
    System.out.println("Dette er statusvindu for tjenersiden.");

    Tjener tjener = new TjenerImpl();
    System.out.println("Tjeneren er laget.");

    Naming.rebind(objektnavn, tjener);
    System.out.println("Tjeneren er registrert som " + objektnavn);

    javax.swing.JOptionPane.showMessageDialog(null, "Trykk Ok for � stoppe tjeneren.");
    Naming.unbind(objektnavn);
    System.exit(0);
  }
}
