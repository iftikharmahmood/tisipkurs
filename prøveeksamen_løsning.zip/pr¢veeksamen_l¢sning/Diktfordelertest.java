/**
 * L�sningsforslag til oppgave 2 i pr�veeksamen
  */

/*
 * Dikt
 */
class Dikt implements Comparable<Dikt> {
  private final String diktet;
  private final String dikteren;

  public Dikt(String diktet, String dikteren) {
    this.diktet = diktet;
    this.dikteren = dikteren;
  }

  public String getDiktet() {
    return diktet;
  }

  public String getDikteren() {
    return dikteren;
  }

  /* Sammenligner dikt mhp. diktlengde. St�rste f�rst */
  public int compareTo(Dikt annetDikt) {
    return annetDikt.getDiktet().length() - diktet.length();
  }

  /* ekstra */
  public String toString() {
    return diktet + "\n(" + diktet.length() + " " + dikteren + ")";
  }
}



/**
 * Diktsamling
 */
class Diktsamling {
  private final Dikt[] samlingen; // fortl�pende opp t.o.m. antallDikt, null deretter
  private int antallDikt;

  public Diktsamling(int max) {
    this.samlingen = new Dikt[max];
    this.antallDikt = 0;
  }

  public boolean leggTil(Dikt diktet) {
    if (antallDikt - 1 < samlingen.length) {
      samlingen[antallDikt] = diktet;
      antallDikt++;
      return true;
    } else return false;
  }

  /* Returnerer true hvis og bare hvis det fins dikt som begynner med begynnelse
   */
  public boolean finsEtDikt(String begynnelse) {
    int i = 0;
    while (i < antallDikt && !samlingen[i].getDiktet().startsWith(begynnelse)) i++;
    return i != antallDikt;
  }

  /* Returnerer alle dikterne uten gjentagelser.
   * Returtabell kan inneholde null-er.
   */
  public String[] finnAlleDikterne() {
    String[] dikterne = new String[antallDikt];
    int teller = 0;
    for (int i = 0; i < antallDikt; i++) {
      String kanskjeNy = samlingen[i].getDikteren();
      int j = 0;
      while (j < teller && !dikterne[j].equals(kanskjeNy)) {
        j++;
       }
      if (j == teller) { // Dikteren fantes ikke fra f�r
        dikterne[teller] = kanskjeNy;
        teller++;
      }
    }
    return dikterne;
  }


  public int finnAntallTegn() {
    int sum = 0;
    for (int i = 0; i < antallDikt; i++) {
      sum += samlingen[i].getDiktet().length();
    }
    return sum;
  }

  /*
   * Parameteren angir grense for max antall tegn per side
   * Tabellene kan inneholde null-er.
   */
  public Diktsamling[] finnSidefordeling(int maxPerSide) {
    Dikt[] kopi = new Dikt[samlingen.length];
    System.arraycopy(samlingen, 0, kopi, 0, samlingen.length); // 1.
    java.util.Arrays.sort(kopi, 0, antallDikt); // 2.

    /* 3. */
    Diktsamling[] sidene = new Diktsamling[antallDikt]; // minst ett dikt per side
    for (int side = 0; side < sidene.length; side++) {
      sidene[side] = new Diktsamling(antallDikt); // max alle dikt p� en eneste side
    }

    /* 4. */
    for (int i = 0; i < antallDikt; i++) {
      int side = 0;
      boolean plassert = false;
      if (kopi[i].getDiktet().length() <= maxPerSide) { // diktet er ikke for langt
        while (side < sidene.length && !plassert) {
          if (sidene[side].finnAntallTegn() + kopi[i].getDiktet().length() <= maxPerSide) {
            sidene[side].leggTil(kopi[i]);
            plassert = true;
          } // ic
          side++;
        } // while
      } // if
    } // for
    return sidene; // 5.
  }

  /* ekstra */
  public int getAntallDikt() {
    return antallDikt;
  }

  /* ekstra */
  public String toString() {
    String resultat = "";
    for (int i = 0; i < antallDikt; i++) {
      resultat += "\n\nDIKT" + (i + 1) + ":\n" + samlingen[i];
    }
    resultat += "\n\nAntall dikt " + antallDikt + ". Antall tegn i samlingen: " + finnAntallTegn();
    return resultat;
  }
}



/**
 * Ekstra klasse
 */
class Diktfordelertest {
  public static void main(String[] args) {
    final int MAX_ANTALL_DIKT = 7;
    final int MAX_ANTALL_TEGN_PER_SIDE = 1000; // per side
    Diktsamling samling = new Diktsamling(MAX_ANTALL_DIKT);

    String eidslott1 = "Mitt �ye over br�nnen\nDypt nede\nlyser ansiktet\nDypere\net annet";
    samling.leggTil(new Dikt(eidslott1, "Eidslott"));

    String boye = "Ja visst g�r det ont n�r knoppar brister. \nVarf�r skulle annars v�ren tveka? \nVarf�r skulle all v�r heta l�ngtan \nbindas i det frusna bitterbleka? \nH�ljet var ju knoppen hela vintern. \nVad �r det f�r nytt, som t�r och spr�nger? \nJa visst g�r det ont n�r knoppar brister, \nont f�r det som v�xer \noch det som st�nger. \n\nJa nog �r det sv�rt n�r droppar faller. \nSk�lvande av �ngslan tungt de h�nger, \nklamrar sig vid kvisten, sv�ller, glider  \n- tyngden drar dem ner�t, hur de kl�nger. \nSv�rt att vara oviss, r�dd och delad, \nsv�rt att k�nna djupet dra och kalla, \n�nd� sitta kvar och bara darra  - \nsv�rt att vilja stanna och vilja falla. \n\nD�, n�r det �r v�rst och inget hj�lper, \nBrister som i jubel tr�dets knoppar. \nD�, n�r ingen r�dsla l�ngre h�ller, \nfaller i ett glitter kvistens droppar \ngl�mmer att de skr�mdes av det nya \ngl�mmer att de �ngslades f�r f�rden  - \nk�nner en sekund sin st�rsta trygghet, \nvilar i den tillit som skapar v�rlden.";
    samling.leggTil(new Dikt(boye, "Boye"));

    String obstfelder1 = "Kan speilet tale? \n\nSpeilet kan tale! \n\nSpeilet skal se paa dig hver morgen, \nforskende, \nse paa dig med det dybe, kloge �ie, \n� dit eget! \nhilse dig med det varme, det m�rkeblaa �ie: \nEr du ren? \nEr du tro?";
    samling.leggTil(new Dikt(obstfelder1, "Obstfelder"));

    String obstfelder2 = "Jeg ser p� den hvide himmel, \njeg ser p� de gr�bl� skyer, \njeg ser p� den blodige sol. \n\nDette er alts� verden. \nDette er alts� klodernes hjem. \n\nEn regndr�be! \n\nJeg ser p� de h�ie huse, \njeg ser p� de tusende vinduer, \njeg ser p� det fjerne kirket�rn. \n\nDette er alts� jorden. \nDette er alts� menneskenes hjem. \n\nDe gr�bl� skyer samler sig. Solen blev borte. \n\nJeg ser p� de velkl�dte herrer, \njeg ser p� de smilende damer, \njeg ser p� de ludende heste. \n\nHvor de gr�bl� skyer blir tunge. \n\nJeg ser, jeg ser �\nJeg er vist kommet p� en feil klode!\nHer er s� underligt �";
    samling.leggTil(new Dikt(obstfelder2, "Obstfelder"));

    String hagerup = "Det bor en gammel baker\np� en bitte liten �y.\nHan er s� lei av kaker\nog krem og syltet�y.\nMen han m� sitte likevel\nog spise sine kaker selv.\nFor han bor helt alene\np� en bitteliten �y.\n\nN�r sm� og store b�ter\ng�r dampende forbi,\nda sitter han og gr�ter\ni sitt varme bakeri,\nog spiser loff og fattigmann,\nfor ingen kunder g�r i land.\nOg han er helt alene p�\np� en bitte liten �y.\n\nDet var en gammel baker\np� en bitte liten �y.\nHan �t for mange kaker\nmed krem og syltet�y.\nForleden dag s� satt han d�d\nmidt i en haug av wienerbr�d.\nOg n� bor ingen baker\np� en bitte liten �y.";
    samling.leggTil(new Dikt(hagerup, "Hagerup"));

    if (samling.finsEtDikt("Jeg ser")) System.out.println("\"Jeg ser\" fins");
    else System.out.println("\"Jeg ser\" fins ikke");

    if (samling.finsEtDikt("Jeg h�rer")) System.out.println("\"Jeg h�rer\" fins");
    else System.out.println("\"Jeg h�rer\" fins ikke");

    String[] dikterne = samling.finnAlleDikterne();
    String alleDikterne = "\n----------- ALLE DIKTERNE: ----------------\n";
    for (int i = 0; i < dikterne.length; i++) {
      if (dikterne[i] != null) alleDikterne += dikterne[i] + "\n";
    }
    System.out.println(alleDikterne);

    Diktsamling[] sidene = samling.finnSidefordeling(MAX_ANTALL_TEGN_PER_SIDE);
    String sidefordeling = "------------ SIDEFORDELING: ----------- ";
    for (int i = 0; i < sidene.length; i++) {
      sidefordeling += "\n\n......... SIDE " + (i + 1) + ":" + sidene[i];
    }
    System.out.println(sidefordeling);
  }
}

/*
"Jeg ser" fins
"Jeg h�rer" fins ikke

----------- ALLE DIKTERNE: ----------------
Eidslott
Boye
Obstfelder
Hagerup

------------ SIDEFORDELING: -----------

......... SIDE 1:

DIKT1:
Ja visst g�r det ont n�r knoppar brister.
Varf�r skulle annars v�ren tveka?
Varf�r skulle all v�r heta l�ngtan
bindas i det frusna bitterbleka?
H�ljet var ju knoppen hela vintern.
Vad �r det f�r nytt, som t�r och spr�nger?
Ja visst g�r det ont n�r knoppar brister,
ont f�r det som v�xer
och det som st�nger.

Ja nog �r det sv�rt n�r droppar faller.
Sk�lvande av �ngslan tungt de h�nger,
klamrar sig vid kvisten, sv�ller, glider
- tyngden drar dem ner�t, hur de kl�nger.
Sv�rt att vara oviss, r�dd och delad,
sv�rt att k�nna djupet dra och kalla,
�nd� sitta kvar och bara darra  -
sv�rt att vilja stanna och vilja falla.

D�, n�r det �r v�rst och inget hj�lper,
Brister som i jubel tr�dets knoppar.
D�, n�r ingen r�dsla l�ngre h�ller,
faller i ett glitter kvistens droppar
gl�mmer att de skr�mdes av det nya
gl�mmer att de �ngslades f�r f�rden  -
k�nner en sekund sin st�rsta trygghet,
vilar i den tillit som skapar v�rlden.
(948 Boye)

Antall dikt 1. Antall tegn i samlingen: 948

......... SIDE 2:

DIKT1:
Det bor en gammel baker
p� en bitte liten �y.
Han er s� lei av kaker
og krem og syltet�y.
Men han m� sitte likevel
og spise sine kaker selv.
For han bor helt alene
p� en bitteliten �y.

N�r sm� og store b�ter
g�r dampende forbi,
da sitter han og gr�ter
i sitt varme bakeri,
og spiser loff og fattigmann,
for ingen kunder g�r i land.
Og han er helt alene p�
p� en bitte liten �y.

Det var en gammel baker
p� en bitte liten �y.
Han �t for mange kaker
med krem og syltet�y.
Forleden dag s� satt han d�d
midt i en haug av wienerbr�d.
Og n� bor ingen baker
p� en bitte liten �y.
(573 Hagerup)

DIKT2:
Kan speilet tale?

Speilet kan tale!

Speilet skal se paa dig hver morgen,
forskende,
se paa dig med det dybe, kloge �ie,
? dit eget!
hilse dig med det varme, det m�rkeblaa �ie:
Er du ren?
Er du tro?
(207 Obstfelder)

DIKT3:
Mitt �ye over br�nnen
Dypt nede
lyser ansiktet
Dypere
et annet
(62 Eidslott)

Antall dikt 3. Antall tegn i samlingen: 842

......... SIDE 3:

DIKT1:
Jeg ser p� den hvide himmel,
jeg ser p� de gr�bl� skyer,
jeg ser p� den blodige sol.

Dette er alts� verden.
Dette er alts� klodernes hjem.

En regndr�be!

Jeg ser p� de h�ie huse,
jeg ser p� de tusende vinduer,
jeg ser p� det fjerne kirket�rn.

Dette er alts� jorden.
Dette er alts� menneskenes hjem.

De gr�bl� skyer samler sig. Solen blev borte.

Jeg ser p� de velkl�dte herrer,
jeg ser p� de smilende damer,
jeg ser p� de ludende heste.

Hvor de gr�bl� skyer blir tunge.

Jeg ser, jeg ser ?
Jeg er vist kommet p� en feil klode!
Her er s� underligt ?
(569 Obstfelder)

Antall dikt 1. Antall tegn i samlingen: 569

......... SIDE 4:

Antall dikt 0. Antall tegn i samlingen: 0

......... SIDE 5:

Antall dikt 0. Antall tegn i samlingen: 0
*/