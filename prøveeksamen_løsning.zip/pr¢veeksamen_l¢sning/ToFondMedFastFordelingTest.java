/**
 * L�sningsforslag til oppgave 1 i pr�veeksamen
 *
 */

/**
 * Fond
 * Et fond er som en bankkonto. Faktiske renter legges til en gang i �ret.
 */
class Fond {
  public static final double SKATTESATS = 23;
  private double kapital;
  private double rentesats; // i prosent, �rlig
  private double forvaltningshonorar; // i prosent, �rlig

  public Fond(double kapital, double rentesats, double forvaltningshonorar) {
    this.kapital = kapital;
    this.rentesats = rentesats;
    this.forvaltningshonorar = forvaltningshonorar;
   }

  public double getKapital() {
    return kapital;
  }

  public double getRentesats() {
    return rentesats;
  }

  public double getForvaltningshonorar() {
    return forvaltningshonorar;
  }

  public double finnFaktiskRentesats() {
    return rentesats - forvaltningshonorar;
  }

  public double finnFaktiskeRenter() {
    return kapital * finnFaktiskRentesats() / 100;
  }

  public void leggTilFaktiskeRenter() {
    double renter = finnFaktiskeRenter();
    kapital = kapital + renter;
  }

  /* Returnerer antall �r det vil ta f�r kapital kommer opp i m�lbel�p eller mer */
  public int finnAntall�r(double m�lbel�p) {
    int antall�r = 0;
    Fond kopi = new Fond(kapital, rentesats, forvaltningshonorar);
    while (kopi.getKapital() < m�lbel�p) {
      kopi.leggTilFaktiskeRenter();
      antall�r++;
    }
    return antall�r;
  }

  public void settInn(double bel�p) {
    kapital += bel�p;
  }

  public double taUtOgBetalSkatt(double bel�p) {
    kapital -= bel�p;
    double skatt = bel�p * SKATTESATS / 100;
    kapital -= skatt;
    return skatt;
  }

  /* ekstra */
  public String toString() {
    return "kapital " + kapital + ", rentesats " + rentesats + ", forvaltningshonorar " + forvaltningshonorar;
  }
} // Fond



/**
 * ToFondFastFordeling
 * To fond med fast prosentvis fordeling av kapitalen seg imellom.
 */
class ToFondMedFastFordeling {
  private Fond fond1; // fond1s faktiske rentesats er st�rre eller lik fond2s faktiske rentesats
  private Fond fond2;
  private double prosentdel1; // fond1's prosentdel. fond1s kapital er prosentdel1% av total kapital.

  public ToFondMedFastFordeling(double kapital, double rentesats1, double rentesats2,
      double forvaltningshonorar1, double forvaltningshonorar2, double prosentdel1) {
    this.fond1 = new Fond(kapital * prosentdel1 / 100, rentesats1, forvaltningshonorar1);
    this.prosentdel1 = prosentdel1;
    this.fond2 = new Fond(kapital * (100 - prosentdel1) / 100, rentesats2, forvaltningshonorar2);
    if (fond1.finnFaktiskRentesats() < fond2.finnFaktiskRentesats()) {
      Fond opprinneligFond1 = fond1;
      fond1 = fond2;
      fond2 = opprinneligFond1;
      this.prosentdel1 = 100 - prosentdel1;
    }
  }

  public double leggTilFaktiskeRenterOgRebalanser() {
    double merVekst = fond1.finnFaktiskeRenter() - fond2.finnFaktiskeRenter();
        /* Alternativt: double merVekst
          = (fond1.getRentesats() - fond2.getRentesats()) * fond1.getKapital() / 100; */
    fond1.leggTilFaktiskeRenter();
    fond2.leggTilFaktiskeRenter();
    double p2 = 100 - prosentdel1;
    double skalFordeles = merVekst / (1 + Fond.SKATTESATS * p2 / 10000);
    double flytt = p2 * skalFordeles / 100;
    double skatt = fond1.taUtOgBetalSkatt(flytt);
    fond2.settInn(flytt);
    return skatt;
  }

  /* ekstra */
  public double getKapital1() {
    return fond1.getKapital();
  }

  /* ekstra */
  public double getKapital2() {
    return fond1.getKapital();
  }

  /* ekstra */
  public double getTotalKapital() {
    return fond1.getKapital() + fond2.getKapital();
  }

  /* ekstra */
  public String toString() {
    return fond1 + "\n" + fond2;
  }
} //  ToFondMedFastFordeling



class ToFondMedFastFordelingTest {
  public static void main(String[] args) {
    System.out.println("--- Kombinasjonsfond med 50% aksjefond og 50% rentefond: ---\n");
    Fond kombinasjonsfond = new Fond(2000, 5.3, 0.3);
    System.out.println(kombinasjonsfond);

    System.out.println("\nAntall for � n� " + 2300 + " kr eller mer: "
        + kombinasjonsfond.finnAntall�r(2300));

    System.out.println("\nF�lger fondet over tre �r:");
    for (int i = 0; i < 3; i++) {
      kombinasjonsfond.leggTilFaktiskeRenter();

      System.out.printf("Etter " + (i + 1) + " �r: %.2f\n",
          kombinasjonsfond.getKapital());
    }

    System.out.println("\n\n--- To enkeltfond med 50-50-fordeling. Rebalansering ---\n");

    ToFondMedFastFordeling toFond
        = new ToFondMedFastFordeling(2000, 7.8, 2.8, 0, 0, 50);
    System.out.println(toFond + "\n");

    for (int i = 0; i < 3; i++) {
      toFond.leggTilFaktiskeRenterOgRebalanser();
      System.out.printf("Etter " + (i + 1) + " �r: %.2f + %.2f = %.2f \n",
          toFond.getKapital1(), toFond.getKapital2(), toFond.getTotalKapital());
     }
  } // main()
}  // ToFondMedFastFordelingTest


/*
--- Kombinasjonsfond med 50% aksjefond og 50% rentefond: ---

kapital 2000.0, rentesats 5.3, forvaltningshonorar 0.3

Antall for � n� 2300 kr eller mer: 3

F�lger fondet over tre �r:
Etter 1 �r: 2100,00
Etter 2 �r: 2205,00
Etter 3 �r: 2315,25


--- To enkeltfond med 50-50-fordeling. Rebalansering ---

kapital 1000.0, rentesats 7.8, forvaltningshonorar 0.0
kapital 1000.0, rentesats 2.8, forvaltningshonorar 0.0

Etter 1 �r: 1050,42 + 1050,42 = 2100,84
Etter 2 �r: 1103,39 + 1103,39 = 2206,77
Etter 3 �r: 1159,02 + 1159,02 = 2318,04
*/